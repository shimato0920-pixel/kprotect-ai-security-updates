<?php
/**
 * Site-wide threat level protection for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculates site-wide threat levels and defensive adjustments.
 */
final class KProtect_Threat_Level {

	/**
	 * Minimum effective firewall block threshold.
	 */
	private const MIN_BLOCK_THRESHOLD = 40;

	/**
	 * Minimum effective rate limit.
	 */
	private const MIN_RATE_LIMIT = 10;

	/**
	 * Threat-level transient cache key.
	 */
	private const CACHE_KEY = 'kprotect_threat_level';

	/**
	 * Threat-level cache lifetime in seconds.
	 */
	private const CACHE_TTL = 60;

	/**
	 * Return the current site-wide threat level.
	 *
	 * @return string
	 */
	public static function current_level(): string {
		$cached = get_transient( self::CACHE_KEY );

		if ( in_array( $cached, array( 'normal', 'elevated', 'high' ), true ) ) {
			return $cached;
		}

		$metrics = self::recent_metrics();

		$level = self::calculate_level(
			$metrics['blocked_events'],
			$metrics['critical_events'],
			$metrics['attack_sources']
		);

		set_transient(
			self::CACHE_KEY,
			$level,
			self::CACHE_TTL
		);

		return $level;
	}

	/**
	 * Clear the cached site-wide threat level.
	 *
	 * @return void
	 */
	public static function clear_cache(): void {
		delete_transient( self::CACHE_KEY );
	}

	/**
	 * Return recent high-confidence threat metrics.
	 *
	 * Only high-risk events that can create a new defensive action are
	 * considered. Accesses from already-blocked IPs are intentionally excluded
	 * so repeated requests from one blocked attacker cannot raise the site-wide
	 * threat level.
	 *
	 * @return array{blocked_events:int,critical_events:int,attack_sources:int}
	 */
	public static function recent_metrics(): array {
		global $wpdb;

		$cutoff = gmdate(
			'Y-m-d H:i:s',
			time() - ( 15 * MINUTE_IN_SECONDS )
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Threat protection requires current security-event history from the KProtect-owned log table.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT
					SUM(CASE WHEN blocked = 1 THEN 1 ELSE 0 END) AS blocked_events,
					COUNT(*) AS critical_events,
					COUNT(DISTINCT NULLIF(ip_hash, \'\')) AS attack_sources
				FROM %i
				WHERE created_at >= %s
				AND risk_score >= %d
				AND event_type IN (%s, %s, %s)',
				$wpdb->prefix . 'kprotect_logs',
				$cutoff,
				90,
				'firewall',
				'rate_limit',
				'login_blocked'
			)
		);

		if ( ! is_object( $row ) ) {
			return array(
				'blocked_events'  => 0,
				'critical_events' => 0,
				'attack_sources'  => 0,
			);
		}

		return array(
			'blocked_events'  => max( 0, (int) ( $row->blocked_events ?? 0 ) ),
			'critical_events' => max( 0, (int) ( $row->critical_events ?? 0 ) ),
			'attack_sources'  => max( 0, (int) ( $row->attack_sources ?? 0 ) ),
		);
	}
	/**
	 * Assess the current threat level and its primary reason.
	 *
	 * @param int $blocked_events  Number of blocked events.
	 * @param int $critical_events Number of events with risk score 90 or higher.
	 * @param int $attack_sources  Number of distinct attack sources.
	 * @return array{level:string,reason:string}
	 */
	public static function assessment(
		int $blocked_events,
		int $critical_events,
		int $attack_sources
	): array {
		$blocked_events  = max( 0, $blocked_events );
		$critical_events = max( 0, $critical_events );
		$attack_sources  = max( 0, $attack_sources );

		if ( $blocked_events >= 10 ) {
			return array(
				'level'  => 'high',
				'reason' => 'high_blocked',
			);
		}

		if ( $critical_events >= 10 ) {
			return array(
				'level'  => 'high',
				'reason' => 'high_critical',
			);
		}

		if ( $blocked_events >= 5 && $attack_sources >= 5 ) {
			return array(
				'level'  => 'high',
				'reason' => 'high_distributed',
			);
		}

		if ( $blocked_events >= 3 ) {
			return array(
				'level'  => 'elevated',
				'reason' => 'elevated_blocked',
			);
		}

		if ( $critical_events >= 3 ) {
			return array(
				'level'  => 'elevated',
				'reason' => 'elevated_critical',
			);
		}

		return array(
			'level'  => 'normal',
			'reason' => 'normal',
		);
	}

	/**
	 * Calculate the current threat level from recent security metrics.
	 *
	 * @param int $blocked_events  Number of blocked events.
	 * @param int $critical_events Number of events with risk score 90 or higher.
	 * @param int $attack_sources  Number of distinct attack sources.
	 * @return string
	 */
	public static function calculate_level(
		int $blocked_events,
		int $critical_events,
		int $attack_sources
	): string {
		$assessment = self::assessment(
			$blocked_events,
			$critical_events,
			$attack_sources
		);

		return $assessment['level'];
	}
	/**
	 * Calculate the effective firewall block threshold.
	 *
	 * @param int    $base_threshold Configured block threshold.
	 * @param string $level          Current threat level.
	 * @return int
	 */
	public static function block_threshold( int $base_threshold, string $level ): int {
		$base_threshold = max( 0, min( 100, $base_threshold ) );

		if ( 'high' === $level ) {
			$base_threshold -= 20;
		} elseif ( 'elevated' === $level ) {
			$base_threshold -= 10;
		}

		return max(
			self::MIN_BLOCK_THRESHOLD,
			$base_threshold
		);
	}

	/**
	 * Calculate the effective request rate limit.
	 *
	 * @param int    $base_limit Configured request limit.
	 * @param string $level      Current threat level.
	 * @return int
	 */
	public static function rate_limit( int $base_limit, string $level ): int {
		$base_limit = max( self::MIN_RATE_LIMIT, $base_limit );

		if ( 'high' === $level ) {
			$base_limit = (int) floor( $base_limit * 0.50 );
		} elseif ( 'elevated' === $level ) {
			$base_limit = (int) floor( $base_limit * 0.75 );
		}

		return max(
			self::MIN_RATE_LIMIT,
			$base_limit
		);
	}
}
