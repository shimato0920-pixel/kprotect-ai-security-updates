<?php
/**
 * IP blocker for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles temporary IP blocking.
 */
final class KProtect_IP_Blocker {

	/**
	 * Security event logger.
	 *
	 * @var KProtect_Logger
	 */
	private KProtect_Logger $logger;
	public function __construct( KProtect_Logger $logger ) {
		$this->logger = $logger; }

	public function is_blocked( string $ip ): bool {
		global $wpdb;
		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) || KProtect_Utils::is_trusted( $ip ) ) {
			return false; }
		foreach ( KProtect_Utils::lines( (string) KProtect_Utils::settings()['blocked_ips'] ) as $rule ) {
			if ( KProtect_Utils::ip_matches( $ip, $rule ) ) {
				return true; }
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Firewall decisions must use current KProtect block state; query is prepared and bounded.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT id, expires_at FROM %i WHERE ip_hash = %s AND active = 1 LIMIT 1',
				$wpdb->prefix . 'kprotect_blocks',
				KProtect_Utils::ip_hash( $ip )
			)
		);
		if ( ! $row ) {
			return false; }
		if ( ! empty( $row->expires_at ) && strtotime( $row->expires_at . ' UTC' ) <= time() ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Expired block is synchronously deactivated so the firewall decision is immediately correct.
			$wpdb->update( $wpdb->prefix . 'kprotect_blocks', array( 'active' => 0 ), array( 'id' => (int) $row->id ), array( '%d' ), array( '%d' ) );
			return false;
		}
		return true;
	}

	public function block( string $ip, string $reason, int $minutes ): void {
		global $wpdb;
		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) || KProtect_Utils::is_trusted( $ip ) ) {
			return; }
		$settings        = KProtect_Utils::settings();
		$previous_blocks = KProtect_Adaptive_Protection::previous_blocks( $ip );
		$minutes         = KProtect_Adaptive_Protection::block_minutes( $minutes, $previous_blocks );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Blocking is an immediate write to a KProtect-owned table and must not be cached.
		$wpdb->replace(
			$wpdb->prefix . 'kprotect_blocks',
			array(
				'ip_hash'    => KProtect_Utils::ip_hash( $ip ),
				'ip_address' => ! empty( $settings['log_ip_address'] ) ? $ip : '',
				'reason'     => substr( sanitize_text_field( $reason ), 0, 255 ),
				'created_at' => current_time( 'mysql', true ),
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + max( 1, $minutes ) * MINUTE_IN_SECONDS ),
				'active'     => 1,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d' )
		);
	}

	public function deny( int $status = 403 ): void {
		$status = in_array( $status, array( 403, 429 ), true ) ? $status : 403;
		status_header( $status );
		if ( 429 === $status ) {
			header( 'Retry-After: 60' );
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		$title = 429 === $status ? 'Too many requests' : 'Access denied';
		exit( '<!doctype html><html lang="ja"><meta charset="utf-8"><title>' . esc_html( $title ) . '</title><body><h1>' . esc_html( (string) $status . ' ' . $title ) . '</h1><p>KProtect AI Security により、このアクセスは拒否されました。</p></body></html>' );
	}
}
