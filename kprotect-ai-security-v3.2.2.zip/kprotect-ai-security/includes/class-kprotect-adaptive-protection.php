<?php
/**
 * Adaptive protection for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculates adaptive block durations for repeat offenders.
 */
final class KProtect_Adaptive_Protection {

	/**
	 * Maximum adaptive block duration in minutes.
	 */
	private const MAX_BLOCK_MINUTES = 1440;

	/**
	 * Lookback period for previous blocks in days.
	 */
	private const LOOKBACK_DAYS = 7;

	/**
	 * Calculate an adaptive block duration.
	 *
	 * @param int $base_minutes    Base block duration in minutes.
	 * @param int $previous_blocks Number of previous blocks.
	 * @return int
	 */
	public static function block_minutes( int $base_minutes, int $previous_blocks ): int {
		$base_minutes    = max( 1, $base_minutes );
		$previous_blocks = max( 0, $previous_blocks );

		if ( 0 === $previous_blocks ) {
			$multiplier = 1;
		} elseif ( 1 === $previous_blocks ) {
			$multiplier = 2;
		} elseif ( 2 === $previous_blocks ) {
			$multiplier = 6;
		} else {
			$multiplier = 24;
		}

		return min(
			self::MAX_BLOCK_MINUTES,
			$base_minutes * $multiplier
		);
	}

	/**
	 * Count previous blocking decisions for an IP.
	 *
	 * Only events that created a new block are counted. Requests rejected
	 * because an IP was already blocked are intentionally excluded.
	 *
	 * @param string $ip Client IP address.
	 * @return int
	 */
	public static function previous_blocks( string $ip ): int {
		global $wpdb;

		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) || KProtect_Utils::is_trusted( $ip ) ) {
			return 0;
		}

		$cutoff = gmdate(
			'Y-m-d H:i:s',
			time() - ( self::LOOKBACK_DAYS * DAY_IN_SECONDS )
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Adaptive protection requires current security-event history from the KProtect-owned log table.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i
				WHERE ip_hash = %s
				AND blocked = 1
				AND created_at >= %s
				AND event_type IN (%s, %s, %s)',
				$wpdb->prefix . 'kprotect_logs',
				KProtect_Utils::ip_hash( $ip ),
				$cutoff,
				'firewall',
				'rate_limit',
				'login_blocked'
			)
		);

		return max( 0, (int) $count );
	}
	/**
	 * Return the repeat-offender lookback period.
	 *
	 * @return int
	 */
	public static function lookback_days(): int {
		return self::LOOKBACK_DAYS;
	}

	/**
	 * Return the maximum adaptive block duration.
	 *
	 * @return int
	 */
	public static function max_block_minutes(): int {
		return self::MAX_BLOCK_MINUTES;
	}
}
