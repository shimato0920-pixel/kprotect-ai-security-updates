<?php
/**
 * Attack intelligence analytics for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_Attack_Intelligence {

	private const LOOKBACK_HOURS = 24;

	/**
	 * Return supported attack types.
	 *
	 * @return array<int, string>
	 */
	private static function supported_types(): array {
		return array(
			'code_execution',
			'webshell_probe',
			'sql_injection',
			'path_traversal',
			'xss',
			'sensitive_file',
		);
	}

	/**
	 * Return intelligence summary for all supported attack types.
	 *
	 * @return array<string, array{attack_events:int,attack_sources:int,critical_events:int,blocked_events:int}>
	 */
	public static function summary(): array {
		$summary = array();

		foreach ( self::supported_types() as $attack_type ) {
			$summary[ $attack_type ] = self::metrics( $attack_type );
		}

		return $summary;
	}

	/**
	 * Return 24-hour metrics for an attack type.
	 *
	 * @return array{attack_events:int,attack_sources:int,critical_events:int,blocked_events:int}
	 */
	public static function metrics( string $attack_type ): array {
		global $wpdb;

		$attack_type = sanitize_key( $attack_type );

		if ( ! in_array( $attack_type, self::supported_types(), true ) ) {
			return array(
				'attack_events'   => 0,
				'attack_sources'  => 0,
				'critical_events' => 0,
				'blocked_events'  => 0,
			);
		}

		$cutoff = gmdate(
			'Y-m-d H:i:s',
			time() - ( self::LOOKBACK_HOURS * HOUR_IN_SECONDS )
		);

		$pattern = '%"attack_type:' . $attack_type . '"%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only analytics query against the KProtect-owned security log table.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT
					COUNT(*) AS attack_events,
					COUNT(DISTINCT NULLIF(ip_hash, \'\')) AS attack_sources,
					SUM(CASE WHEN risk_score >= 90 THEN 1 ELSE 0 END) AS critical_events,
					SUM(CASE WHEN blocked = 1 THEN 1 ELSE 0 END) AS blocked_events
				FROM %i
				WHERE created_at >= %s
				AND event_type = %s
				AND reasons LIKE %s',
				$wpdb->prefix . 'kprotect_logs',
				$cutoff,
				'firewall',
				$pattern
			)
		);

		return array(
			'attack_events'   => max( 0, (int) ( $row->attack_events ?? 0 ) ),
			'attack_sources'  => max( 0, (int) ( $row->attack_sources ?? 0 ) ),
			'critical_events' => max( 0, (int) ( $row->critical_events ?? 0 ) ),
			'blocked_events'  => max( 0, (int) ( $row->blocked_events ?? 0 ) ),
		);
	}
}
