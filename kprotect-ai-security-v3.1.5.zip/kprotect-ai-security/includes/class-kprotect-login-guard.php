<?php
/**
 * Login protection for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Protects the WordPress login process.
 */
final class KProtect_Login_Guard {

	/**
	 * Security event logger.
	 *
	 * @var KProtect_Logger
	 */
	private KProtect_Logger $logger;

	/**
	 * IP address blocker.
	 *
	 * @var KProtect_IP_Blocker
	 */
	private KProtect_IP_Blocker $blocker;

	/**
	 * Constructor.
	 *
	 * @param KProtect_Logger     $logger  Security event logger.
	 * @param KProtect_IP_Blocker $blocker IP address blocker.
	 */
	public function __construct( KProtect_Logger $logger, KProtect_IP_Blocker $blocker ) {
		$this->logger  = $logger;
		$this->blocker = $blocker;
	}

	/**
	 * Evaluate failed-login counters without side effects.
	 *
	 * @param int                 $ip_count       Failed attempts from the current IP.
	 * @param int                 $username_count Failed attempts against the submitted username.
	 * @param array<string,mixed> $settings       KProtect settings.
	 * @return array<string,mixed>
	 */
	public static function evaluate_attempt(
		int $ip_count,
		int $username_count,
		array $settings
	): array {
		$threshold = max(
			2,
			(int) ( $settings['login_failures'] ?? 5 )
		);

		$account_threshold = $threshold + 3;

		return array(
			'block_ip'          => $ip_count >= $threshold,
			'account_attack'    => $username_count >= $account_threshold,
			'ip_count'          => max( 0, $ip_count ),
			'username_count'    => max( 0, $username_count ),
			'ip_threshold'      => $threshold,
			'account_threshold' => $account_threshold,
		);
	}
	/**
	 * Check whether a login request should be allowed.
	 *
	 * @param mixed  $user     Current authentication result.
	 * @param string $username Submitted username.
	 * @param string $password Submitted password.
	 * @return mixed
	 */
	public function check( $user, string $username, string $password ) {
		$ip = KProtect_Utils::client_ip();

		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) ) {
			return $user;
		}

		if ( ! KProtect_Utils::is_trusted( $ip ) && $this->blocker->is_blocked( $ip ) ) {
			return new WP_Error(
				'kprotect_blocked',
				__(
					'セキュリティ保護により、一時的にログインできません。',
					'kprotect-ai-security'
				)
			);
		}

		return $user;
	}

	/**
	 * Record a failed login attempt.
	 *
	 * @param string $username Submitted username.
	 * @return void
	 */
	public function failed( string $username ): void {
		$settings = KProtect_Utils::settings();
		$ip       = KProtect_Utils::client_ip();

		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) || KProtect_Utils::is_trusted( $ip ) ) {
			return;
		}

		$ttl = max(
			5,
			(int) $settings['login_block_minutes']
		) * MINUTE_IN_SECONDS;

		$ip_key   = 'kprotect_login_' . substr( KProtect_Utils::ip_hash( $ip ), 0, 32 );
		$ip_count = (int) get_transient( $ip_key ) + 1;

		set_transient(
			$ip_key,
			$ip_count,
			$ttl
		);

		$username_count = 0;
		$username_key   = self::username_counter_key( $username );

		if ( '' !== $username_key ) {
			$username_count = (int) get_transient( $username_key ) + 1;

			set_transient(
				$username_key,
				$username_count,
				$ttl
			);
		}

		$decision = self::evaluate_attempt(
			$ip_count,
			$username_count,
			$settings
		);

		$reasons = array(
			'failed_login',
			'attempt_' . $ip_count,
		);

		if ( $decision['account_attack'] ) {
			$reasons[] = 'distributed_account_attack';
		}

		$risk = min(
			95,
			20 + $ip_count * 12
		);

		if ( $decision['account_attack'] ) {
			$risk = max( 80, $risk );
		}

		$this->logger->log(
			'login_failed',
			$risk,
			$reasons,
			false,
			$ip
		);

		if ( $decision['block_ip'] ) {
			$this->blocker->block(
				$ip,
				'login_bruteforce',
				(int) $settings['login_block_minutes']
			);

			$this->logger->log(
				'login_blocked',
				95,
				array( 'login_bruteforce' ),
				true,
				$ip
			);
		}
	}

	public static function username_counter_key( string $username ): string {
		$username = strtolower( trim( $username ) );

		if ( '' === $username ) {
			return '';
		}

		$hash = hash_hmac(
			'sha256',
			$username,
			wp_salt( 'auth' )
		);

		return 'kprotect_login_user_' . substr( $hash, 0, 32 );
	}
	/**
	 * Clear the failed-login counter after a successful login.
	 *
	 * @param string  $user_login Authenticated username.
	 * @param WP_User $user       Authenticated WordPress user.
	 * @return void
	 */
	public function success( string $user_login, WP_User $user ): void {
		$ip = KProtect_Utils::client_ip();

		if ( KProtect_Utils::has_valid_client_ip( $ip ) ) {
			delete_transient(
				'kprotect_login_' . substr( KProtect_Utils::ip_hash( $ip ), 0, 32 )
			);
		}

		$username_key = self::username_counter_key( $user_login );

		if ( '' !== $username_key ) {
			delete_transient( $username_key );
		}
	}
}
