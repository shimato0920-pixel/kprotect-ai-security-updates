<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Installer {
	private const SCHEMA_VERSION = '2.1.1';
	public static function activate(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset       = $wpdb->get_charset_collate();
		$logs          = $wpdb->prefix . 'kprotect_logs';
		$blocks        = $wpdb->prefix . 'kprotect_blocks';
		$notifications = $wpdb->prefix . 'kprotect_notifications';
		$deliveries    = $wpdb->prefix . 'kprotect_delivery_history';
		$queue         = $wpdb->prefix . 'kprotect_notification_queue';

		$sql_logs = "CREATE TABLE {$logs} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			event_type varchar(50) NOT NULL,
			risk_score smallint(5) unsigned NOT NULL DEFAULT 0,
			ip_hash char(64) NOT NULL,
			ip_address varchar(45) NOT NULL DEFAULT '',
			request_method varchar(10) NOT NULL DEFAULT '',
			request_path text NOT NULL,
			reasons text NOT NULL,
			blocked tinyint(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY event_type (event_type),
			KEY ip_hash (ip_hash),
			KEY blocked (blocked),
			KEY created_blocked (created_at, blocked),
			KEY created_event (created_at, event_type),
			KEY created_risk (created_at, risk_score)
		) {$charset};";

		$sql_blocks = "CREATE TABLE {$blocks} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			ip_hash char(64) NOT NULL,
			ip_address varchar(45) NOT NULL DEFAULT '',
			reason varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			expires_at datetime NULL,
			active tinyint(1) NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY ip_hash (ip_hash),
			KEY expires_at (expires_at),
			KEY active (active)
		) {$charset};";

		$sql_notifications = "CREATE TABLE {$notifications} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			event_type varchar(50) NOT NULL,
			severity varchar(20) NOT NULL DEFAULT 'low',
			title varchar(190) NOT NULL,
			message text NOT NULL,
			risk_score smallint(5) unsigned NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'unread',
			occurrences bigint(20) unsigned NOT NULL DEFAULT 1,
			feedback_status varchar(20) NOT NULL DEFAULT '',
			feedback_note text NOT NULL,
			feedback_updated_at datetime NULL,
			fingerprint char(64) NOT NULL,
			email_sent tinyint(1) NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY fingerprint (fingerprint),
			KEY updated_at (updated_at),
			KEY status (status),
			KEY severity (severity),
			KEY feedback_status (feedback_status),
			KEY status_updated (status, updated_at),
			KEY risk_updated (risk_score, updated_at)
		) {$charset};";

		$sql_queue = "CREATE TABLE {$queue} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			available_at datetime NOT NULL,
			channel varchar(20) NOT NULL,
			event_type varchar(50) NOT NULL,
			risk_score smallint(5) unsigned NOT NULL DEFAULT 0,
			reasons longtext NOT NULL,
			fingerprint char(64) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			attempts smallint(5) unsigned NOT NULL DEFAULT 0,
			occurrences bigint(20) unsigned NOT NULL DEFAULT 1,
			is_test tinyint(1) NOT NULL DEFAULT 0,
			last_error varchar(500) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY status_available (status, available_at),
			KEY fingerprint_status (fingerprint, status)
		) {$charset};";

		$sql_deliveries = "CREATE TABLE {$deliveries} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			channel varchar(20) NOT NULL,
			event_type varchar(50) NOT NULL,
			risk_score smallint(5) unsigned NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL,
			http_code smallint(5) unsigned NOT NULL DEFAULT 0,
			duration_ms int(10) unsigned NOT NULL DEFAULT 0,
			error_message varchar(500) NOT NULL DEFAULT '',
			attempts smallint(5) unsigned NOT NULL DEFAULT 1,
			is_test tinyint(1) NOT NULL DEFAULT 0,
			payload longtext NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY channel_status (channel, status),
			KEY status_created (status, created_at)
		) {$charset};";

		dbDelta( $sql_logs );
		dbDelta( $sql_blocks );
		dbDelta( $sql_notifications );
		dbDelta( $sql_deliveries );
		dbDelta( $sql_queue );

		$existing_settings = get_option( 'kprotect_settings', array() );
		$merged_settings   = wp_parse_args( is_array( $existing_settings ) ? $existing_settings : array(), self::defaults() );
		update_option( 'kprotect_settings', $merged_settings, false );

		$previous_version = (string) get_option( 'kprotect_version', '' );
		if ( KPROTECT_VERSION !== $previous_version ) {
			$history   = (array) get_option( 'kprotect_upgrade_history', array() );
			$history[] = array(
				'from'       => $previous_version,
				'to'         => KPROTECT_VERSION,
				'updated_at' => current_time( 'mysql' ),
			);
			$history   = array_slice( $history, -20 );
			update_option( 'kprotect_upgrade_history', $history, false );
		}
		update_option( 'kprotect_schema_version', self::SCHEMA_VERSION, false );
		update_option( 'kprotect_version', KPROTECT_VERSION, false );
		if ( ! wp_next_scheduled( 'kprotect_daily_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'kprotect_daily_cleanup' );
		}
		if ( ! wp_next_scheduled( 'kprotect_daily_integrity_scan' ) ) {
			wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'daily', 'kprotect_daily_integrity_scan' );
		}
	}

	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'kprotect_daily_cleanup' );
		wp_clear_scheduled_hook( 'kprotect_daily_integrity_scan' );
		wp_clear_scheduled_hook( 'kprotect_process_notification_queue' );
	}

	public static function defaults(): array {
		return array(
			'enabled'                     => 1,
			'block_threshold'             => 80,
			'log_threshold'               => 25,
			'block_minutes'               => 60,
			'rate_limit_requests'         => 120,
			'rate_limit_window'           => 60,
			'login_failures'              => 5,
			'login_block_minutes'         => 60,
			'disable_xmlrpc'              => 1,
			'log_ip_address'              => 0,
			'trusted_ips'                 => '',
			'blocked_ips'                 => '',
			'excluded_paths'              => '',
			'log_retention_days'          => 30,
			'admin_notifications'         => 1,
			'notification_threshold'      => 75,
			'notification_retention_days' => 30,
			'email_notifications'         => 0,
			'email_threshold'             => 90,
			'email_cooldown_minutes'      => 60,
			'email_event_types'           => array_keys( KProtect_Notification_Rules::event_types() ),
			'notification_email'          => (string) get_option( 'admin_email' ),
			'discord_notifications'       => 0,
			'discord_threshold'           => 90,
			'discord_cooldown_minutes'    => 60,
			'discord_event_types'         => array_keys( KProtect_Notification_Rules::event_types() ),
			'discord_webhook_url'         => '',
			'slack_notifications'         => 0,
			'slack_threshold'             => 90,
			'slack_cooldown_minutes'      => 60,
			'slack_event_types'           => array_keys( KProtect_Notification_Rules::event_types() ),
			'slack_webhook_url'           => '',
			'rest_api_enabled'            => 0,
			'webhook_notifications'       => 0,
			'webhook_threshold'           => 90,
			'webhook_cooldown_minutes'    => 60,
			'webhook_event_types'         => array_keys( KProtect_Notification_Rules::event_types() ),
			'webhook_url'                 => '',
			'webhook_secret'              => '',
		);
	}
}
