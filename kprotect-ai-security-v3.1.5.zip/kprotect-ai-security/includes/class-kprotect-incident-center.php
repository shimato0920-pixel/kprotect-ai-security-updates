<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/** Groups related security logs into explainable incidents without adding a new DB table. */
final class KProtect_Incident_Center {
	/** @return array<int,array<string,mixed>> */
	public function recent( int $hours = 24, int $limit = 50 ): array {
		global $wpdb;
		$hours = max( 1, min( 168, $hours ) );
		$limit = max( 1, min( 200, $limit ) );
		$table = $wpdb->prefix . 'kprotect_logs';
		$since = gmdate( 'Y-m-d H:i:s', time() - ( $hours * HOUR_IN_SECONDS ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Incident grouping requires current KProtect security-log rows; query is read-only, prepared, date-bounded, and hard-limited.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id,created_at,event_type,risk_score,ip_hash,ip_address,request_path,reasons,blocked FROM %i WHERE created_at >= %s ORDER BY id ASC LIMIT 5000',
				$table,
				$since
			),
			ARRAY_A
		);
		return array_slice( self::group( is_array( $rows ) ? $rows : array() ), 0, $limit );
	}

	/** @param array<int,array<string,mixed>> $rows @return array<int,array<string,mixed>> */
	public static function group( array $rows, int $window_minutes = 30 ): array {
		$groups = array();
		$window = max( 5, $window_minutes ) * 60;
		foreach ( $rows as $row ) {
			$time = strtotime( (string) ( $row['created_at'] ?? '' ) ) ?: 0;
			$type = self::family( (string) ( $row['event_type'] ?? '' ) );
			$ip   = (string) ( $row['ip_hash'] ?? '' );
			$key  = $type . '|' . $ip;
			if ( ! isset( $groups[ $key ] ) || ( $time - (int) $groups[ $key ]['last_ts'] ) > $window ) {
				$key           .= '|' . $time;
				$groups[ $key ] = array(
					'id'         => substr( hash( 'sha256', $key ), 0, 12 ),
					'family'     => $type,
					'label'      => self::label( $type ),
					'first_seen' => (string) $row['created_at'],
					'last_seen'  => (string) $row['created_at'],
					'last_ts'    => $time,
					'events'     => 0,
					'max_risk'   => 0,
					'blocked'    => 0,
					'ip'         => ! empty( $row['ip_address'] ) ? (string) $row['ip_address'] : substr( $ip, 0, 12 ) . '…',
					'paths'      => array(),
					'reasons'    => array(),
				);
			}
			++$groups[ $key ]['events'];
			$groups[ $key ]['max_risk']  = max( (int) $groups[ $key ]['max_risk'], (int) ( $row['risk_score'] ?? 0 ) );
			$groups[ $key ]['blocked']  += ! empty( $row['blocked'] ) ? 1 : 0;
			$groups[ $key ]['last_seen'] = (string) $row['created_at'];
			$groups[ $key ]['last_ts']   = $time;
			$path                        = (string) ( $row['request_path'] ?? '' );
			if ( $path && count( $groups[ $key ]['paths'] ) < 3 ) {
				$groups[ $key ]['paths'][ $path ] = $path; }
			foreach ( (array) json_decode( (string) ( $row['reasons'] ?? '[]' ), true ) as $reason ) {
				if ( count( $groups[ $key ]['reasons'] ) < 5 ) {
					$groups[ $key ]['reasons'][ (string) $reason ] = (string) $reason; }
			}
		}
		$out = array_values( $groups );
		foreach ( $out as &$item ) {
			$item['paths']   = array_values( $item['paths'] );
			$item['reasons'] = array_values( $item['reasons'] );
			$item['status']  = ( time() - (int) $item['last_ts'] <= $window ) ? 'active' : 'quiet';
		}
		unset( $item );
		usort( $out, static fn( $a, $b ) => ( (int) $b['last_ts'] <=> (int) $a['last_ts'] ) );
		return $out;
	}

	private static function family( string $type ): string {
		if ( str_starts_with( $type, 'login' ) ) {
			return 'login_attack'; }
		if ( str_contains( $type, 'integrity' ) ) {
			return 'file_change'; }
		if ( str_contains( $type, 'malware' ) ) {
			return 'suspicious_file'; }
		return $type ?: 'request_risk';
	}
	private static function label( string $family ): string {
		return array(
			'login_attack'    => 'ログイン攻撃',
			'file_change'     => '重要ファイル変更',
			'suspicious_file' => '不審ファイル',
			'firewall'        => '不審リクエスト',
			'rate_limit'      => '大量アクセス',
		)[ $family ] ?? $family;
	}
}
