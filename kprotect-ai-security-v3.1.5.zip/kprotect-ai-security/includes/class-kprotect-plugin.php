<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_Plugin {

	private static ?self $instance = null;

	public static function instance(): self {
		return self::$instance ??= new self();
	}

	public function run(): void {
		if ( get_option( 'kprotect_version' ) !== KPROTECT_VERSION ) {
			KProtect_Installer::activate();
		}

		$logger         = new KProtect_Logger();
		$blocker        = new KProtect_IP_Blocker( $logger );
		$firewall       = new KProtect_Firewall( $logger, $blocker );
		$login          = new KProtect_Login_Guard( $logger, $blocker );
		$scanner        = new KProtect_Integrity_Scanner( $logger );
		$full_integrity = new KProtect_File_Integrity_Manager( $logger );
		$auditor        = new KProtect_Security_Auditor();
		$assistant      = new KProtect_Security_Assistant( $auditor );
		$report         = new KProtect_Security_Report();
		$incidents      = new KProtect_Incident_Center();
		$analytics      = new KProtect_Dashboard_Analytics();
		$notifications  = new KProtect_Notification_Center();
		$deliveries     = new KProtect_Delivery_History();
		$malware        = new KProtect_Malware_Scanner( $logger );
		$maintenance    = new KProtect_Maintenance_Manager();

		$rest_api = new KProtect_REST_API(
			$assistant,
			$report,
			$analytics,
			$full_integrity
		);

		add_action( 'rest_api_init', array( $rest_api, 'register_routes' ) );

		add_action( 'init', array( $firewall, 'inspect' ), 0 );
		add_filter( 'xmlrpc_enabled', array( $firewall, 'disable_xmlrpc' ), PHP_INT_MAX );

		add_filter( 'authenticate', array( $login, 'check' ), 5, 3 );
		add_action( 'wp_login_failed', array( $login, 'failed' ) );
		add_action( 'wp_login', array( $login, 'success' ), 10, 2 );

		add_action( 'kprotect_daily_cleanup', array( $maintenance, 'run_cleanup' ) );
		add_action( 'kprotect_daily_integrity_scan', array( $scanner, 'scan' ) );

		$queue = new KProtect_Notification_Queue();

		add_action(
			'kprotect_process_notification_queue',
			array( $queue, 'process' )
		);

		if ( ! wp_next_scheduled( 'kprotect_daily_cleanup' ) ) {
			wp_schedule_event(
				time() + HOUR_IN_SECONDS,
				'daily',
				'kprotect_daily_cleanup'
			);
		}

		if ( ! wp_next_scheduled( 'kprotect_daily_integrity_scan' ) ) {
			wp_schedule_event(
				time() + ( 2 * HOUR_IN_SECONDS ),
				'daily',
				'kprotect_daily_integrity_scan'
			);
		}

		$updater = new KProtect_GitHub_Updater( KPROTECT_FILE );
		$updater->hooks();

		if ( is_admin() ) {
			(
				new KProtect_Admin(
					$logger,
					$scanner,
					$full_integrity,
					$auditor,
					$malware,
					$assistant,
					$incidents,
					$analytics,
					$notifications,
					$deliveries,
					$report,
					$maintenance
				)
			)->hooks();
		}
	}
}
