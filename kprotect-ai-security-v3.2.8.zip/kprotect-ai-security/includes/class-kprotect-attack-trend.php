<?php
/**
 * Attack-type trend protection for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies distributed attack-type trend protection.
 */
final class KProtect_Attack_Trend {

	/**
	 * Minimum effective firewall block threshold.
	 */
	private const MIN_BLOCK_THRESHOLD = 40;

	/**
	 * Trend cache lifetime in seconds.
	 */
	private const CACHE_TTL = 60;

	/**
	 * Trend lookback window in minutes.
	 */
	private const LOOKBACK_MINUTES = 15;

	/**
	 * Supported attack types.
	 *
	 * @return array<int, string>
	 */
	private static function protected_types(): array {
		return array(
			'code_execution',
			'webshell_probe',
			'sql_injection',
			'path_traversal',
			'xss',
			'sensitive_file',
		);
	}

	/**
	 * Determine whether an attack type is protected by trend detection.
	 *
	 * @param string $attack_type Attack type.
	 * @return bool
	 */
	private static function is_protected_type( string $attack_type ): bool {
		return in_array(
			sanitize_key( $attack_type ),
			self::protected_types(),
			true
		);
	}

	/**
	 * Calculate the attack trend level.
	 *
	 * @param int $events  Number of matching attack events.
	 * @param int $sources Number of distinct attack sources.
	 * @return string
	 */
	public static function calculate_level( int $events, int $sources ): string {
		$events  = max( 0, $events );
		$sources = max( 0, $sources );

		if ( $events >= 10 && $sources >= 5 ) {
			return 'distributed';
		}

		if ( $events >= 5 && $sources >= 3 ) {
			return 'surge';
		}

		return 'normal';
	}

	/**
	 * Return the current trend level for an attack type.
	 *
	 * @param string $attack_type Attack type.
	 * @return string
	 */
	public static function current_level( string $attack_type ): string {
		$attack_type = sanitize_key( $attack_type );

		if ( ! self::is_protected_type( $attack_type ) ) {
			return 'normal';
		}

		$cache_key = 'kprotect_attack_trend_' . $attack_type;
		$cached    = get_transient( $cache_key );

		if (
			is_string( $cached ) &&
			in_array( $cached, array( 'normal', 'surge', 'distributed' ), true )
		) {
			return $cached;
		}

		$metrics = self::recent_metrics( $attack_type );
		$level   = self::calculate_level(
			$metrics['attack_events'],
			$metrics['attack_sources']
		);

		set_transient(
			$cache_key,
			$level,
			self::CACHE_TTL
		);

		return $level;
	}

	/**
	 * Return recent metrics for one attack type.
	 *
	 * @param string $attack_type Attack type.
	 * @return array{attack_events:int,attack_sources:int}
	 */
	public static function recent_metrics( string $attack_type ): array {
		global $wpdb;

		$attack_type = sanitize_key( $attack_type );

		if ( ! self::is_protected_type( $attack_type ) ) {
			return array(
				'attack_events'  => 0,
				'attack_sources' => 0,
			);
		}

		$cutoff = gmdate(
			'Y-m-d H:i:s',
			time() - ( self::LOOKBACK_MINUTES * MINUTE_IN_SECONDS )
		);

		$metadata_pattern = '%"attack_type:' . $attack_type . '"%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Attack trend metrics are read from the KProtect-owned log table and cached by current_level().
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT
					COUNT(*) AS attack_events,
					COUNT(DISTINCT NULLIF(ip_hash, \'\')) AS attack_sources
				FROM %i
				WHERE created_at >= %s
				AND event_type = %s
				AND reasons LIKE %s',
				$wpdb->prefix . 'kprotect_logs',
				$cutoff,
				'firewall',
				$metadata_pattern
			)
		);

		return array(
			'attack_events'  => max(
				0,
				(int) ( $row->attack_events ?? 0 )
			),
			'attack_sources' => max(
				0,
				(int) ( $row->attack_sources ?? 0 )
			),
		);
	}

	/**
	 * Clear all attack trend caches.
	 *
	 * @return void
	 */
	public static function clear_cache(): void {
		foreach ( self::protected_types() as $attack_type ) {
			delete_transient(
				'kprotect_attack_trend_' . $attack_type
			);
		}
	}

	/**
	 * Adjust the effective block threshold for an attack trend.
	 *
	 * @param int    $block_threshold Effective block threshold.
	 * @param string $level           Attack trend level.
	 * @param string $attack_type     Classified attack type.
	 * @return int
	 */
	public static function block_threshold(
		int $block_threshold,
		string $level,
		string $attack_type
	): int {
		$block_threshold = max( 0, min( 100, $block_threshold ) );
		$level           = sanitize_key( $level );
		$attack_type     = sanitize_key( $attack_type );

		if ( ! self::is_protected_type( $attack_type ) ) {
			return $block_threshold;
		}

		if ( 'distributed' === $level ) {
			$block_threshold -= 10;
		} elseif ( 'surge' === $level ) {
			$block_threshold -= 5;
		}

		return max(
			self::MIN_BLOCK_THRESHOLD,
			$block_threshold
		);
	}
}
