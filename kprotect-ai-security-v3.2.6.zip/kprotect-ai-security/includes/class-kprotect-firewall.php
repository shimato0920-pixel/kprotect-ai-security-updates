<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_Firewall {
	private KProtect_Logger $logger;
	private KProtect_IP_Blocker $blocker;
	private KProtect_Detector $detector;
	private KProtect_Rate_Limiter $rate;

	public function __construct( KProtect_Logger $logger, KProtect_IP_Blocker $blocker ) {
		$this->logger   = $logger;
		$this->blocker  = $blocker;
		$this->detector = new KProtect_Detector();
		$this->rate     = new KProtect_Rate_Limiter();
	}

	public function inspect(): void {
		$settings = KProtect_Utils::settings();

		if (
			empty( $settings['enabled'] ) ||
			( defined( 'WP_CLI' ) && WP_CLI ) ||
			wp_doing_cron()
		) {
			return;
		}

		$ip = KProtect_Utils::client_ip();

		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) ) {
			return;
		}

		if ( KProtect_Utils::is_trusted( $ip ) ) {
			return;
		}

		if ( KProtect_Utils::is_excluded_path() ) {
			return;
		}

		$is_administrator = current_user_can( 'manage_options' );

		if ( ! $is_administrator && $this->blocker->is_blocked( $ip ) ) {
			$this->logger->log(
				'blocked_ip',
				100,
				array( 'active_block' ),
				true,
				$ip
			);
			$this->blocker->deny();
		}

		$threat_level = $is_administrator
			? 'normal'
			: KProtect_Threat_Level::current_level();

		if ( ! $is_administrator && $this->rate->hit( $ip, $threat_level ) ) {
			$this->blocker->block(
				$ip,
				'rate_limit',
				(int) $settings['block_minutes']
			);
			$this->logger->log(
				'rate_limit',
				90,
				array( 'too_many_requests' ),
				true,
				$ip
			);
			$this->blocker->deny( 429 );
		}

		$result   = $this->detector->inspect();
		$decision = self::evaluate_result(
			$result,
			$settings,
			$is_administrator,
			$threat_level
		);

		if ( $decision['block'] ) {
			$this->blocker->block(
				$ip,
				implode( ',', $decision['reasons'] ),
				(int) $settings['block_minutes']
			);

			$this->logger->log(
				'firewall',
				$decision['score'],
				self::log_reasons( $decision ),
				true,
				$ip
			);

			$this->blocker->deny();
		}

		if ( $decision['log'] ) {
			$this->logger->log(
				'firewall',
				$decision['score'],
				self::log_reasons( $decision ),
				false,
				$ip
			);
		}
	}

	public static function evaluate_result(
		array $result,
		array $settings,
		bool $is_administrator,
		string $threat_level = 'normal'
	): array {
		$score   = max( 0, min( 100, (int) ( $result['score'] ?? 0 ) ) );
		$reasons = array_values(
			array_map(
				'strval',
				(array) ( $result['reasons'] ?? array() )
			)
		);
		$bot     = sanitize_key( (string) ( $result['bot'] ?? 'browser' ) );

		$log_threshold = max(
			0,
			min( 100, (int) ( $settings['log_threshold'] ?? 25 ) )
		);

		$block_threshold = KProtect_Threat_Level::block_threshold(
			max(
				0,
				min( 100, (int) ( $settings['block_threshold'] ?? 80 ) )
			),
			$threat_level
		);

		if ( '' !== $bot && 'browser' !== $bot ) {
			$client_reason = 'client:' . $bot;

			if ( ! in_array( $client_reason, $reasons, true ) ) {
				$reasons[] = $client_reason;
			}
		}

		$should_log   = $score >= $log_threshold;
		$should_block = ! $is_administrator && $score >= $block_threshold;

		if ( $is_administrator && $should_log ) {
			if ( ! in_array( 'administrator_session', $reasons, true ) ) {
				$reasons[] = 'administrator_session';
			}
		}

		$classification = KProtect_Attack_Classifier::classify(
			$reasons,
			$score
		);

		return array(
			'score'             => $score,
			'reasons'           => $reasons,
			'log'               => $should_log,
			'block'             => $should_block,
			'log_threshold'     => $log_threshold,
			'block_threshold'   => $block_threshold,
			'attack_type'       => $classification['type'],
			'attack_risk'       => $classification['risk'],
			'attack_confidence' => $classification['confidence'],
		);
	}

	/**
	 * Build reasons for firewall log storage.
	 *
	 * @param array $decision Firewall decision.
	 * @return array
	 */
	public static function log_reasons( array $decision ): array {
		$reasons = array_values(
			array_map(
				'strval',
				(array) ( $decision['reasons'] ?? array() )
			)
		);

		$type = sanitize_key(
			(string) ( $decision['attack_type'] ?? 'unknown' )
		);

		if ( '' === $type ) {
			$type = 'unknown';
		}

		$risk = sanitize_key(
			(string) ( $decision['attack_risk'] ?? 'low' )
		);

		if ( ! in_array( $risk, array( 'low', 'medium', 'high', 'critical' ), true ) ) {
			$risk = 'low';
		}

		$confidence = max(
			0,
			min(
				100,
				(int) ( $decision['attack_confidence'] ?? 0 )
			)
		);

		$metadata = array(
			'attack_type:' . $type,
			'attack_risk:' . $risk,
			'attack_confidence:' . $confidence,
		);

		foreach ( $metadata as $reason ) {
			if ( ! in_array( $reason, $reasons, true ) ) {
				$reasons[] = $reason;
			}
		}

		return $reasons;
	}

	public function disable_xmlrpc( bool $enabled ): bool {
		return ! empty( KProtect_Utils::settings()['disable_xmlrpc'] )
			? false
			: $enabled;
	}
}
