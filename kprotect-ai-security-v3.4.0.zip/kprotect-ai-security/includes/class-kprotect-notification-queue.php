<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_Notification_Queue {
	private const STATE_OPTION = 'kprotect_queue_runtime_state';
	private const LOG_OPTION   = 'kprotect_queue_process_log';
	private const CACHE_GROUP  = 'kprotect_notification_queue';
	private const CACHE_TTL    = 30;

	private function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'kprotect_notification_queue';
	}

	private function clear_cache(): void {
		wp_cache_delete( 'pending_count', self::CACHE_GROUP );
		wp_cache_delete( 'stats', self::CACHE_GROUP );
	}

	/**
	 * Return the notification cooldown in seconds.
	 */
	public static function cooldown_seconds(): int {
		return 30 * MINUTE_IN_SECONDS;
	}

	/**
	 * Determine whether a sent notification is still inside the cooldown.
	 */
	public static function is_within_cooldown(
		int $sent_timestamp,
		int $current_timestamp,
		int $cooldown
	): bool {
		if ( $sent_timestamp <= 0 || $current_timestamp <= 0 ) {
			return false;
		}

		$cooldown = max( MINUTE_IN_SECONDS, $cooldown );

		return $sent_timestamp >= ( $current_timestamp - $cooldown );
	}

	/**
	 * Build the aggregate values for an event suppressed by cooldown.
	 *
	 * @param array<string,mixed> $recent_sent Existing sent queue row.
	 * @return array{occurrences:int,risk_score:int,cooldown_hits:int}
	 */
	public static function cooldown_aggregate( array $recent_sent, int $score ): array {
		return array(
			'occurrences'   => max( 0, (int) ( $recent_sent['occurrences'] ?? 0 ) ) + 1,
			'risk_score'    => max( (int) ( $recent_sent['risk_score'] ?? 0 ), max( 0, min( 100, $score ) ) ),
			'cooldown_hits' => max( 0, (int) ( $recent_sent['cooldown_hits'] ?? 0 ) ) + 1,
		);
	}

	public function enqueue( string $channel, string $event_type, int $score, array $reasons, bool $is_test = false ): int {
		global $wpdb;

		$channel     = sanitize_key( $channel );
		$event_type  = sanitize_key( $event_type );
		$score       = max( 0, min( 100, $score ) );
		$reasons     = array_values( array_map( 'sanitize_text_field', $reasons ) );
		$fingerprint = hash( 'sha256', $channel . '|' . KProtect_Notification_Center::fingerprint( $event_type, $reasons ) );

		$cooldown = max(
			MINUTE_IN_SECONDS,
			(int) apply_filters(
				'kprotect_notification_queue_cooldown',
				self::cooldown_seconds(),
				$channel,
				$event_type,
				$score,
				$reasons,
				$is_test
			)
		);

		$cooldown_since = gmdate(
			'Y-m-d H:i:s',
			time() - $cooldown
		);

		// Connection tests should always be delivered when explicitly requested.
		if ( ! $is_test ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Queue deduplication must inspect current KProtect-owned delivery state.
			$recent_sent = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, occurrences, risk_score, cooldown_hits FROM %i
					WHERE fingerprint = %s
					AND status = 'sent'
					AND updated_at >= %s
					ORDER BY updated_at DESC
					LIMIT 1",
					$this->table(),
					$fingerprint,
					$cooldown_since
				),
				ARRAY_A
			);

			if ( is_array( $recent_sent ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Updating KProtect queue aggregation state must be immediate.
				$wpdb->update(
					$this->table(),
					self::cooldown_aggregate( $recent_sent, $score ),
					array( 'id' => (int) $recent_sent['id'] ),
					array( '%d', '%d', '%d' ),
					array( '%d' )
				);

				$this->clear_cache();

				return (int) $recent_sent['id'];
			}
		}

		// Direct access is intentional because this is a KProtect-owned custom queue table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM %i WHERE fingerprint = %s AND status = 'pending' LIMIT 1",
				$this->table(),
				$fingerprint
			),
			ARRAY_A
		);

		if ( $existing ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
			$wpdb->update(
				$this->table(),
				array(
					'occurrences' => (int) $existing['occurrences'] + 1,
					'risk_score'  => max( (int) $existing['risk_score'], $score ),
					'updated_at'  => current_time( 'mysql', true ),
				),
				array( 'id' => (int) $existing['id'] ),
				array( '%d', '%d', '%s' ),
				array( '%d' )
			);
			$this->clear_cache();
			return (int) $existing['id'];
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
		$wpdb->insert(
			$this->table(),
			array(
				'created_at'    => current_time( 'mysql', true ),
				'updated_at'    => current_time( 'mysql', true ),
				'available_at'  => current_time( 'mysql', true ),
				'channel'       => $channel,
				'event_type'    => $event_type,
				'risk_score'    => $score,
				'reasons'       => wp_json_encode( $reasons ),
				'fingerprint'   => $fingerprint,
				'status'        => 'pending',
				'attempts'      => 0,
				'occurrences'   => 1,
				'cooldown_hits' => 0,
				'is_test'       => $is_test ? 1 : 0,
				'last_error'    => '',
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s' )
		);

		$this->clear_cache();
		if ( ! wp_next_scheduled( 'kprotect_process_notification_queue' ) ) {
			wp_schedule_single_event( time() + 10, 'kprotect_process_notification_queue' );
		}

		return (int) $wpdb->insert_id;
	}

	public function process( int $limit = 10 ): int {
		global $wpdb;

		$started     = microtime( true );
		$started_gmt = current_time( 'mysql', true );
		$limit       = max( 1, min( 50, $limit ) );

		// Direct access is intentional because this is a KProtect-owned custom queue table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM %i WHERE status = 'pending' AND available_at <= %s ORDER BY id ASC LIMIT %d",
				$this->table(),
				current_time( 'mysql', true ),
				$limit
			),
			ARRAY_A
		);

		$done    = 0;
		$success = 0;
		$failed  = 0;

		foreach ( $rows as $row ) {
			$id = (int) $row['id'];

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
			$wpdb->update(
				$this->table(),
				array( 'status' => 'processing' ),
				array( 'id' => $id ),
				array( '%s' ),
				array( '%d' )
			);

			$reasons = json_decode( (string) $row['reasons'], true );
			if ( ! is_array( $reasons ) ) {
				$reasons = array();
			}
			if ( (int) $row['occurrences'] > 1 ) {
				$reasons[] = 'aggregated_occurrences_' . (int) $row['occurrences'];
			}

			$result = $this->dispatch(
				(string) $row['channel'],
				(string) $row['event_type'],
				(int) $row['risk_score'],
				$reasons,
				! empty( $row['is_test'] )
			);

			if ( is_wp_error( $result ) ) {
				$attempts = (int) $row['attempts'] + 1;
				++$failed;
				$this->record_failure( $id, $attempts, $result->get_error_message() );
			} else {
				++$success;
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
				$wpdb->update(
					$this->table(),
					array(
						'status'     => 'sent',
						'attempts'   => (int) $row['attempts'] + 1,
						'updated_at' => current_time( 'mysql', true ),
					),
					array( 'id' => $id ),
					array( '%s', '%d', '%s' ),
					array( '%d' )
				);
			}

			++$done;
		}

		$this->clear_cache();
		$pending = $this->pending_count();
		if ( $pending > 0 && ! wp_next_scheduled( 'kprotect_process_notification_queue' ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, 'kprotect_process_notification_queue' );
		}

		$state = array(
			'last_run_gmt'  => $started_gmt,
			'processed'     => $done,
			'succeeded'     => $success,
			'failed'        => $failed,
			'pending_after' => $pending,
			'duration_ms'   => (int) round( ( microtime( true ) - $started ) * 1000 ),
		);
		update_option( self::STATE_OPTION, $state, false );
		$this->append_process_log( $state );

		return $done;
	}

	/**
	 * Return the retry delay for a failed queue delivery.
	 */
	public static function retry_delay_seconds( int $attempts ): int {
		$attempts = max( 1, $attempts );

		if ( $attempts >= 3 ) {
			return HOUR_IN_SECONDS;
		}

		return ( 5 ** $attempts ) * MINUTE_IN_SECONDS;
	}

	/**
	 * Determine whether automatic retries should stop.
	 */
	public static function should_stop_retrying( int $attempts ): bool {
		return $attempts >= 4;
	}

	/**
	 * Return the number of automatic retries remaining.
	 */
	public static function remaining_retries( int $attempts ): int {
		return max( 0, 4 - max( 0, $attempts ) );
	}

	private function record_failure( int $id, int $attempts, string $message ): void {
		global $wpdb;

		$data = array(
			'attempts'   => $attempts,
			'last_error' => wp_html_excerpt( $message, 500, '' ),
			'updated_at' => current_time( 'mysql', true ),
		);

		if ( self::should_stop_retrying( $attempts ) ) {
			$data['status'] = 'failed';
			$formats        = array( '%d', '%s', '%s', '%s' );
		} else {
			$delay                = self::retry_delay_seconds( $attempts );
			$data['status']       = 'pending';
			$data['available_at'] = gmdate( 'Y-m-d H:i:s', time() + $delay );
			$formats              = array( '%d', '%s', '%s', '%s', '%s' );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
		$wpdb->update(
			$this->table(),
			$data,
			array( 'id' => $id ),
			$formats,
			array( '%d' )
		);
	}

	private function append_process_log( array $state ): void {
		$logs = get_option( self::LOG_OPTION, array() );
		if ( ! is_array( $logs ) ) {
			$logs = array();
		}

		array_unshift(
			$logs,
			array(
				'created_at_gmt' => (string) ( $state['last_run_gmt'] ?? current_time( 'mysql', true ) ),
				'processed'      => (int) ( $state['processed'] ?? 0 ),
				'succeeded'      => (int) ( $state['succeeded'] ?? 0 ),
				'failed'         => (int) ( $state['failed'] ?? 0 ),
				'pending_after'  => (int) ( $state['pending_after'] ?? 0 ),
				'duration_ms'    => (int) ( $state['duration_ms'] ?? 0 ),
			)
		);

		update_option( self::LOG_OPTION, array_slice( $logs, 0, 20 ), false );
	}

	private function dispatch( string $channel, string $event_type, int $score, array $reasons, bool $is_test ) {
		switch ( $channel ) {
			case 'email':
				return ( new KProtect_Notifier() )->send_email( $event_type, $score, $reasons, $is_test );
			case 'discord':
				return ( new KProtect_Discord_Notifier() )->send( $event_type, $score, $reasons, $is_test );
			case 'slack':
				return ( new KProtect_Slack_Notifier() )->send( $event_type, $score, $reasons, $is_test );
			case 'webhook':
				return ( new KProtect_Webhook_Notifier() )->send( $event_type, $score, $reasons, $is_test );
		}

		return new WP_Error( 'kprotect_queue_channel', '不明な通知チャンネルです。' );
	}

	public function pending_count(): int {
		global $wpdb;

		$cached = wp_cache_get( 'pending_count', self::CACHE_GROUP );
		if ( false !== $cached ) {
			return (int) $cached;
		}

		// Direct access is intentional because this is a KProtect-owned custom queue table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE status = 'pending'",
				$this->table()
			)
		);
		wp_cache_set( 'pending_count', $count, self::CACHE_GROUP, self::CACHE_TTL );
		return $count;
	}

	/**
	 * Return the number of pending file-integrity queue rows.
	 */
	public function pending_file_integrity_count(): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Administrative recovery must inspect current KProtect-owned queue state.
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE status = 'pending' AND event_type = 'file_integrity'",
				$this->table()
			)
		);
	}

	/**
	 * Delete only pending file-integrity queue rows.
	 *
	 * Processing, sent, failed, and unrelated event rows are preserved.
	 */
	public function delete_pending_file_integrity(): int {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- This explicit administrator recovery action deletes only matching rows from the KProtect-owned queue.
		$deleted = $wpdb->delete(
			$this->table(),
			array(
				'status'     => 'pending',
				'event_type' => 'file_integrity',
			),
			array( '%s', '%s' )
		);

		$this->clear_cache();

		return false === $deleted ? 0 : (int) $deleted;
	}

	public function stats(): array {
		global $wpdb;

		$cached = wp_cache_get( 'stats', self::CACHE_GROUP );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		// Direct access is intentional because this is a KProtect-owned custom queue table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT status, COUNT(*) AS total FROM %i GROUP BY status',
				$this->table()
			),
			ARRAY_A
		);
		$out  = array(
			'pending'    => 0,
			'processing' => 0,
			'sent'       => 0,
			'failed'     => 0,
		);

		foreach ( $rows as $row ) {
			$status = sanitize_key( (string) $row['status'] );
			if ( isset( $out[ $status ] ) ) {
				$out[ $status ] = (int) $row['total'];
			}
		}

		wp_cache_set( 'stats', $out, self::CACHE_GROUP, self::CACHE_TTL );
		return $out;
	}

	public function latest( int $limit = 100 ): array {
		global $wpdb;

		$limit = max( 1, min( 500, $limit ) );
		// Direct access is intentional because this is a KProtect-owned custom queue table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned queue state must be current; aggregate helpers use object cache where safe.
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i ORDER BY id DESC LIMIT %d',
				$this->table(),
				$limit
			),
			ARRAY_A
		);
	}

	public function runtime_state(): array {
		$state = get_option( self::STATE_OPTION, array() );
		return is_array( $state ) ? $state : array();
	}

	public function process_logs(): array {
		$logs = get_option( self::LOG_OPTION, array() );
		return is_array( $logs ) ? $logs : array();
	}

	public function next_scheduled(): int {
		return (int) ( wp_next_scheduled( 'kprotect_process_notification_queue' ) ?: 0 );
	}
}
