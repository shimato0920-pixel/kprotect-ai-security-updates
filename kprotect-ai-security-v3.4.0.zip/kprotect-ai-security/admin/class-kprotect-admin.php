<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_Admin {
	private KProtect_Logger $logger;
	private KProtect_Integrity_Scanner $scanner;
	private KProtect_File_Integrity_Manager $full_integrity;
	private KProtect_Security_Auditor $auditor;
	private KProtect_Malware_Scanner $malware;
	private KProtect_Security_Assistant $assistant;
	private KProtect_Incident_Center $incidents;
	private KProtect_Dashboard_Analytics $analytics;
	private KProtect_Notification_Center $notifications;
	private KProtect_Delivery_History $deliveries;
	private KProtect_Security_Report $report;
	private KProtect_Maintenance_Manager $maintenance;
	private KProtect_Notification_Queue $queue;
	public function __construct( KProtect_Logger $logger, KProtect_Integrity_Scanner $scanner, KProtect_File_Integrity_Manager $full_integrity, KProtect_Security_Auditor $auditor, KProtect_Malware_Scanner $malware, KProtect_Security_Assistant $assistant, KProtect_Incident_Center $incidents, KProtect_Dashboard_Analytics $analytics, KProtect_Notification_Center $notifications, KProtect_Delivery_History $deliveries, KProtect_Security_Report $report, KProtect_Maintenance_Manager $maintenance ) {
		$this->maintenance    = $maintenance;
		$this->logger         = $logger;
		$this->scanner        = $scanner;
		$this->full_integrity = $full_integrity;
		$this->auditor        = $auditor;
		$this->malware        = $malware;
		$this->assistant      = $assistant;
		$this->incidents      = $incidents;
		$this->analytics      = $analytics;
		$this->notifications  = $notifications;
		$this->deliveries     = $deliveries;
		$this->report         = $report;
		$this->queue          = new KProtect_Notification_Queue(); }
	public function hooks(): void {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register' ) );
		add_action( 'admin_init', array( $this, 'maybe_delete_processed_notifications' ), 1 );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_kprotect_unblock', array( $this, 'unblock' ) );
		add_action( 'admin_post_kprotect_integrity_baseline', array( $this, 'integrity_baseline' ) );
		add_action( 'admin_post_kprotect_integrity_scan', array( $this, 'integrity_scan' ) );
		add_action( 'admin_post_kprotect_full_integrity_scan', array( $this, 'full_integrity_scan' ) );
		add_action( 'admin_post_kprotect_full_integrity_baseline', array( $this, 'full_integrity_baseline' ) );
		add_action( 'admin_post_kprotect_malware_scan', array( $this, 'malware_scan' ) );
		add_action( 'admin_post_kprotect_malware_baseline', array( $this, 'malware_baseline' ) );
		add_action( 'admin_post_kprotect_notification_action', array( $this, 'notification_action' ) );
		add_action( 'admin_post_kprotect_delete_processed_notifications', array( $this, 'delete_processed_notifications' ) );
		add_action( 'admin_post_kprotect_test_notification', array( $this, 'test_notification' ) );
		add_action( 'admin_post_kprotect_test_discord', array( $this, 'test_discord' ) );
		add_action( 'admin_post_kprotect_test_slack', array( $this, 'test_slack' ) );
		add_action( 'admin_post_kprotect_test_webhook', array( $this, 'test_webhook' ) );
		add_action( 'admin_post_kprotect_retry_delivery', array( $this, 'retry_delivery' ) );
		add_action( 'admin_post_kprotect_run_cleanup', array( $this, 'run_cleanup' ) );
		add_action( 'admin_post_kprotect_firewall_self_test', array( $this, 'firewall_self_test' ) );
		add_action( 'admin_post_kprotect_create_distributed_test', array( $this, 'create_distributed_test' ) );
		add_action( 'admin_post_kprotect_create_distributed_cooldown_test', array( $this, 'create_distributed_cooldown_test' ) );
		add_action( 'admin_post_kprotect_create_webhook_retry_test', array( $this, 'create_webhook_retry_test' ) );
		add_action( 'admin_post_kprotect_delete_distributed_test', array( $this, 'delete_distributed_test' ) );
		add_action( 'admin_post_kprotect_process_queue', array( $this, 'process_queue' ) );
		add_action( 'admin_post_kprotect_delete_pending_file_integrity_queue', array( $this, 'delete_pending_file_integrity_queue' ) );
		add_action( 'admin_post_kprotect_export_incident_csv', array( $this, 'export_incident_csv' ) );
		add_action( 'wp_ajax_kprotect_monitor', array( $this, 'monitor_ajax' ) );
		add_action( 'wp_ajax_kprotect_ai_assistant', array( $this, 'ai_assistant_ajax' ) );
	}
	public function menu(): void {
		add_menu_page( 'KProtect AI', 'KProtect AI', 'manage_options', 'kprotect-ai', array( $this, 'dashboard' ), 'dashicons-shield-alt', 80 );
		add_submenu_page( 'kprotect-ai', 'KProtect Advisor', 'AIレポート', 'manage_options', 'kprotect-assistant', array( $this, 'assistant' ) );
		add_submenu_page( 'kprotect-ai', 'AI Rule Builder', 'AIルール', 'manage_options', 'kprotect-rule-builder', array( $this, 'rule_builder' ) );
		add_submenu_page( 'kprotect-ai', 'セキュリティレポート', 'レポート', 'manage_options', 'kprotect-reports', array( $this, 'reports' ) );
		add_submenu_page( 'kprotect-ai', 'インシデントセンター', 'インシデント', 'manage_options', 'kprotect-incidents', array( $this, 'incidents' ) );
		$unread             = $this->notifications->unread_count();
		$notification_label = '通知' . ( $unread > 0 ? ' <span class="awaiting-mod count-' . (int) $unread . '"><span class="pending-count">' . (int) $unread . '</span></span>' : '' );
		add_submenu_page( 'kprotect-ai', '通知センター', $notification_label, 'manage_options', 'kprotect-notifications', array( $this, 'notifications' ) );
		add_submenu_page( 'kprotect-ai', '通知配信履歴', '配信履歴', 'manage_options', 'kprotect-deliveries', array( $this, 'delivery_history' ) );
		add_submenu_page( 'kprotect-ai', '通知キュー', '通知キュー', 'manage_options', 'kprotect-queue', array( $this, 'queue_page' ) );
		add_submenu_page( 'kprotect-ai', 'セキュリティログ', 'ログ', 'manage_options', 'kprotect-logs', array( $this, 'logs' ) );
		add_submenu_page( 'kprotect-ai', 'ブロックIP', 'ブロックIP', 'manage_options', 'kprotect-blocks', array( $this, 'blocks' ) );
		add_submenu_page( 'kprotect-ai', '改ざん検知', '改ざん検知', 'manage_options', 'kprotect-integrity', array( $this, 'integrity' ) );
		add_submenu_page( 'kprotect-ai', 'ファイル整合性', 'ファイル整合性', 'manage_options', 'kprotect-full-integrity', array( $this, 'full_integrity' ) );
		add_submenu_page( 'kprotect-ai', 'セキュリティ診断', 'セキュリティ診断', 'manage_options', 'kprotect-audit', array( $this, 'audit' ) );
		add_submenu_page( 'kprotect-ai', 'uploadsスキャン', 'uploadsスキャン', 'manage_options', 'kprotect-malware', array( $this, 'malware' ) );
		add_submenu_page( 'kprotect-ai', '保守・パフォーマンス', '保守・負荷', 'manage_options', 'kprotect-maintenance', array( $this, 'maintenance' ) );
		add_submenu_page( 'kprotect-ai', '設定', '設定', 'manage_options', 'kprotect-settings', array( $this, 'settings' ) );
	}
	public function assets( string $hook ): void {
		if ( false === strpos( $hook, 'kprotect' ) ) {
			return; }
		wp_enqueue_style( 'kprotect-admin', KPROTECT_URL . 'assets/css/admin.css', array(), KPROTECT_VERSION );
		if ( false !== strpos( $hook, 'kprotect-ai' ) ) {
			wp_enqueue_script( 'kprotect-monitor', KPROTECT_URL . 'assets/js/admin-monitor.js', array(), KPROTECT_VERSION, true );
			wp_localize_script(
				'kprotect-monitor',
				'KProtectMonitor',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'kprotect_monitor' ),
				)
			);
		}
	}
	public function register(): void {
		register_setting(
			'kprotect_group',
			'kprotect_settings',
			array(
				'sanitize_callback' => array( $this, 'sanitize' ),
				'default'           => KProtect_Installer::defaults(),
			)
		); }
	public function sanitize( array $input ): array {
		$d   = KProtect_Installer::defaults();
		$out = array();
		foreach ( array( 'enabled', 'disable_xmlrpc', 'log_ip_address', 'admin_notifications', 'email_notifications', 'discord_notifications', 'slack_notifications', 'webhook_notifications', 'rest_api_enabled' ) as $k ) {
			$out[ $k ] = empty( $input[ $k ] ) ? 0 : 1; }
		foreach ( array( 'block_threshold', 'log_threshold', 'notification_threshold', 'email_threshold', 'discord_threshold', 'slack_threshold', 'webhook_threshold' ) as $k ) {
			$out[ $k ] = max( 0, min( 100, (int) ( $input[ $k ] ?? $d[ $k ] ) ) ); }
		foreach ( array( 'block_minutes', 'rate_limit_requests', 'rate_limit_window', 'login_failures', 'login_block_minutes', 'log_retention_days', 'notification_retention_days', 'email_cooldown_minutes', 'discord_cooldown_minutes', 'slack_cooldown_minutes', 'webhook_cooldown_minutes' ) as $k ) {
			$out[ $k ] = max( 1, (int) ( $input[ $k ] ?? $d[ $k ] ) ); }
		$out['trusted_ips']         = sanitize_textarea_field( $input['trusted_ips'] ?? '' );
		$out['blocked_ips']         = sanitize_textarea_field( $input['blocked_ips'] ?? '' );
		$out['excluded_paths']      = KProtect_Utils::sanitize_excluded_paths(
			(string) ( $input['excluded_paths'] ?? '' )
		);
		$out['notification_email']  = sanitize_email( $input['notification_email'] ?? get_option( 'admin_email' ) );
		$known_types                = array_keys( KProtect_Notification_Rules::event_types() );
		$selected_types             = isset( $input['email_event_types'] ) && is_array( $input['email_event_types'] ) ? array_map( 'sanitize_key', wp_unslash( $input['email_event_types'] ) ) : array();
		$out['email_event_types']   = array_values( array_intersect( $known_types, $selected_types ) );
		$discord_types              = isset( $input['discord_event_types'] ) && is_array( $input['discord_event_types'] ) ? array_map( 'sanitize_key', wp_unslash( $input['discord_event_types'] ) ) : array();
		$out['discord_event_types'] = array_values( array_intersect( $known_types, $discord_types ) );
		$out['discord_webhook_url'] = KProtect_Discord_Notifier::sanitize_webhook_url( (string) ( $input['discord_webhook_url'] ?? '' ) );
		$slack_types                = isset( $input['slack_event_types'] ) && is_array( $input['slack_event_types'] ) ? array_map( 'sanitize_key', wp_unslash( $input['slack_event_types'] ) ) : array();
		$out['slack_event_types']   = array_values( array_intersect( $known_types, $slack_types ) );
		$out['slack_webhook_url']   = KProtect_Slack_Notifier::sanitize_webhook_url( (string) ( $input['slack_webhook_url'] ?? '' ) );
		$webhook_types              = isset( $input['webhook_event_types'] ) && is_array( $input['webhook_event_types'] ) ? array_map( 'sanitize_key', wp_unslash( $input['webhook_event_types'] ) ) : array();
		$out['webhook_event_types'] = array_values( array_intersect( $known_types, $webhook_types ) );
		$out['webhook_url']         = KProtect_Webhook_Notifier::sanitize_webhook_url( (string) ( $input['webhook_url'] ?? '' ) );
		$out['webhook_secret']      = sanitize_text_field( (string) ( $input['webhook_secret'] ?? '' ) );
		return wp_parse_args( $out, $d );
	}
	/**
	 * Render the shared KProtect administration header.
	 *
	 * @param string $title Current page title.
	 */
	private function header( string $title ): void {
		$descriptions = array(
			'KProtect AI Security' => 'サイトの検知状況、優先対応、AI分析をまとめて確認します。',
			'インシデントセンター'           => '対応が必要なセキュリティイベントを優先順に確認します。',
			'セキュリティログ'             => '記録された検知イベントを検索し、根拠と対応状況を確認します。',
			'ブロックIP'               => '一時遮断中の接続元と手動ブロック設定を管理します。',
			'重要ファイルの改ざん検知'         => '重要ファイルの変更を基準情報と比較して確認します。',
			'KProtect Advisor'     => 'サイトの安全度と、優先して確認すべき改善項目を表示します。',
			'セキュリティ診断'             => 'WordPress環境の主要なセキュリティ設定を読み取り専用で診断します。',
			'uploads高度スキャン'        => 'uploadsフォルダ内の不審なファイルを読み取り専用で確認します。',
			'KProtect セキュリティレポート'  => '検知傾向、主なイベント、推奨対応をレポート形式で確認します。',
			'KProtect 通知センター'      => '未対応通知と処理済み履歴を分けて管理します。',
			'通知キュー'                => '外部通知の待機、再試行、失敗状況を確認します。',
			'通知配信履歴'               => 'メールやWebhookなどの配信結果を確認します。',
			'保守・パフォーマンス'           => 'ログ保持、処理負荷、アップグレード状態を確認します。',
			'AI Rule Builder'      => '自然な日本語から安全なルール案を作成し、テスト・保存します。',
			'KProtect 設定'          => '検知、遮断、通知、保持期間などの動作を設定します。',
			'ファイル整合性'              => 'プラグインファイルの追加・変更・削除を基準情報と比較します。',
		);
		$description  = $descriptions[ $title ] ?? 'KProtect AI Securityの管理機能です。';
		$icon         = 'dashicons-shield-alt';

		echo '<div class="wrap kprotect-wrap">';
		echo '<header class="kp-admin-page-header">';
		echo '<div class="kp-admin-page-header__icon" aria-hidden="true"><span class="dashicons ' . esc_attr( $icon ) . '"></span></div>';
		echo '<div class="kp-admin-page-header__content">';
		echo '<span class="kp-admin-page-header__product">KProtect AI Security</span>';
		echo '<h1 class="kp-admin-page-header__title">' . esc_html( $title ) . '</h1>';
		echo '<p class="kp-admin-page-header__description">' . esc_html( $description ) . '</p>';
		echo '</div>';
		echo '<span class="kp-admin-page-header__version">v' . esc_html( KPROTECT_VERSION ) . '</span>';
		echo '</header>';
	}
	private function stats(): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Real-time security telemetry from KProtect-owned tables must reflect the latest events; all queries are prepared.
		$table = $wpdb->prefix . 'kprotect_logs';
		$today = gmdate( 'Y-m-d 00:00:00' );
		$hour  = gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS );
		return array(
			'total'    => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE created_at >= %s', $table, $today ) ),
			'blocked'  => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE created_at >= %s AND blocked = 1', $table, $today ) ),
			'login'    => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE created_at >= %s AND event_type LIKE %s', $table, $today, 'login%' ) ),
			'hour'     => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE created_at >= %s', $table, $hour ) ),
			'max_risk' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(MAX(risk_score),0) FROM %i WHERE created_at >= %s', $table, $hour ) ),
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}
	public function dashboard(): void {
		$s             = $this->stats();
		$data          = $this->analytics->snapshot( 24 );
		$login_attacks = KProtect_Login_Attack_Tracker::recent_attacks( 20 );
		$status        = $s['max_risk'] >= 80 ? '危険' : ( $s['hour'] > 0 ? '監視中' : '安全' );
		$class         = $s['max_risk'] >= 80 ? 'danger' : ( $s['hour'] > 0 ? 'watch' : 'safe' );
		$this->header( 'KProtect AI Security' );
		echo '<p class="description">Ver.' . esc_html( KPROTECT_VERSION ) . '：KProtect Advisorの分野別健康度と優先対応プランを搭載しています。</p>';
		$csv_url = wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_export_incident_csv' ), 'kprotect_export_incident_csv' );

		$threat_level        = KProtect_Threat_Level::current_level();
		$threat_metrics      = KProtect_Threat_Level::recent_metrics();
		$settings            = KProtect_Utils::settings();
		$base_threshold      = max( 0, min( 100, (int) ( $settings['block_threshold'] ?? 80 ) ) );
		$base_rate           = max( 10, (int) ( $settings['rate_limit_requests'] ?? 120 ) );
		$effective_threshold = KProtect_Threat_Level::block_threshold( $base_threshold, $threat_level );
		$effective_rate      = KProtect_Threat_Level::rate_limit( $base_rate, $threat_level );
		$threat_labels       = array(
			'normal'   => 'NORMAL',
			'elevated' => 'ELEVATED',
			'high'     => 'HIGH',
		);
		$threat_label        = $threat_labels[ $threat_level ] ?? 'NORMAL';
		$threat_assessment   = KProtect_Threat_Level::assessment(
			(int) ( $threat_metrics['blocked_events'] ?? 0 ),
			(int) ( $threat_metrics['critical_events'] ?? 0 ),
			(int) ( $threat_metrics['attack_sources'] ?? 0 )
		);
		$threat_reasons      = array(
			'normal'            => '現在、自動防御を強化する条件には達していません。',
			'elevated_blocked'  => '直近15分の自動遮断が3件以上に達したため、防御をELEVATEDへ強化しています。',
			'elevated_critical' => '直近15分のCriticalイベントが3件以上に達したため、防御をELEVATEDへ強化しています。',
			'high_blocked'      => '直近15分の自動遮断が10件以上に達したため、防御をHIGHへ強化しています。',
			'high_critical'     => '直近15分のCriticalイベントが10件以上に達したため、防御をHIGHへ強化しています。',
			'high_distributed'  => '直近15分に5件以上の自動遮断と5以上の攻撃元を検知したため、分散攻撃として防御をHIGHへ強化しています。',
		);
		$threat_reason       = $threat_reasons[ $threat_assessment['reason'] ] ?? $threat_reasons['normal'];

		if ( $threat_assessment['level'] !== $threat_level ) {
			$threat_reason = '脅威情報を再評価中です。自動防御レベルには最大60秒以内に最新状態が反映されます。';
		}
		echo '<div class="kp-dashboard-actions"><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=kprotect-assistant' ) ) . '">AIレポート</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=kprotect-incidents' ) ) . '">インシデント</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=kprotect-notifications' ) ) . '">通知センター</a> <a class="button" href="' . esc_url( $csv_url ) . '">集計CSVを出力</a> <span id="kp-updated">10秒ごとに更新</span></div>';
		echo '<section class="kp-panel kp-threat-level kp-threat-' . esc_attr( $threat_level ) . '">';
		echo '<div class="kp-panel-heading"><div><h2>自動防御レベル</h2><span>直近15分の高危険度イベントから自動調整</span></div><strong class="kp-threat-badge">' . esc_html( $threat_label ) . '</strong></div>';
		echo '<div class="kp-threat-metrics">';
		echo '<div><span>Firewall閾値</span><strong>' . esc_html( (string) $effective_threshold ) . '</strong><small>設定値 ' . esc_html( (string) $base_threshold ) . '</small></div>';
		echo '<div><span>Rate Limit</span><strong>' . esc_html( (string) $effective_rate ) . '</strong><small>設定値 ' . esc_html( (string) $base_rate ) . '</small></div>';
		echo '<div><span>Critical</span><strong>' . esc_html( (string) ( $threat_metrics['critical_events'] ?? 0 ) ) . '件</strong><small>危険度90以上</small></div>';
		echo '<div><span>Blocked</span><strong>' . esc_html( (string) ( $threat_metrics['blocked_events'] ?? 0 ) ) . '件</strong><small>自動遮断</small></div>';
		echo '<div><span>攻撃元</span><strong>' . esc_html( (string) ( $threat_metrics['attack_sources'] ?? 0 ) ) . '</strong><small>匿名化した接続元</small></div>';
		echo '</div>';
		echo '<div class="kp-threat-reason"><strong>現在の判定理由</strong><p>' . esc_html( $threat_reason ) . '</p></div>';

		echo '<p class="description">脅威が増加するとFirewall閾値とRate Limitを一時的に強化し、状況が収まると設定値へ自動復帰します。管理画面の設定値自体は変更しません。</p>';
		echo '</section>';

		$attack_trends             = KProtect_Attack_Trend::dashboard_status();
		$attack_trend_labels       = array(
			'code_execution' => 'コード実行攻撃',
			'webshell_probe' => 'Webシェル探索',
			'sql_injection'  => 'SQLインジェクション',
			'path_traversal' => 'パストラバーサル',
			'xss'            => 'クロスサイトスクリプティング',
			'sensitive_file' => '機密ファイル探索',
		);
		$attack_trend_level_labels = array(
			'normal'      => 'NORMAL',
			'surge'       => 'SURGE',
			'distributed' => 'DISTRIBUTED',
		);

		echo '<section class="kp-panel kp-attack-trends">';
		echo '<div class="kp-panel-heading"><div><h2>攻撃タイプ別トレンド</h2><span>直近15分の同種攻撃と攻撃元の分散状況</span></div></div>';
		echo '<div class="kp-attack-trend-grid">';

		foreach ( $attack_trends as $attack_type => $trend ) {
			$trend_level = sanitize_key(
				(string) ( $trend['level'] ?? 'normal' )
			);
			$trend_label = $attack_trend_level_labels[ $trend_level ] ?? 'NORMAL';
			$type_label  = $attack_trend_labels[ $attack_type ] ?? $attack_type;

			echo '<div class="kp-attack-trend-item kp-trend-' . esc_attr( $trend_level ) . '">';
			echo '<div class="kp-attack-trend-title"><strong>' . esc_html( $type_label ) . '</strong><span class="kp-attack-trend-badge">' . esc_html( $trend_label ) . '</span></div>';
			echo '<div class="kp-attack-trend-metrics">';
			echo '<div><span>検知</span><strong>' . esc_html( (string) ( $trend['attack_events'] ?? 0 ) ) . '件</strong></div>';
			echo '<div><span>攻撃元</span><strong>' . esc_html( (string) ( $trend['attack_sources'] ?? 0 ) ) . '</strong></div>';
			echo '</div>';
			echo '</div>';
		}

		echo '</div>';
		echo '<p class="description">同じ攻撃タイプが複数の接続元から集中するとSURGEまたはDISTRIBUTEDとなり、その攻撃タイプに対するFirewall閾値を一時的に強化します。</p>';
		echo '</section>';

		$attack_intelligence       = KProtect_Attack_Intelligence::summary();
		$attack_intelligence_cache = KProtect_Attack_Intelligence::cache_status();

		echo '<section class="kp-panel kp-attack-trends">';
		echo '<div class="kp-panel-heading"><div><h2>攻撃インテリジェンス</h2><span>直近24時間の攻撃タイプ別検知状況</span></div></div>';
		echo '<div class="kp-attack-trend-title"><strong>キャッシュ</strong><span class="kp-attack-trend-badge">' . esc_html( ! empty( $attack_intelligence_cache['cached'] ) ? 'ACTIVE' : 'EMPTY' ) . '</span></div>';
		echo '<p class="description">TTL: ' . esc_html( (string) ( $attack_intelligence_cache['cache_ttl'] ?? 0 ) ) . '秒 / 対象: ' . esc_html( (string) ( $attack_intelligence_cache['attack_types'] ?? 0 ) ) . 'タイプ</p>';
		echo '<div class="kp-attack-trend-grid">';

		foreach ( $attack_intelligence as $attack_type => $intelligence ) {

			$type_label = $attack_trend_labels[ $attack_type ] ?? $attack_type;

			echo '<div class="kp-attack-trend-item">';
			echo '<div class="kp-attack-trend-title"><strong>' . esc_html( $type_label ) . '</strong><span class="kp-attack-trend-badge">24H</span></div>';
			echo '<div class="kp-attack-trend-metrics">';
			echo '<div><span>検知</span><strong>' . esc_html( (string) ( $intelligence['attack_events'] ?? 0 ) ) . '件</strong></div>';
			echo '<div><span>攻撃元</span><strong>' . esc_html( (string) ( $intelligence['attack_sources'] ?? 0 ) ) . '</strong></div>';
			echo '<div><span>Critical</span><strong>' . esc_html( (string) ( $intelligence['critical_events'] ?? 0 ) ) . '件</strong></div>';
			echo '<div><span>Blocked</span><strong>' . esc_html( (string) ( $intelligence['blocked_events'] ?? 0 ) ) . '件</strong></div>';
			echo '</div>';
			echo '</div>';

		}

		echo '</div>';
		echo '<p class="description">直近24時間の攻撃傾向を攻撃タイプ別に集計します。短期的な防御強化判定とは独立した分析情報です。</p>';
		echo '</section>';

		$update_diagnostics      = KProtect_Update_Diagnostics::status();
		$update_available        = ! empty( $update_diagnostics['update_available'] );
		$cache_exists            = ! empty( $update_diagnostics['cache_exists'] );
		$cached_version          = $update_diagnostics['cached_version'] ?? null;
		$checked_at              = $update_diagnostics['checked_at'] ?? null;
		$remaining_seconds       = $update_diagnostics['remaining_seconds'] ?? null;
		$last_error_code         = $update_diagnostics['last_error_code'] ?? null;
		$last_error_http_status  = $update_diagnostics['last_error_http_status'] ?? null;
		$last_error_at           = $update_diagnostics['last_error_at'] ?? null;
		$update_error_message    = null;
		$update_error_time_label = null;

		if ( null !== $last_error_code ) {
			switch ( $last_error_code ) {
				case 'request_error':
					$update_error_message = '更新サーバーへの接続に失敗しました。';
					break;

				case 'http_error':
					$update_error_message = '更新サーバーがHTTPエラーを返しました。';

					if ( null !== $last_error_http_status ) {
						$update_error_message .= ' HTTP ' . (int) $last_error_http_status;
					}
					break;

				case 'invalid_response':
					$update_error_message = '更新情報の形式を確認できませんでした。';
					break;

				default:
					$update_error_message = '更新情報の取得中に問題が発生しました。';
					break;
			}

			if ( null !== $last_error_at ) {
				$update_error_time_label = wp_date(
					'Y年n月j日 H:i:s',
					(int) $last_error_at
				);
			}
		}

		if ( null === $cached_version ) {
			$update_status_label = '未確認';
			$update_status_class = 'unknown';
		} elseif ( $update_available ) {
			$update_status_label = '更新あり';
			$update_status_class = 'available';
		} elseif ( version_compare( (string) $cached_version, KPROTECT_VERSION, '<' ) ) {
			$update_status_label = 'キャッシュ旧版';
			$update_status_class = 'stale';
		} else {
			$update_status_label = '最新版';
			$update_status_class = 'current';
		}

		$checked_at_label = null !== $checked_at
			? wp_date( 'Y年n月j日 H:i:s', (int) $checked_at )
			: '未取得';

		if ( null === $remaining_seconds ) {
			$remaining_label = '不明';
		} elseif ( $remaining_seconds <= 0 ) {
			$remaining_label = '期限切れ';
		} else {
			$remaining_minutes = (int) ceil( $remaining_seconds / MINUTE_IN_SECONDS );
			$remaining_label   = $remaining_minutes . '分';
		}

		$update_check_url = self_admin_url(
			'update-core.php?force-check=1'
		);

		echo '<section class="kp-panel kp-update-diagnostics kp-update-' . esc_attr( $update_status_class ) . '">';

		echo '<div class="kp-panel-heading"><div><h2>アップデート診断</h2><span>GitHub公開版とKProtect更新キャッシュの状態</span></div><strong class="kp-update-badge">' . esc_html( $update_status_label ) . '</strong></div>';

		echo '<div class="kp-update-metrics">';

		echo '<div><span>現在のバージョン</span><strong>' . esc_html( (string) $update_diagnostics['current_version'] ) . '</strong><small>インストール済み</small></div>';

		echo '<div><span>取得済み最新版</span><strong>' . esc_html( null !== $cached_version ? (string) $cached_version : '未取得' ) . '</strong><small>GitHub更新情報</small></div>';

		echo '<div><span>キャッシュ</span><strong>' . esc_html( $cache_exists ? '有効' : 'なし' ) . '</strong><small>更新情報キャッシュ</small></div>';

		echo '<div><span>残り時間</span><strong>' . esc_html( $remaining_label ) . '</strong><small>最大60分</small></div>';

		echo '</div>';

		echo '<div class="kp-update-detail"><strong>最終確認</strong><span>' . esc_html( $checked_at_label ) . '</span></div>';

		if ( null !== $update_error_message ) {
			echo '<div class="kp-update-error">';
			echo '<strong>前回の更新確認エラー</strong>';
			echo '<p>' . esc_html( $update_error_message ) . '</p>';

			if ( null !== $update_error_time_label ) {
				echo '<small>発生日時 ' . esc_html( $update_error_time_label ) . '</small>';
			}

			echo '</div>';
		}

		echo '<div class="kp-update-actions"><a class="button" href="' . esc_url( $update_check_url ) . '">更新情報を再確認</a><span>再確認するとKProtectの更新キャッシュを破棄し、WordPressの更新確認を実行します。</span></div>';

		echo '</section>';

		$analyst       = KProtect_Security_Analyst::analyze();
		$analyst_level = sanitize_key( (string) ( $analyst['level'] ?? 'normal' ) );
		echo '<section class="kp-panel kp-security-analyst kp-analyst-' . esc_attr( $analyst_level ) . '">';
		echo '<div class="kp-panel-heading"><div><h2>AI Security Analyst</h2><span>過去24時間と7日平均をローカル比較</span></div><strong>確度 ' . esc_html( (string) ( $analyst['confidence'] ?? '限定的' ) ) . '</strong></div>';
		echo '<h3>' . esc_html( (string) ( $analyst['title'] ?? '' ) ) . '</h3><p>' . esc_html( (string) ( $analyst['summary'] ?? '' ) ) . '</p>';
		echo '<div class="kp-analyst-metrics"><div><span>24時間</span><strong>' . esc_html( (string) ( $analyst['total_24h'] ?? 0 ) ) . '件</strong></div><div><span>前の24時間</span><strong>' . esc_html( (string) ( $analyst['previous_24h'] ?? 0 ) ) . '件</strong></div><div><span>前日比</span><strong>' . esc_html( (string) ( $analyst['day_change_percent'] ?? 0 ) ) . '%</strong></div><div><span>7日平均</span><strong>' . esc_html( (string) ( $analyst['daily_average'] ?? 0 ) ) . '件/日</strong></div><div><span>平均との差</span><strong>' . esc_html( (string) ( $analyst['change_percent'] ?? 0 ) ) . '%</strong></div><div><span>高危険度</span><strong>' . esc_html( (string) ( $analyst['critical_24h'] ?? 0 ) ) . '件</strong></div><div><span>未遮断</span><strong>' . esc_html( (string) ( $analyst['unblocked_24h'] ?? 0 ) ) . '件</strong></div></div>';
		echo '<div class="kp-analyst-insights"><div><strong>主な検知種別</strong><ol>';
		foreach ( (array) ( $analyst['top_types'] ?? array() ) as $analyst_type ) {
			echo '<li><span>' . esc_html( (string) ( $analyst_type['label'] ?? '' ) ) . '</span><strong>' . esc_html( (string) ( $analyst_type['total'] ?? 0 ) ) . '件</strong><small>最大危険度 ' . esc_html( (string) ( $analyst_type['max_risk'] ?? 0 ) ) . '</small></li>'; }
		if ( empty( $analyst['top_types'] ) ) {
			echo '<li>直近24時間の検知はありません。</li>'; }
		echo '</ol></div><div><strong>傾向</strong><dl><div><dt>集中時間帯</dt><dd>' . esc_html( (string) ( $analyst['peak_hour']['hour'] ?? '該当なし' ) ) . '（' . esc_html( (string) ( $analyst['peak_hour']['total'] ?? 0 ) ) . '件）</dd></div><div><dt>反復する匿名接続元</dt><dd>' . esc_html( (string) ( $analyst['repeated_sources']['groups'] ?? 0 ) ) . 'グループ</dd></div><div><dt>最多反復回数</dt><dd>' . esc_html( (string) ( $analyst['repeated_sources']['max_events'] ?? 0 ) ) . '件</dd></div></dl></div></div>';
		echo '<div class="kp-analyst-actions"><strong>推奨対応</strong><ol>';
		foreach ( (array) ( $analyst['actions'] ?? array() ) as $analyst_action ) {
			echo '<li>' . esc_html( (string) $analyst_action ) . '</li>'; }
		echo '</ol></div><p class="description">' . esc_html( (string) ( $analyst['privacy_note'] ?? '' ) ) . '</p></section>';
		$intelligence = (array) ( $data['intelligence'] ?? array() );
		$ai_level     = sanitize_key( (string) ( $intelligence['level'] ?? 'safe' ) );
		echo '<section class="kp-ai-overview kp-ai-' . esc_attr( $ai_level ) . '">';
		echo '<div class="kp-ai-score"><span>ローカルAI評価</span><strong id="kp-ai-score">' . esc_html( (string) ( $intelligence['score'] ?? 100 ) ) . '</strong><small>/100</small></div>';
		echo '<div class="kp-ai-message"><span class="kp-ai-eyebrow">説明可能なセキュリティ評価・確度 <strong id="kp-ai-confidence">' . esc_html( (string) ( $intelligence['confidence'] ?? '限定的' ) ) . '</strong></span><h2 id="kp-ai-title">' . esc_html( (string) ( $intelligence['title'] ?? '' ) ) . '</h2><p id="kp-ai-summary">' . esc_html( (string) ( $intelligence['summary'] ?? '' ) ) . '</p><div class="kp-ai-assessment"><strong id="kp-ai-likelihood">' . esc_html( (string) ( $intelligence['likelihood'] ?? '判定：追加確認が必要' ) ) . '</strong><p id="kp-ai-assessment">' . esc_html( (string) ( $intelligence['assessment'] ?? '' ) ) . '</p></div><div class="kp-ai-evidence"><strong>判断材料</strong><ul id="kp-ai-evidence">';
		foreach ( (array) ( $intelligence['evidence'] ?? array() ) as $evidence ) {
			echo '<li>' . esc_html( (string) $evidence ) . '</li>';
		}
		echo '</ul></div>';
		$response_plan = (array) ( $intelligence['response_plan'] ?? array() );
		echo '<div class="kp-ai-response-plan"><div class="kp-ai-plan-heading"><span>優先度 <strong id="kp-ai-plan-priority">' . esc_html( (string) ( $response_plan['priority'] ?? 'D' ) ) . '</strong></span><span>対応目安 <strong id="kp-ai-plan-urgency">' . esc_html( (string) ( $response_plan['urgency'] ?? '定期点検時' ) ) . '</strong></span></div><p><strong>最優先で確認する対象：</strong><span id="kp-ai-plan-target">' . esc_html( (string) ( $response_plan['target'] ?? '' ) ) . '</span></p><div class="kp-ai-plan-grid"><div><strong>判断理由</strong><ul id="kp-ai-plan-reasons">';
		foreach ( (array) ( $response_plan['reasons'] ?? array() ) as $reason ) {
			echo '<li>' . esc_html( (string) $reason ) . '</li>';
		}
		echo '</ul></div><div><strong>推奨する操作</strong><ol id="kp-ai-actions" class="kp-ai-actions">';
		foreach ( (array) ( $response_plan['steps'] ?? $intelligence['actions'] ?? array() ) as $action ) {
			echo '<li>' . esc_html( (string) $action ) . '</li>';
		}
		echo '</ol></div></div><details class="kp-ai-defer"><summary>対応を後回しにできる条件</summary><ul id="kp-ai-plan-defer">';
		foreach ( (array) ( $response_plan['defer_conditions'] ?? array() ) as $condition ) {
			echo '<li>' . esc_html( (string) $condition ) . '</li>';
		}
		echo '</ul><p>条件を満たさない場合は、表示された期限内に確認してください。</p></details></div><p class="kp-ai-recommendation"><strong>最優先：</strong><span id="kp-ai-recommendation">' . esc_html( (string) ( $intelligence['recommendation'] ?? '' ) ) . '</span></p></div>';
		echo '<div class="kp-ai-signals" id="kp-ai-signals">';
		foreach ( (array) ( $intelligence['signals'] ?? array() ) as $signal ) {
			echo '<div><span>' . esc_html( (string) ( $signal['label'] ?? '' ) ) . '</span><strong>' . esc_html( (string) ( $signal['value'] ?? '' ) ) . '</strong></div>'; }
		echo '</div></section>';
		echo '<div class="kp-soc-grid">';
		$incident_queue = (array) ( $intelligence['incident_queue'] ?? array() );
		echo '<section class="kp-panel kp-incident-queue"><div class="kp-panel-heading"><h2>AI Incident Queue</h2><span>対応すべき順に自動整理</span></div><div id="kp-incident-queue" class="kp-incident-queue-list">';
		$this->render_incident_queue( $incident_queue );
		echo '</div></section>';
		$incident_report = (array) ( $intelligence['incident_report'] ?? array() );
		$this->render_incident_report( $incident_report );
		echo '<section class="kp-panel kp-ai-chat"><div class="kp-panel-heading"><div><h2>AI Assistant</h2><span>ローカルログに基づく相談機能</span></div><strong>外部送信なし</strong></div>';
		echo '<p>現在の集計結果について質問できます。回答は事実・評価・推奨対応を分けて表示します。</p>';
		echo '<div class="kp-ai-chat-presets"><button type="button" class="button" data-kp-question="今、何を最優先で確認すべき？">最優先の対応</button><button type="button" class="button" data-kp-question="直近24時間の状況をまとめて">24時間のまとめ</button><button type="button" class="button" data-kp-question="ファイル変更は誤検知の可能性がある？">ファイル変更</button><button type="button" class="button" data-kp-question="ログイン攻撃について教えて">ログイン攻撃</button></div>';
		echo '<form id="kp-ai-chat-form" class="kp-ai-chat-form"><label for="kp-ai-chat-question">質問</label><div><input id="kp-ai-chat-question" type="text" maxlength="300" placeholder="例：この警告は誤検知の可能性がありますか？"><button class="button button-primary" type="submit">ローカルAIに相談</button></div></form>';
		echo '<div id="kp-ai-chat-result" class="kp-ai-chat-result" aria-live="polite"><p class="description">質問を選ぶか入力してください。</p></div></section></div>';
		echo '<section class="kprotect-monitor"><div><span>現在の状態</span><strong id="kp-status" class="kp-status ' . esc_attr( $css_class ) . '">' . esc_html( $status ) . '</strong></div><div><span>直近1時間の検知</span><strong id="kp-hour">' . esc_html( (string) $s['hour'] ) . '</strong></div><div><span>最大危険度</span><strong id="kp-risk">' . esc_html( (string) $s['max_risk'] ) . '</strong></div></section>';
		echo '<div class="kprotect-cards kp-four">';
		foreach ( array(
			'本日の検知'  => $s['total'],
			'本日の遮断'  => $s['blocked'],
			'ログイン関連' => $s['login'],
			'直近イベント' => count( (array) $data['recent'] ),
		) as $label => $value ) {
			echo '<div class="kprotect-card"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( (string) $value ) . '</strong></div>'; }
		echo '</div>';

		echo '<section class="kp-panel">';
		echo '<div class="kp-panel-heading"><div><h2>ログイン攻撃状況</h2><span>匿名化されたアカウント単位の集計</span></div><strong>最大20件</strong></div>';

		if ( empty( $login_attacks ) ) {
			echo '<p class="description">現在、集計されたログイン攻撃はありません。</p>';
		} else {
			echo '<table class="widefat striped">';
			echo '<thead><tr><th>対象ID</th><th>失敗回数</th><th>攻撃元数</th><th>分散攻撃</th><th>初回検知</th><th>最終検知</th></tr></thead><tbody>';

			foreach ( $login_attacks as $attack ) {
				$first_seen_ts = ! empty( $attack['first_seen'] )
					? strtotime( (string) $attack['first_seen'] . ' UTC' )
					: false;

				$last_seen_ts = ! empty( $attack['last_seen'] )
					? strtotime( (string) $attack['last_seen'] . ' UTC' )
					: false;

				$first_seen = $first_seen_ts
					? wp_date( 'Y-m-d H:i:s', $first_seen_ts )
					: '-';

				$last_seen = $last_seen_ts
					? wp_date( 'Y-m-d H:i:s', $last_seen_ts )
					: '-';

				$distributed = ! empty( $attack['distributed'] )
					? '検知'
					: '未検知';

				echo '<tr>';
				echo '<td><code>' . esc_html( (string) ( $attack['account_id'] ?? '' ) ) . '</code></td>';
				echo '<td>' . esc_html( (string) ( $attack['failed_count'] ?? 0 ) ) . '</td>';
				echo '<td>' . esc_html( (string) ( $attack['source_count'] ?? 0 ) ) . '</td>';
				echo '<td>' . esc_html( $distributed ) . '</td>';
				echo '<td>' . esc_html( $first_seen ) . '</td>';
				echo '<td>' . esc_html( $last_seen ) . '</td>';
				echo '</tr>';
			}

			echo '</tbody></table>';
		}

		echo '<p class="description">対象IDはユーザー名を保存せず、HMACで匿名化した識別子の一部だけを表示します。攻撃元IPの平文はこの集計には保存しません。</p>';
		echo '</section>';

		echo '<div class="kp-dashboard-grid"><section class="kp-panel"><h2>直近24時間の検知推移</h2><canvas id="kp-timeline-chart" height="240" aria-label="直近24時間の検知推移"></canvas><p class="description">検知件数と遮断件数を1時間単位で表示します。</p></section><section class="kp-panel"><h2>検知種別</h2><canvas id="kp-type-chart" height="240" aria-label="検知種別の割合"></canvas><div id="kp-type-legend" class="kp-chart-legend"></div></section></div>';
		echo '<section class="kp-panel"><div class="kp-panel-heading"><h2>リアルタイムイベント</h2><a href="' . esc_url( admin_url( 'admin.php?page=kprotect-logs' ) ) . '">すべてのログ</a></div><div class="kp-live-table-wrap"><table class="widefat striped kp-live-table"><thead><tr><th>時刻</th><th>種類</th><th>危険度</th><th>攻撃元</th><th>状態</th><th>根拠</th></tr></thead><tbody id="kp-live-events">';
		$this->render_recent_rows( (array) $data['recent'] );
		echo '</tbody></table></div></section>';
		echo '<script type="application/json" id="kp-dashboard-data">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>';
		echo '<div class="kprotect-notice"><h2>プライバシー</h2><p>グラフとイベント一覧はローカルデータのみで生成され、外部サービスへ送信されません。IP平文保存が無効な場合はハッシュの先頭部分だけを表示します。</p></div></div>';
	}


	/**
	 * Render the local 24-hour incident report.
	 *
	 * @param array<string,mixed> $report Incident report data.
	 * @return void
	 */
	private function render_incident_report( array $report ): void {
		$level = sanitize_key( (string) ( $report['level'] ?? 'normal' ) );
		echo '<section class="kp-panel kp-incident-report kp-report-' . esc_attr( $level ) . '">';
		echo '<div class="kp-panel-heading"><div><h2>AI Incident Report</h2><span id="kp-report-period">' . esc_html( (string) ( $report['period'] ?? '直近24時間' ) ) . '</span></div><strong id="kp-report-trend" class="kp-report-trend">' . esc_html( (string) ( $report['trend_label'] ?? '前日比較データなし' ) ) . '</strong></div>';
		echo '<div class="kp-report-metrics">';
		foreach ( array(
			'検知'    => $report['total'] ?? 0,
			'遮断'    => $report['blocked'] ?? 0,
			'未遮断'   => $report['unblocked'] ?? 0,
			'最大危険度' => $report['max_risk'] ?? 0,
		) as $label => $value ) {
			echo '<div><span>' . esc_html( $label ) . '</span><strong>' . esc_html( (string) $value ) . '</strong></div>';
		}
		echo '</div><div class="kp-report-grid"><div><h3>主なイベント</h3><ol id="kp-report-events">';
		foreach ( (array) ( $report['top_events'] ?? array() ) as $event ) {
			echo '<li><span>' . esc_html( (string) ( $event['label'] ?? '' ) ) . '</span><strong>' . esc_html( (string) ( $event['total'] ?? 0 ) ) . '件</strong></li>';
		}
		echo '</ol></div><div><h3>AI総括</h3><p id="kp-report-summary">' . esc_html( (string) ( $report['summary'] ?? '' ) ) . '</p><p class="kp-report-peak">集中時間帯：<strong id="kp-report-peak">' . esc_html( (string) ( $report['peak_label'] ?? '該当なし' ) ) . '</strong>（<span id="kp-report-peak-total">' . esc_html( (string) ( $report['peak_total'] ?? 0 ) ) . '</span>件）</p><small>' . esc_html( (string) ( $report['privacy_note'] ?? '' ) ) . '</small></div></div></section>';
	}


	/**
	 * Render the prioritized local incident queue.
	 *
	 * @param array<int,array<string,mixed>> $items Prioritized incident groups.
	 * @return void
	 */
	private function render_incident_queue( array $items ): void {
		if ( empty( $items ) ) {
			echo '<p class="kp-incident-empty">現在、優先対応が必要なイベントはありません。</p>';
			return;
		}

		foreach ( $items as $item ) {
			$priority = preg_replace( '/[^A-D]/', '', (string) ( $item['priority'] ?? 'D' ) );
			echo '<article class="kp-incident-item kp-incident-priority-' . esc_attr( strtolower( $priority ) ) . '">';
			echo '<div class="kp-incident-priority"><strong>' . esc_html( $priority ) . '</strong><span>' . esc_html( (string) ( $item['priority_label'] ?? '' ) ) . '</span></div>';
			echo '<div class="kp-incident-main"><div class="kp-incident-title"><h3>' . esc_html( (string) ( $item['label'] ?? '' ) ) . '</h3><span>' . esc_html( (string) ( $item['count'] ?? 0 ) ) . '件</span></div>';
			echo '<p>' . esc_html( (string) ( $item['reason'] ?? '' ) ) . '</p><small>推奨：' . esc_html( (string) ( $item['action'] ?? '' ) ) . '</small></div>';
			echo '<div class="kp-incident-metrics"><span>最大危険度 <strong>' . esc_html( (string) ( $item['max_risk'] ?? 0 ) ) . '</strong></span><span>未遮断 <strong>' . esc_html( (string) ( $item['unblocked_count'] ?? 0 ) ) . '</strong></span></div>';
			echo '</article>';
		}
	}

	/** @param array<int,array<string,mixed>> $rows */
	private function render_recent_rows( array $rows ): void {
		if ( empty( $rows ) ) {
			echo '<tr><td colspan="6">直近の検知ログはありません。</td></tr>';
			return; }
		foreach ( $rows as $row ) {
			$risk         = (int) ( $row['risk'] ?? 0 );
			$risk_class   = $risk >= 80 ? 'danger' : ( $risk >= 50 ? 'watch' : 'safe' );
			$raw_time     = (string) ( $row['time'] ?? '' );
			$time_ts      = $raw_time ? strtotime( $raw_time . ' UTC' ) : false;
			$display_time = $time_ts ? wp_date( 'Y-m-d H:i:s', $time_ts ) : $raw_time;
			$details      = array();
			foreach ( array_slice( (array) ( $row['explanations'] ?? array() ), 0, 4 ) as $explanation ) {
				$label     = (string) ( $explanation['label'] ?? '' );
				$points    = (int) ( $explanation['points'] ?? 0 );
				$details[] = $label . ( $points > 0 ? ' (+' . $points . ')' : '' );
			}
			echo '<tr><td>' . esc_html( $display_time ) . '</td><td>' . esc_html( (string) ( $row['label'] ?? '' ) ) . '</td><td><span class="kp-risk-pill ' . esc_attr( $risk_class ) . '">' . esc_html( (string) $risk ) . '</span><br><small>' . esc_html( (string) ( $row['level_label'] ?? '' ) ) . '</small></td><td><code>' . esc_html( (string) ( $row['source'] ?? '' ) ) . '</code></td><td>' . ( ! empty( $row['blocked'] ) ? '<strong>遮断</strong>' : '記録' ) . '</td><td>' . esc_html( implode( '、', $details ) ) . '</td></tr>';
		}
	}

	public function monitor_ajax(): void {
		check_ajax_referer( 'kprotect_monitor', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array(), 403 ); }
		$s      = $this->stats();
		$status = $s['max_risk'] >= 80 ? '危険' : ( $s['hour'] > 0 ? '監視中' : '安全' );
		$class  = $s['max_risk'] >= 80 ? 'danger' : ( $s['hour'] > 0 ? 'watch' : 'safe' );
		wp_send_json_success(
			array(
				'hour'      => $s['hour'],
				'risk'      => $s['max_risk'],
				'status'    => $status,
				'class'     => $class,
				'updated'   => wp_date( 'H:i:s' ),
				'dashboard' => $this->analytics->snapshot( 12 ),
			)
		);
	}

	/**
	 * Answer an administrator question using local dashboard data.
	 *
	 * @return void
	 */
	public function ai_assistant_ajax(): void {
		check_ajax_referer( 'kprotect_monitor', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => '権限がありません。' ), 403 );
		}
		$question = isset( $_POST['question'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['question'] ) ) : '';
		$data     = $this->analytics->snapshot( 24 );
		$answer   = KProtect_AI_Provider_Manager::answer( $question, (array) ( $data['intelligence'] ?? array() ) );
		wp_send_json_success( $answer );
	}


	/** Output one RFC 4180-compatible CSV row without direct filesystem calls. */
	private function output_csv_row( array $fields ): void {
		$encoded = array_map(
			static function ( $field ): string {
				$value = (string) $field;
				return '"' . str_replace( '"', '""', $value ) . '"';
			},
			$fields
		);
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV is a non-HTML response; every field is RFC 4180 quoted and embedded quotes are doubled above.\n		echo implode( ',', $encoded ) . "\r\n";
	}

	/**
	 * Export aggregate incident information as a privacy-preserving CSV file.
	 *
	 * The export intentionally excludes raw IP addresses, request paths,
	 * request bodies, passwords, and file contents.
	 *
	 * @return void
	 */
	public function export_incident_csv(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		check_admin_referer( 'kprotect_export_incident_csv' );

		$data         = $this->analytics->snapshot( 24 );
		$intelligence = (array) ( $data['intelligence'] ?? array() );
		$report       = (array) ( $intelligence['incident_report'] ?? array() );
		$queue        = (array) ( $intelligence['incident_queue'] ?? array() );
		$filename     = 'kprotect-incident-report-' . gmdate( 'Ymd-His' ) . '.csv';

		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

		echo "\xEF\xBB\xBF"; // UTF-8 BOM for spreadsheet applications.
		$this->output_csv_row( array( 'KProtect AI Security Incident Report' ) );
		$this->output_csv_row( array( 'Generated at (UTC)', gmdate( 'Y-m-d H:i:s' ) ) );
		$this->output_csv_row( array( 'Period', (string) ( $report['period'] ?? '直近24時間' ) ) );
		$this->output_csv_row( array( 'Detected', (int) ( $report['total'] ?? 0 ) ) );
		$this->output_csv_row( array( 'Blocked', (int) ( $report['blocked'] ?? 0 ) ) );
		$this->output_csv_row( array( 'Unblocked', (int) ( $report['unblocked'] ?? 0 ) ) );
		$this->output_csv_row( array( 'Maximum risk', (int) ( $report['max_risk'] ?? 0 ) ) );
		$this->output_csv_row( array( 'Summary', (string) ( $report['summary'] ?? '' ) ) );
		$this->output_csv_row( array() );
		$this->output_csv_row( array( 'Priority', 'Event', 'Count', 'Maximum risk', 'Unblocked', 'Reason', 'Recommended action' ) );

		foreach ( $queue as $item ) {
			$this->output_csv_row(
				array(
					(string) ( $item['priority'] ?? 'D' ),
					(string) ( $item['label'] ?? '' ),
					(int) ( $item['count'] ?? 0 ),
					(int) ( $item['max_risk'] ?? 0 ),
					(int) ( $item['unblocked_count'] ?? 0 ),
					(string) ( $item['reason'] ?? '' ),
					(string) ( $item['action'] ?? '' ),
				)
			);
		}
		exit;
	}

	public function incidents(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only incident time filter; no state is changed.
		$hours = max( 1, min( 168, absint( wp_unslash( $_GET['hours'] ?? 24 ) ) ) );
		$items = $this->incidents->recent( $hours, 100 );
		$this->header( 'インシデントセンター' );
		echo '<p class="kp-ui-description">関連する検知を攻撃元と種類ごとに30分単位でまとめています。ログ自体は変更しません。</p>';

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect status flag.
		$distributed_test_status = isset( $_GET['kp_distributed_test'] )
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect status flag.
			? sanitize_key( wp_unslash( (string) $_GET['kp_distributed_test'] ) )
			: '';

		if ( 'created' === $distributed_test_status ) {
			echo '<div class="notice notice-success inline"><p>分散ログイン攻撃の統合テストデータを1件作成しました。通知やIP遮断は実行していません。</p></div>';
		} elseif ( 'deleted' === $distributed_test_status ) {
			echo '<div class="notice notice-success inline"><p>分散ログイン攻撃の統合テストデータを削除しました。</p></div>';
		}

		echo '<section class="kp-panel">';
		echo '<h2>分散ログイン攻撃 統合テスト</h2>';
		echo '<p class="kp-ui-description">外部通知やIP遮断を行わず、専用マーカー付きのテストログと通知センター内のテスト通知だけを作成し、インシデント・レポート・通知の連携と重複統合を確認します。</p>';
		echo '<p>';
		echo '<a class="button button-primary" href="' . esc_url(
			wp_nonce_url(
				admin_url( 'admin-post.php?action=kprotect_create_distributed_test' ),
				'kprotect_create_distributed_test'
			)
		) . '">テストデータを作成</a> ';

		echo '<a class="button button-secondary" href="' . esc_url(
			wp_nonce_url(
				admin_url( 'admin-post.php?action=kprotect_create_distributed_cooldown_test' ),
				'kprotect_create_distributed_cooldown_test'
			)
		) . '">外部通知クールダウンテスト</a> ';
		echo '<a class="button button-secondary" href="' . esc_url(
			wp_nonce_url(
				admin_url( 'admin-post.php?action=kprotect_create_webhook_retry_test' ),
				'kprotect_create_webhook_retry_test'
			)
		) . '">WEBHOOK再試行テスト</a> ';
		echo '<a class="button" href="' . esc_url(
			wp_nonce_url(
				admin_url( 'admin-post.php?action=kprotect_delete_distributed_test' ),
				'kprotect_delete_distributed_test'
			)
		) . '">テストデータを削除</a>';
		echo '</p></section>';

		echo '<form method="get"><input type="hidden" name="page" value="kprotect-incidents"><select name="hours"><option value="24" ' . selected( $hours, 24, false ) . '>直近24時間</option><option value="72" ' . selected( $hours, 72, false ) . '>直近3日</option><option value="168" ' . selected( $hours, 168, false ) . '>直近7日</option></select> <button class="button">表示</button></form>';
		if ( empty( $items ) ) {
			echo '<div class="notice notice-success inline"><p>対象期間にインシデントはありません。</p></div></div>';
			return; }
		echo '<table class="widefat striped kp-incident-table"><thead><tr><th>状態</th><th>種類</th><th>期間</th><th>攻撃元</th><th>件数</th><th>最大危険度</th><th>遮断</th><th>根拠</th></tr></thead><tbody>';
		foreach ( $items as $i ) {
			$status = 'active' === $i['status'] ? '継続中' : '沈静化';
			echo '<tr><td><strong>' . esc_html( $status ) . '</strong></td><td>' . esc_html( (string) $i['label'] ) . '</td><td>' . esc_html( (string) $i['first_seen'] ) . '<br>〜 ' . esc_html( (string) $i['last_seen'] ) . '</td><td><code>' . esc_html( (string) $i['ip'] ) . '</code></td><td>' . esc_html( (string) $i['events'] ) . '</td><td>' . esc_html( (string) $i['max_risk'] ) . '</td><td>' . esc_html( (string) $i['blocked'] ) . '</td><td>' . esc_html( implode( ', ', (array) $i['reasons'] ) ) . '</td></tr>';
		}
		echo '</tbody></table><p class="description">「沈静化」は直近30分に同じ攻撃元・種類の追加検知がない状態です。侵害が解決したことを保証する表示ではありません。</p></div>';
	}

	public function logs(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'kprotect_logs';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only security-log filters; no state is changed.
		$type = sanitize_key( wp_unslash( $_GET['event_type'] ?? '' ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only security-log filter; no state is changed.
		$blocked = isset( $_GET['blocked'] ) ? sanitize_text_field( wp_unslash( $_GET['blocked'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only security-log filter; no state is changed.
		$min_risk = max( 0, min( 100, absint( wp_unslash( $_GET['min_risk'] ?? 0 ) ) ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only security-log search term; no state is changed.
		$keyword        = sanitize_text_field( wp_unslash( $_GET['keyword'] ?? '' ) );
		$type_filter    = '' !== $type ? 1 : 0;
		$blocked_filter = ( '1' === $blocked || '0' === $blocked ) ? 1 : 0;
		$blocked_value  = $blocked_filter ? (int) $blocked : 0;
		$keyword_filter = '' !== $keyword ? 1 : 0;
		$like           = '%' . $wpdb->esc_like( $keyword ) . '%';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin security-log view intentionally reads the latest KProtect-owned log rows; queries are prepared and bounded.
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				' SELECT * FROM %i
				  WHERE ( %d = 0 OR event_type = %s )
				    AND ( %d = 0 OR blocked = %d )
				    AND risk_score >= %d
				    AND ( %d = 0 OR request_path LIKE %s OR reasons LIKE %s OR ip_address LIKE %s OR ip_hash LIKE %s )
				  ORDER BY id DESC LIMIT 300',
				$table,
				$type_filter,
				$type,
				$blocked_filter,
				$blocked_value,
				$min_risk,
				$keyword_filter,
				$like,
				$like,
				$like,
				$like
			)
		);
		$types = $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT event_type FROM %i ORDER BY event_type ASC', $table ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$this->header( 'セキュリティログ' );
		echo '<form method="get" class="kp-log-filter"><input type="hidden" name="page" value="kprotect-logs"><select name="event_type"><option value="">すべての種類</option>';
		foreach ( $types as $event_type ) {
			echo '<option value="' . esc_attr( $event_type ) . '" ' . selected( $type, $event_type, false ) . '>' . esc_html( $event_type ) . '</option>'; }
		echo '</select> <select name="blocked"><option value="">遮断状態すべて</option><option value="1" ' . selected( $blocked, '1', false ) . '>遮断あり</option><option value="0" ' . selected( $blocked, '0', false ) . '>遮断なし</option></select> <label>最低危険度 <input type="number" min="0" max="100" name="min_risk" value="' . esc_attr( (string) $min_risk ) . '" class="small-text"></label> <input type="search" name="keyword" value="' . esc_attr( $keyword ) . '" placeholder="IP・パス・理由"> <button class="button button-primary">検索</button> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=kprotect-logs' ) ) . '">解除</a></form>';
		echo '<p>' . esc_html( (string) count( $rows ) ) . '件を表示しています（最大300件）。</p><table class="widefat striped"><thead><tr><th>日時</th><th>種類</th><th>危険度</th><th>遮断</th><th>IP</th><th>パス</th><th>理由</th></tr></thead><tbody>';
		if ( empty( $rows ) ) {
			echo '<tr><td colspan="7">該当するログはありません。</td></tr>'; }
		foreach ( $rows as $r ) {
			$reasons = json_decode( $r->reasons, true );
			$event   = KProtect_Risk_Score_Calculator::explain_event(
				(string) $r->event_type,
				is_array( $reasons ) ? $reasons : array(),
				(int) $r->risk_score,
				! empty( $r->blocked )
			);
			$level   = (string) $event['level'];
			$items   = (array) $event['items'];
			echo '<tr>';
			echo '<td>' . esc_html( ( $ts = strtotime( (string) $r->created_at . ' UTC' ) ) ? wp_date( 'Y-m-d H:i:s', $ts ) : (string) $r->created_at ) . '</td>';
			echo '<td><span class="kp-event-badge">' . esc_html( KProtect_Risk_Score_Calculator::event_label( (string) $r->event_type ) ) . '</span></td>';
			echo '<td><span class="kp-risk-badge kp-risk-' . esc_attr( $level ) . '"><strong>' . esc_html( (string) $r->risk_score ) . '</strong> ' . esc_html( (string) $event['level_label'] ) . '</span></td>';
			echo '<td>' . ( $r->blocked ? '<span class="kp-status-badge kp-status-blocked">遮断</span>' : '<span class="kp-status-badge kp-status-audit">監査</span>' ) . '</td>';
			echo '<td>' . esc_html( $r->ip_address ?: substr( $r->ip_hash, 0, 12 ) . '…' ) . '</td>';
			echo '<td><code class="kp-log-path">' . esc_html( $r->request_path ) . '</code></td>';
			echo '<td><details class="kp-explanation"><summary><strong>' . esc_html( (string) $event['title'] ) . '</strong><span>' . esc_html( (string) $event['summary'] ) . '</span></summary><div class="kp-explanation-body">';
			foreach ( $items as $item ) {
				$points = (int) ( $item['points'] ?? 0 );
				echo '<div class="kp-explanation-item"><span>' . esc_html( (string) ( $item['label'] ?? '' ) ) . '</span><strong>' . esc_html( (string) ( $item['value'] ?? '' ) ) . ( $points > 0 ? ' (+' . esc_html( (string) $points ) . ')' : '' ) . '</strong></div>';
			}
			$advisor = KProtect_Event_Advisor::analyze(
				(string) $r->event_type,
				is_array( $reasons ) ? $reasons : array(),
				(int) $r->risk_score,
				! empty( $r->blocked ),
				(string) $r->request_path
			);
			echo '<p class="kp-recommendation-text"><strong>推奨：</strong>' . esc_html( (string) $event['recommendation'] ) . '</p>';
			echo '<section class="kp-event-advisor kp-advisor-' . esc_attr( (string) $advisor['level'] ) . '"><div class="kp-event-advisor-heading"><strong>ローカルAI診断</strong><span>判断材料の確度：' . esc_html( (string) $advisor['confidence_label'] ) . '</span></div>';
			echo '<h4>' . esc_html( (string) $advisor['headline'] ) . '</h4><p>' . esc_html( (string) $advisor['what_happened'] ) . '</p><p><strong>評価：</strong>' . esc_html( (string) $advisor['assessment'] ) . '</p>';
			echo '<p><strong>誤検知の可能性：</strong>' . esc_html( (string) $advisor['false_positive_note'] ) . '</p><ol>';
			foreach ( (array) $advisor['actions'] as $action ) {
				echo '<li>' . esc_html( (string) $action ) . '</li>'; }
			echo '</ol><small>' . esc_html( (string) $advisor['privacy_note'] ) . '</small></section></div></details></td>';
			echo '</tr>';
		}
		echo '</tbody></table></div>';
	}
	public function blocks(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'kprotect_blocks';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Active block list must reflect current KProtect-owned block state; query is prepared and bounded.
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE active = 1 ORDER BY id DESC LIMIT 200', $table ) );
		$this->header( 'ブロックIP' );
		echo '<table class="widefat striped"><thead><tr><th>登録日時</th><th>IP</th><th>理由</th><th>期限</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_unblock&id=' . (int) $r->id ), 'kprotect_unblock_' . $r->id );
			echo '<tr><td>' . esc_html( ( $ts = strtotime( (string) $r->created_at . ' UTC' ) ) ? wp_date( 'Y-m-d H:i:s', $ts ) : (string) $r->created_at ) . '</td><td>' . esc_html( $r->ip_address ?: substr( $r->ip_hash, 0, 12 ) . '…' ) . '</td><td>' . esc_html( $r->reason ) . '</td><td>' . esc_html( $r->expires_at && ( $ets = strtotime( (string) $r->expires_at . ' UTC' ) ) ? wp_date( 'Y-m-d H:i:s', $ets ) : (string) $r->expires_at ) . '</td><td><a class="button" href="' . esc_url( $url ) . '">解除</a></td></tr>';}
		echo '</tbody></table></div>';
	}
	public function unblock(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}$id = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0;
		check_admin_referer( 'kprotect_unblock_' . $id );
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Explicit administrator unblock action on a KProtect-owned table; capability and nonce are verified above.
		$wpdb->update( $wpdb->prefix . 'kprotect_blocks', array( 'active' => 0 ), array( 'id' => $id ), array( '%d' ), array( '%d' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-blocks' ) );
		exit; }
	public function integrity(): void {
		$baseline = (array) get_option( 'kprotect_integrity_baseline', array() );
		$changes  = (array) get_option( 'kprotect_integrity_last_result', array() );
		$this->header( '重要ファイルの改ざん検知' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect status flag.
		if ( isset( $_GET['kp_done'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect status flag.
			$done = sanitize_key( wp_unslash( $_GET['kp_done'] ) );
			echo '<div class="notice notice-success"><p>' . esc_html( 'baseline' === $done ? '基準状態を保存しました。' : '検査を実行しました。' ) . '</p></div>'; }
		echo '<p class="kp-ui-description">wp-config.php、.htaccess、WordPress起動ファイル、現在のテーマ主要ファイルをSHA-256で比較します。ファイルの内容は外部へ送信しません。</p>';
		echo '<div class="kp-ui-toolbar"><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_integrity_scan' ), 'kprotect_integrity_scan' ) ) . '">今すぐ検査</a> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_integrity_baseline' ), 'kprotect_integrity_baseline' ) ) . '">現在を新しい基準にする</a></div>';
		echo '<p class="kp-ui-meta"><strong>基準ファイル数：</strong>' . esc_html( (string) count( $baseline ) ) . '　<strong>最終検査：</strong>' . esc_html( (string) get_option( 'kprotect_integrity_last_scan', '未実行' ) ) . '</p>';
		if ( empty( $baseline ) ) {
			echo '<div class="notice notice-warning inline"><p>まだ基準状態がありません。「現在を新しい基準にする」を押してください。</p></div>';
		} elseif ( empty( $changes ) ) {
			echo '<div class="notice notice-success inline"><p>変更は検出されていません。</p></div>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>ファイル</th><th>状態</th></tr></thead><tbody>';
			foreach ( $changes as $c ) {
				echo '<tr><td><code>' . esc_html( $c['file'] ) . '</code></td><td>' . esc_html( $c['type'] ) . '</td></tr>';
			}echo '</tbody></table><p class="description">WordPressやテーマを正規更新した直後にも変更が出ます。内容を確認後、新しい基準を作成してください。</p>';}
		echo '</div>';
	}
	public function integrity_baseline(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}check_admin_referer( 'kprotect_integrity_baseline' );
		$this->scanner->create_baseline();
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-integrity&kp_done=baseline' ) );
		exit; }
	public function integrity_scan(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}check_admin_referer( 'kprotect_integrity_scan' );
		$this->scanner->scan();
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-integrity&kp_done=scan' ) );
		exit; }


	public function assistant(): void {
		$report  = $this->assistant->report();
		$metrics = (array) $report['metrics'];
		$level   = (string) $report['risk_level'];
		$this->header( 'KProtect Advisor' );
		echo '<p class="kp-ui-description">ログ、設定診断、改ざん検知、uploadsスキャンを統合し、優先順位付きの対応計画を作成します。データは外部AIサービスへ送信しません。</p>';
		echo '<section class="kp-assistant-hero kp-level-' . esc_attr( $level ) . '"><div><span>現在の安全度</span><strong>' . esc_html( (string) $report['safety_score'] ) . '<small>/100</small></strong></div><div><span>総合リスク</span><strong>' . esc_html( (string) $report['risk_label'] ) . '</strong></div><p>' . esc_html( (string) $report['summary'] ) . '</p></section>';
		$trend = (array) ( $report['trend'] ?? array() );
		echo '<div class="kprotect-cards kp-four">';
		$change       = $report['change_percent'];
		$change_label = null === $change ? '比較データなし' : ( (int) $change >= 0 ? '+' : '' ) . (int) $change . '%';
		foreach ( array(
			'本日の検知' => (int) ( $metrics['today_events'] ?? 0 ),
			'昨日比'   => $change_label,
			'7日間傾向' => (string) ( $trend['label'] ?? '横ばい' ),
			'未読通知'  => (int) ( $metrics['unread_notifications'] ?? 0 ),
		) as $label => $value ) {
			echo '<div class="kprotect-card"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( (string) $value ) . '</strong></div>';
		}
		echo '</div>';

		echo '<section class="kp-panel"><div class="kp-panel-heading"><h2>セキュリティ健康度</h2><span class="description">改善点を分野別に確認できます</span></div><div class="kp-domain-grid">';
		foreach ( (array) ( $report['domains'] ?? array() ) as $domain ) {
			$score = (int) ( $domain['score'] ?? 0 );
			echo '<article class="kp-domain kp-domain-' . esc_attr( (string) ( $domain['status'] ?? 'watch' ) ) . '"><div><strong>' . esc_html( (string) ( $domain['label'] ?? '' ) ) . '</strong><span>' . esc_html( (string) ( $domain['description'] ?? '' ) ) . '</span></div><b>' . esc_html( (string) $score ) . '</b><div class="kp-domain-meter"><i style="width:' . esc_attr( (string) $score ) . '%"></i></div></article>';
		}
		echo '</div></section>';

		echo '<div class="kp-assistant-grid"><section class="kp-panel"><h2>優先対応プラン</h2>';
		foreach ( (array) $report['recommendations'] as $item ) {
			$url = admin_url( 'admin.php?page=' . sanitize_key( (string) $item['page'] ) );
			echo '<article class="kp-recommendation kp-rec-' . esc_attr( (string) $item['severity'] ) . '"><div><div class="kp-rec-meta"><span>優先度 ' . esc_html( (string) $item['priority'] ) . '/5</span><span>目安：' . esc_html( (string) $item['due'] ) . '</span></div><h3>' . esc_html( (string) $item['title'] ) . '</h3><p>' . esc_html( (string) $item['message'] ) . '</p><p class="kp-benefit"><strong>期待される効果：</strong>' . esc_html( (string) $item['benefit'] ) . '</p></div><a class="button" href="' . esc_url( $url ) . '">確認する</a></article>';
		}
		echo '</section><section class="kp-panel"><h2>Advisorの見解</h2><p>' . esc_html( (string) ( $trend['message'] ?? '' ) ) . '</p>';
		echo '<h3>リスク加点</h3>';
		foreach ( array(
			'攻撃状況' => 'attack',
			'設定'   => 'configuration',
			'ファイル' => 'files',
		) as $label => $key ) {
			$value = (int) ( $report['components'][ $key ] ?? 0 );
			echo '<div class="kp-risk-component"><span>' . esc_html( $label ) . '</span><div><i style="width:' . esc_attr( (string) min( 100, $value * 3 ) ) . '%"></i></div><strong>+' . esc_html( (string) $value ) . '</strong></div>';
		}
		echo '<p class="description">スコアは管理判断を支援する指標です。侵害の有無を自動断定するものではありません。</p></section></div>';

		$types = (array) ( $metrics['top_event_types'] ?? array() );
		echo '<section class="kp-panel"><h2>本日の主な検知</h2>';
		if ( empty( $types ) ) {
			echo '<p>本日の検知ログはありません。</p>'; } else {
			echo '<table class="widefat striped"><thead><tr><th>種類</th><th>件数</th></tr></thead><tbody>';
			foreach ( $types as $type ) {
				echo '<tr><td>' . esc_html( (string) $type['event_type'] ) . '</td><td>' . esc_html( (string) $type['total'] ) . '</td></tr>';
			} echo '</tbody></table>'; }
			echo '</section><p class="description">KProtect Advisorは説明可能なルールと統計による支援機能です。機械学習モデルではありません。</p></div>';
	}

	/**
	 * Create one notification-free distributed login integration test log.
	 *
	 * @return void
	 */
	public function create_distributed_test(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kprotect-ai-security' ) );
		}

		check_admin_referer( 'kprotect_create_distributed_test' );

		global $wpdb;

		$table  = $wpdb->prefix . 'kprotect_logs';
		$marker = 'kprotect_distributed_integration_test';
		$like   = '%' . $wpdb->esc_like( $marker ) . '%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Removes only KProtect-owned integration-test rows before creating one fresh test event.
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE reasons LIKE %s',
				$table,
				$like
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Inserts one local KProtect integration-test row without invoking notification delivery.
		$wpdb->insert(
			$table,
			array(
				'created_at'     => current_time( 'mysql', true ),
				'event_type'     => 'login_failed',
				'risk_score'     => 80,
				'ip_hash'        => KProtect_Utils::ip_hash( '203.0.113.250' ),
				'ip_address'     => '',
				'request_method' => 'POST',
				'request_path'   => '/wp-login.php?kprotect-integration-test=1',
				'reasons'        => wp_json_encode(
					array(
						'failed_login',
						'distributed_account_attack',
						$marker,
					),
					JSON_UNESCAPED_UNICODE
				),
				'blocked'        => 0,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d' )
		);

		$notification_reasons = array(
			'failed_login',
			'attempt_8',
			'distributed_account_attack',
			$marker,
		);

		$notification_table = $wpdb->prefix . 'kprotect_notifications';
		$fingerprint        = KProtect_Notification_Center::fingerprint(
			'login_failed',
			$notification_reasons
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only check used only to vary integration-test attempt metadata while exercising notification deduplication.
		$existing_notification = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE fingerprint = %s',
				$notification_table,
				$fingerprint
			)
		);

		if ( $existing_notification > 0 ) {
			$notification_reasons[1] = 'attempt_9';
		}

		$this->notifications->record(
			'login_failed',
			80,
			$notification_reasons,
			true
		);

		KProtect_Security_Analyst::clear_cache();

		wp_safe_redirect(
			add_query_arg(
				'kp_distributed_test',
				'created',
				admin_url( 'admin.php?page=kprotect-incidents' )
			)
		);
		exit;
	}

	/**
	 * Queue a webhook notification for retry integration testing.
	 *
	 * This uses the normal notification queue without performing a real
	 * security event or IP block.
	 *
	 * @return void
	 */
	public function create_webhook_retry_test(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kprotect-ai-security' ) );
		}

		check_admin_referer( 'kprotect_create_webhook_retry_test' );

		$this->queue->enqueue(
			'webhook',
			'retry_test',
			80,
			array(
				'manual_test',
				'webhook_retry_check',
				'kprotect_webhook_retry_test',
			),
			true
		);

		wp_safe_redirect(
			add_query_arg(
				'kp_webhook_retry_test',
				'queued',
				admin_url( 'admin.php?page=kprotect-queue' )
			)
		);
		exit;
	}

	/**
	 * Queue a normal distributed-login notification for cooldown testing.
	 *
	 * This intentionally uses the normal notification pipeline but does not
	 * perform a real login attempt or IP block.
	 *
	 * @return void
	 */
	public function create_distributed_cooldown_test(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kprotect-ai-security' ) );
		}

		check_admin_referer( 'kprotect_create_distributed_cooldown_test' );

		global $wpdb;

		$queue_table = $wpdb->prefix . 'kprotect_notification_queue';
		$marker      = 'kprotect_distributed_cooldown_test';
		$like        = '%' . $wpdb->esc_like( $marker ) . '%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only integration-test lookup used only to vary attempt metadata.
		$existing = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE reasons LIKE %s',
				$queue_table,
				$like
			)
		);

		$reasons = array(
			'failed_login',
			$existing > 0 ? 'attempt_9' : 'attempt_8',
			'distributed_account_attack',
			$marker,
		);

		$this->queue->enqueue(
			'email',
			'login_failed',
			80,
			$reasons
		);

		wp_safe_redirect(
			add_query_arg(
				'kp_distributed_cooldown_test',
				'queued',
				admin_url( 'admin.php?page=kprotect-queue' )
			)
		);

		exit;
	}

	/**
	 * Delete distributed login integration test logs only.
	 *
	 * @return void
	 */
	public function delete_distributed_test(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kprotect-ai-security' ) );
		}

		check_admin_referer( 'kprotect_delete_distributed_test' );

		global $wpdb;

		$table  = $wpdb->prefix . 'kprotect_logs';
		$marker = 'kprotect_distributed_integration_test';
		$like   = '%' . $wpdb->esc_like( $marker ) . '%';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Deletes only KProtect-owned distributed integration-test rows identified by the dedicated marker.
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE reasons LIKE %s',
				$table,
				$like
			)
		);

		$notification_table = $wpdb->prefix . 'kprotect_notifications';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Deletes only integration-test notifications containing the dedicated KProtect test marker.
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE message LIKE %s',
				$notification_table,
				$like
			)
		);

		KProtect_Security_Analyst::clear_cache();

		wp_safe_redirect(
			add_query_arg(
				'kp_distributed_test',
				'deleted',
				admin_url( 'admin.php?page=kprotect-incidents' )
			)
		);
		exit;
	}
	public function firewall_self_test(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to perform this action.', 'kprotect-ai-security' ) );
		}

		check_admin_referer( 'kprotect_firewall_self_test' );

		$detector = new KProtect_Detector();
		$settings = KProtect_Utils::settings();

		$tests = array(
			'normal'         => array(
				'label'    => '正常なリクエスト',
				'target'   => '/about/?page=2',
				'expected' => '',
			),
			'sqli'           => array(
				'label'    => 'SQL Injection',
				'target'   => '/search/?q=1 UNION SELECT password FROM users',
				'expected' => 'sql_injection',
			),
			'xss'            => array(
				'label'    => 'XSS',
				'target'   => '/search/?q=<script>alert(1)</script>',
				'expected' => 'xss',
			),
			'traversal'      => array(
				'label'    => 'Path Traversal',
				'target'   => '/../../etc/passwd',
				'expected' => 'path_traversal',
			),
			'code_execution' => array(
				'label'    => 'Code Execution',
				'target'   => '/?cmd=system(id)',
				'expected' => 'code_execution',
			),
			'sensitive_file' => array(
				'label'    => '機密ファイルアクセス',
				'target'   => '/wp-config.php',
				'expected' => 'sensitive_file',
			),
			'webshell'       => array(
				'label'    => 'Webshell Probe',
				'target'   => '/wso.php',
				'expected' => 'webshell_probe',
			),
		);

		$results = array();

		foreach ( $tests as $key => $test ) {
			$result   = $detector->inspect_target( $test['target'] );
			$decision = KProtect_Firewall::evaluate_result(
				$result,
				$settings,
				false
			);
			$reasons  = (array) ( $decision['reasons'] ?? array() );

			if ( '' === $test['expected'] ) {
				$passed = (int) ( $decision['score'] ?? 0 ) < 25;
			} else {
				$passed = in_array( $test['expected'], $reasons, true );
			}

			$results[ $key ] = array(
				'label'           => $test['label'],
				'passed'          => $passed,
				'score'           => (int) ( $decision['score'] ?? 0 ),
				'reasons'         => $reasons,
				'expected'        => $test['expected'],
				'log'             => ! empty( $decision['log'] ),
				'block'           => ! empty( $decision['block'] ),
				'log_threshold'   => (int) ( $decision['log_threshold'] ?? 0 ),
				'block_threshold' => (int) ( $decision['block_threshold'] ?? 0 ),
			);
		}

		set_transient(
			'kprotect_firewall_self_test_' . get_current_user_id(),
			$results,
			5 * MINUTE_IN_SECONDS
		);

		$allowlist_tests = array(
			'exact_match'     => array(
				'label'    => '完全一致',
				'target'   => '/payment/callback',
				'expected' => true,
			),
			'directory_child' => array(
				'label'    => '配下パス',
				'target'   => '/wp-json/example/test',
				'expected' => true,
			),
			'similar_prefix'  => array(
				'label'    => '類似パス誤一致防止',
				'target'   => '/wp-json/example2/test',
				'expected' => false,
			),
			'normal_path'     => array(
				'label'    => '通常パス',
				'target'   => '/about/',
				'expected' => false,
			),
		);

		$allowlist_results = array();

		foreach ( $allowlist_tests as $key => $test ) {
			$excluded = KProtect_Utils::is_excluded_path( $test['target'] );

			$allowlist_results[ $key ] = array(
				'label'    => $test['label'],
				'target'   => $test['target'],
				'excluded' => $excluded,
				'expected' => $test['expected'],
				'passed'   => $excluded === $test['expected'],
			);
		}

		set_transient(
			'kprotect_firewall_allowlist_self_test_' . get_current_user_id(),
			$allowlist_results,
			5 * MINUTE_IN_SECONDS
		);

		$login_tests = array(
			'normal'             => array(
				'label'          => '通常状態',
				'ip_count'       => 1,
				'username_count' => 1,
				'block_ip'       => false,
				'account_attack' => false,
			),
			'ip_below_threshold' => array(
				'label'          => 'IP遮断しきい値直前',
				'ip_count'       => max( 1, (int) $settings['login_failures'] - 1 ),
				'username_count' => 1,
				'block_ip'       => false,
				'account_attack' => false,
			),
			'ip_threshold'       => array(
				'label'          => 'IP遮断しきい値到達',
				'ip_count'       => max( 2, (int) $settings['login_failures'] ),
				'username_count' => 1,
				'block_ip'       => true,
				'account_attack' => false,
			),
			'account_below'      => array(
				'label'          => '分散攻撃しきい値直前',
				'ip_count'       => 1,
				'username_count' => max( 2, (int) $settings['login_failures'] ) + 2,
				'block_ip'       => false,
				'account_attack' => false,
			),
			'account_threshold'  => array(
				'label'          => '分散型アカウント攻撃',
				'ip_count'       => 1,
				'username_count' => max( 2, (int) $settings['login_failures'] ) + 3,
				'block_ip'       => false,
				'account_attack' => true,
			),
			'both_thresholds'    => array(
				'label'          => 'IP攻撃＋分散攻撃',
				'ip_count'       => max( 2, (int) $settings['login_failures'] ),
				'username_count' => max( 2, (int) $settings['login_failures'] ) + 3,
				'block_ip'       => true,
				'account_attack' => true,
			),
		);

		$login_results = array();

		foreach ( $login_tests as $key => $test ) {
			$decision = KProtect_Login_Guard::evaluate_attempt(
				(int) $test['ip_count'],
				(int) $test['username_count'],
				$settings
			);

			$passed =
				(bool) $decision['block_ip'] === (bool) $test['block_ip']
				&&
				(bool) $decision['account_attack'] === (bool) $test['account_attack'];

			$login_results[ $key ] = array(
				'label'             => $test['label'],
				'passed'            => $passed,
				'ip_count'          => (int) $decision['ip_count'],
				'username_count'    => (int) $decision['username_count'],
				'block_ip'          => ! empty( $decision['block_ip'] ),
				'account_attack'    => ! empty( $decision['account_attack'] ),
				'ip_threshold'      => (int) $decision['ip_threshold'],
				'account_threshold' => (int) $decision['account_threshold'],
			);
		}

		set_transient(
			'kprotect_login_guard_self_test_' . get_current_user_id(),
			$login_results,
			5 * MINUTE_IN_SECONDS
		);

		$distributed_threshold = max(
			2,
			(int) $settings['login_failures']
		) + 3;

		$distributed_tests = array(
			'same_source_many_failures' => array(
				'label'        => '同一攻撃元から多数失敗',
				'failed_count' => $distributed_threshold,
				'source_count' => 1,
				'new_source'   => false,
				'distributed'  => false,
			),
			'below_threshold'           => array(
				'label'        => '分散攻撃しきい値直前',
				'failed_count' => max( 0, $distributed_threshold - 1 ),
				'source_count' => max( 0, $distributed_threshold - 1 ),
				'new_source'   => true,
				'distributed'  => false,
			),
			'at_threshold'              => array(
				'label'        => '分散攻撃しきい値到達',
				'failed_count' => $distributed_threshold,
				'source_count' => $distributed_threshold,
				'new_source'   => true,
				'distributed'  => true,
			),
			'many_failures_one_source'  => array(
				'label'        => '失敗多数・攻撃元1件',
				'failed_count' => $distributed_threshold,
				'source_count' => 1,
				'new_source'   => false,
				'distributed'  => false,
			),
		);

		$distributed_results = array();

		foreach ( $distributed_tests as $key => $test ) {
			$decision = KProtect_Login_Attack_Tracker::evaluate_aggregate(
				(int) $test['failed_count'],
				(int) $test['source_count'],
				(bool) $test['new_source'],
				(int) $settings['login_failures']
			);

			$distributed_results[ $key ] = array(
				'label'             => $test['label'],
				'passed'            => (bool) $decision['distributed'] === (bool) $test['distributed'],
				'failed_count'      => (int) $decision['failed_count'],
				'source_count'      => (int) $decision['source_count'],
				'distributed'       => ! empty( $decision['distributed'] ),
				'account_threshold' => (int) $decision['account_threshold'],
			);
		}

		set_transient(
			'kprotect_login_attack_tracker_self_test_' . get_current_user_id(),
			$distributed_results,
			5 * MINUTE_IN_SECONDS
		);

		wp_safe_redirect(
			add_query_arg(
				'kp_self_test',
				'done',
				admin_url( 'admin.php?page=kprotect-audit' )
			)
		);
		exit;
	}
	public function audit(): void {
		$checks              = $this->auditor->audit();
		$score               = $this->auditor->score( $checks );
		$self_results        = get_transient( 'kprotect_firewall_self_test_' . get_current_user_id() );
		$allowlist_results   = get_transient( 'kprotect_firewall_allowlist_self_test_' . get_current_user_id() );
		$login_results       = get_transient( 'kprotect_login_guard_self_test_' . get_current_user_id() );
		$distributed_results = get_transient( 'kprotect_login_attack_tracker_self_test_' . get_current_user_id() );

		$this->header( 'セキュリティ診断' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect status flag.
		if ( isset( $_GET['kp_self_test'] ) ) {
			echo '<div class="notice notice-success inline"><p>ファイアウォール自己診断を実行しました。</p></div>';
		}
		echo '<p class="kp-ui-description">WordPressとサーバー設定の一部を読み取り専用で確認します。設定変更は自動で行いません。</p>';
		echo '<div class="kprotect-score"><strong>' . esc_html( (string) $score ) . '</strong><span>/ 100</span><p>診断スコア</p></div>';
		echo '<table class="widefat striped kp-audit-table"><thead><tr><th>結果</th><th>項目</th><th>内容</th></tr></thead><tbody>';
		foreach ( $checks as $check ) {
			$status = ! empty( $check['passed'] ) ? '合格' : '要確認';
			$class  = ! empty( $check['passed'] ) ? 'pass' : esc_attr( $check['severity'] );
			echo '<tr><td><span class="kp-audit-status ' . esc_attr( $class ) . '">' . esc_html( $status ) . '</span></td><td><strong>' . esc_html( $check['label'] ) . '</strong></td><td>' . esc_html( $check['message'] ) . '</td></tr>';
		}
		echo '</tbody></table><p class="description">権限表示はホスティング環境によって取得結果が異なる場合があります。表示だけを根拠に権限を変更せず、提供会社の推奨値も確認してください。</p>';

		echo '<section class="kp-panel"><h2>KProtect ファイアウォール自己診断</h2>';
		echo '<p class="kp-ui-description">外部へ攻撃リクエストを送信せず、KProtect内部の検知エンジンだけを安全に確認します。IP遮断やセキュリティログへの攻撃記録は行いません。</p>';
		echo '<p><a class="button button-primary" href="' . esc_url(
			wp_nonce_url(
				admin_url( 'admin-post.php?action=kprotect_firewall_self_test' ),
				'kprotect_firewall_self_test'
			)
		) . '">自己診断を実行</a></p>';

		if ( is_array( $self_results ) && ! empty( $self_results ) ) {
			$passed_count = 0;

			foreach ( $self_results as $item ) {
				if ( ! empty( $item['passed'] ) ) {
					++$passed_count;
				}
			}

			$first_result    = reset( $self_results );
			$log_threshold   = (int) ( $first_result['log_threshold'] ?? 0 );
			$block_threshold = (int) ( $first_result['block_threshold'] ?? 0 );

			echo '<p><strong>結果：</strong>' . esc_html( (string) $passed_count ) . ' / ' . esc_html( (string) count( $self_results ) ) . ' 項目合格</p>';
			echo '<p class="kp-ui-meta"><strong>現在のログしきい値：</strong>' . esc_html( (string) $log_threshold ) . '　<strong>現在のブロックしきい値：</strong>' . esc_html( (string) $block_threshold ) . '</p>';
			echo '<table class="widefat striped"><thead><tr><th>結果</th><th>テスト</th><th>危険度</th><th>ログ</th><th>遮断</th><th>検知理由</th></tr></thead><tbody>';

			foreach ( $self_results as $item ) {
				$passed       = ! empty( $item['passed'] );
				$status       = $passed ? '合格' : '要確認';
				$class        = $passed ? 'pass' : 'high';
				$log_status   = ! empty( $item['log'] ) ? '対象' : '対象外';
				$block_status = ! empty( $item['block'] ) ? '対象' : '対象外';
				$reasons      = array_map(
					static fn( $reason ): string => KProtect_Risk_Score_Calculator::event_label( (string) $reason ),
					(array) ( $item['reasons'] ?? array() )
				);

				echo '<tr>';
				echo '<td><span class="kp-audit-status ' . esc_attr( $class ) . '">' . esc_html( $status ) . '</span></td>';
				echo '<td><strong>' . esc_html( (string) ( $item['label'] ?? '' ) ) . '</strong></td>';
				echo '<td>' . esc_html( (string) ( $item['score'] ?? 0 ) ) . '</td>';
				echo '<td>' . esc_html( $log_status ) . '</td>';
				echo '<td>' . esc_html( $block_status ) . '</td>';
				echo '<td>' . esc_html( empty( $reasons ) ? 'なし' : implode( ', ', $reasons ) ) . '</td>';
				echo '</tr>';
			}

			echo '</tbody></table>';

			if ( is_array( $allowlist_results ) && ! empty( $allowlist_results ) ) {
				$allowlist_passed = 0;

				foreach ( $allowlist_results as $item ) {
					if ( ! empty( $item['passed'] ) ) {
						++$allowlist_passed;
					}
				}

				echo '<h3 class="kp-ui-section-title">ファイアウォール除外パス診断</h3>';
				echo '<p><strong>結果：</strong>' . esc_html( (string) $allowlist_passed ) . ' / ' . esc_html( (string) count( $allowlist_results ) ) . ' 項目合格</p>';
				echo '<table class="widefat striped"><thead><tr><th>結果</th><th>テスト</th><th>対象パス</th><th>判定</th><th>期待値</th></tr></thead><tbody>';

				foreach ( $allowlist_results as $item ) {
					$passed   = ! empty( $item['passed'] );
					$status   = $passed ? '合格' : '要確認';
					$class    = $passed ? 'pass' : 'high';
					$excluded = ! empty( $item['excluded'] ) ? '除外' : '検査対象';
					$expected = ! empty( $item['expected'] ) ? '除外' : '検査対象';

					echo '<tr>';
					echo '<td><span class="kp-audit-status ' . esc_attr( $class ) . '">' . esc_html( $status ) . '</span></td>';
					echo '<td><strong>' . esc_html( (string) ( $item['label'] ?? '' ) ) . '</strong></td>';
					echo '<td><code>' . esc_html( (string) ( $item['target'] ?? '' ) ) . '</code></td>';
					echo '<td>' . esc_html( $excluded ) . '</td>';
					echo '<td>' . esc_html( $expected ) . '</td>';
					echo '</tr>';
				}

				echo '</tbody></table>';
			}

			if ( is_array( $login_results ) && ! empty( $login_results ) ) {
				$login_passed = 0;

				foreach ( $login_results as $item ) {
					if ( ! empty( $item['passed'] ) ) {
						++$login_passed;
					}
				}

				$first_login = reset( $login_results );

				echo '<h3 class="kp-ui-section-title">ログイン攻撃防御診断</h3>';
				echo '<p><strong>結果：</strong>' . esc_html( (string) $login_passed ) . ' / ' . esc_html( (string) count( $login_results ) ) . ' 項目合格</p>';
				echo '<p class="kp-ui-meta"><strong>IP遮断しきい値：</strong>' . esc_html( (string) ( $first_login['ip_threshold'] ?? 0 ) ) . '　<strong>分散攻撃しきい値：</strong>' . esc_html( (string) ( $first_login['account_threshold'] ?? 0 ) ) . '</p>';
				echo '<table class="widefat striped"><thead><tr><th>結果</th><th>テスト</th><th>IP失敗回数</th><th>アカウント失敗回数</th><th>IP遮断</th><th>分散攻撃</th></tr></thead><tbody>';

				foreach ( $login_results as $item ) {
					$passed         = ! empty( $item['passed'] );
					$status         = $passed ? '合格' : '要確認';
					$class          = $passed ? 'pass' : 'high';
					$block_status   = ! empty( $item['block_ip'] ) ? '対象' : '対象外';
					$account_status = ! empty( $item['account_attack'] ) ? '検知' : '未検知';

					echo '<tr>';
					echo '<td><span class="kp-audit-status ' . esc_attr( $class ) . '">' . esc_html( $status ) . '</span></td>';
					echo '<td><strong>' . esc_html( (string) ( $item['label'] ?? '' ) ) . '</strong></td>';
					echo '<td>' . esc_html( (string) ( $item['ip_count'] ?? 0 ) ) . '</td>';
					echo '<td>' . esc_html( (string) ( $item['username_count'] ?? 0 ) ) . '</td>';
					echo '<td>' . esc_html( $block_status ) . '</td>';
					echo '<td>' . esc_html( $account_status ) . '</td>';
					echo '</tr>';
				}

				echo '</tbody></table>';
			}

			if ( is_array( $distributed_results ) && ! empty( $distributed_results ) ) {
				$distributed_passed = 0;

				foreach ( $distributed_results as $item ) {
					if ( ! empty( $item['passed'] ) ) {
						++$distributed_passed;
					}
				}

				$first_distributed = reset( $distributed_results );

				echo '<h3 class="kp-ui-section-title">分散ログイン攻撃集計診断</h3>';
				echo '<p><strong>結果：</strong>' . esc_html( (string) $distributed_passed ) . ' / ' . esc_html( (string) count( $distributed_results ) ) . ' 項目合格</p>';
				echo '<p class="kp-ui-meta"><strong>分散攻撃しきい値：</strong>' . esc_html( (string) ( $first_distributed['account_threshold'] ?? 0 ) ) . '</p>';
				echo '<table class="widefat striped"><thead><tr><th>結果</th><th>テスト</th><th>失敗回数</th><th>攻撃元数</th><th>分散攻撃</th></tr></thead><tbody>';

				foreach ( $distributed_results as $item ) {
					$passed      = ! empty( $item['passed'] );
					$status      = $passed ? '合格' : '要確認';
					$class       = $passed ? 'pass' : 'high';
					$distributed = ! empty( $item['distributed'] ) ? '検知' : '未検知';

					echo '<tr>';
					echo '<td><span class="kp-audit-status ' . esc_attr( $class ) . '">' . esc_html( $status ) . '</span></td>';
					echo '<td><strong>' . esc_html( (string) ( $item['label'] ?? '' ) ) . '</strong></td>';
					echo '<td>' . esc_html( (string) ( $item['failed_count'] ?? 0 ) ) . '</td>';
					echo '<td>' . esc_html( (string) ( $item['source_count'] ?? 0 ) ) . '</td>';
					echo '<td>' . esc_html( $distributed ) . '</td>';
					echo '</tr>';
				}

				echo '</tbody></table>';
			}
		} else {
			echo '<div class="notice notice-info inline"><p>まだ自己診断を実行していません。</p></div>';
		}

		echo '</section></div>';
	}

	public function malware(): void {
		$result = (array) get_option( 'kprotect_malware_last_result', array() );
		$this->header( 'uploads高度スキャン' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect status flag.
		if ( isset( $_GET['kp_done'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect status flag.
			$message = 'baseline' === sanitize_key( wp_unslash( (string) $_GET['kp_done'] ) ) ? '現在の状態を新しい基準として保存しました。' : 'スキャンを実行しました。';
			echo '<div class="notice notice-success"><p>' . esc_html( $message ) . '</p></div>';
		}
		echo '<p class="kp-ui-description">uploads内のPHP系ファイルを検出し、ハッシュ基準との差分、危険な関数の組み合わせ、難読化の兆候を評価します。ファイルの削除・隔離・変更は行いません。</p>';
		echo '<div class="kp-ui-toolbar"><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_malware_scan' ), 'kprotect_malware_scan' ) ) . '">今すぐスキャン</a> ';
		echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_malware_baseline' ), 'kprotect_malware_baseline' ) ) . '" onclick="return confirm(\'現在のPHPファイルを安全な基準として保存します。内容を確認済みですか？\');">現在を新しい基準にする</a></div>';
		echo '<p class="kp-ui-meta"><strong>最終スキャン：</strong>' . esc_html( (string) get_option( 'kprotect_malware_last_scan', '未実行' ) ) . '　<strong>基準ファイル数：</strong>' . esc_html( (string) $this->malware->baseline_count() ) . '</p>';
		if ( empty( $result ) ) {
			echo '<div class="notice notice-info inline"><p>まだスキャン結果がありません。最初のスキャン後、内容を確認して基準を保存してください。</p></div></div>';
			return; }
		if ( ! empty( $result['error'] ) ) {
			echo '<div class="notice notice-error inline"><p>' . esc_html( $result['error'] ) . '</p></div>'; }
		$findings = (array) ( $result['findings'] ?? array() );
		$high     = count( array_filter( $findings, static fn( array $item ): bool => (int) ( $item['risk'] ?? 0 ) >= 70 ) );
		echo '<div class="kprotect-cards kp-four"><div class="kprotect-card"><span>確認ファイル数</span><strong>' . esc_html( (string) ( $result['files_checked'] ?? 0 ) ) . '</strong></div><div class="kprotect-card"><span>PHP系ファイル</span><strong>' . esc_html( (string) count( (array) ( $result['php_files'] ?? array() ) ) ) . '</strong></div><div class="kprotect-card"><span>新規・変更</span><strong>' . esc_html( (string) ( count( (array) ( $result['new_files'] ?? array() ) ) + count( (array) ( $result['changed_files'] ?? array() ) ) ) ) . '</strong></div><div class="kprotect-card"><span>高リスク</span><strong>' . esc_html( (string) $high ) . '</strong></div></div>';
		if ( ! empty( $result['truncated'] ) ) {
			echo '<div class="notice notice-warning inline"><p>負荷制限のため3,000ファイルで停止しました。</p></div>'; }
		if ( empty( $result['baseline_exists'] ) ) {
			echo '<div class="notice notice-info inline"><p>差分比較の基準がありません。スキャン結果を確認し、安全と判断できた場合だけ「現在を新しい基準にする」を押してください。</p></div>'; }
		if ( empty( $findings ) ) {
			echo '<div class="notice notice-success inline"><p>uploads内にPHP系ファイルは見つかりませんでした。</p></div>'; } else {
			echo '<h2 class="kp-ui-section-title">PHP系ファイル評価</h2><table class="widefat striped"><thead><tr><th>ファイル</th><th>差分</th><th>危険度</th><th>検出根拠</th><th>更新日時</th><th>SHA-256</th></tr></thead><tbody>';
			$status_labels    = array(
				'baseline' => '初回確認',
				'existing' => '変更なし',
				'new'      => '新規',
				'changed'  => '変更',
			);
			$indicator_labels = array(
				'eval'                   => 'eval実行',
				'base64_decode'          => 'Base64復号',
				'gzinflate'              => '圧縮コード展開',
				'gzuncompress'           => '圧縮コード展開',
				'shell_exec'             => 'OSコマンド実行',
				'passthru'               => 'OSコマンド実行',
				'proc_open'              => 'プロセス実行',
				'popen'                  => 'プロセス実行',
				'system'                 => 'OSコマンド実行',
				'exec'                   => 'OSコマンド実行',
				'assert'                 => '動的コード評価',
				'preg_replace_e'         => '旧式コード実行',
				'variable_function'      => '可変関数実行',
				'hex_obfuscation'        => '16進難読化',
				'long_encoded_string'    => '長いエンコード文字列',
				'superglobal_write'      => '外部入力からの実行',
				'obfuscation_combo'      => '難読化の組み合わせ',
				'remote_command_combo'   => '外部入力とコマンド実行の組み合わせ',
				'uncommon_php_extension' => '一般的でないPHP拡張子',
				'new_since_baseline'     => '基準後の新規ファイル',
				'changed_since_baseline' => '基準後の内容変更',
				'large_php_file'         => '大容量PHPファイル',
				'unreadable'             => '読み取り不可',
			);
			foreach ( $findings as $item ) {
				$labels = array_map( static fn( string $key ): string => $indicator_labels[ $key ] ?? $key, (array) ( $item['indicators'] ?? array() ) );
				$mtime  = ! empty( $item['mtime'] ) ? wp_date( 'Y-m-d H:i:s', (int) $item['mtime'] ) : '-';
				echo '<tr><td><code>' . esc_html( (string) $item['file'] ) . '</code></td><td>' . esc_html( $status_labels[ (string) $item['status'] ] ?? (string) $item['status'] ) . '</td><td><strong>' . esc_html( strtoupper( (string) $item['level'] ) . ' ' . (string) $item['risk'] ) . '</strong></td><td>' . esc_html( empty( $labels ) ? 'PHPファイル自体を要確認' : implode( '、', $labels ) ) . '</td><td>' . esc_html( $mtime ) . '</td><td><code>' . esc_html( substr( (string) $item['hash'], 0, 12 ) ) . '…</code></td></tr>';
			}
			echo '</tbody></table>';
			}
			if ( ! empty( $result['removed_files'] ) ) {
				echo '<h2 class="kp-ui-section-title">基準から削除されたファイル</h2><p class="kp-ui-info"><code>' . esc_html( implode( '</code>、<code>', (array) $result['removed_files'] ) ) . '</code></p>'; }
			echo '<p class="description">危険度は複数の兆候を組み合わせた確認優先度です。検出だけで感染を断定できません。基準更新や削除の前にバックアップを取り、内容を確認してください。</p></div>';
	}

	public function malware_scan(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' ); }
		check_admin_referer( 'kprotect_malware_scan' );
		$this->malware->scan_uploads();
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-malware&kp_done=scan' ) );
		exit;
	}

	public function malware_baseline(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' ); }
		check_admin_referer( 'kprotect_malware_baseline' );
		$this->malware->update_baseline();
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-malware&kp_done=baseline' ) );
		exit;
	}



	public function reports(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only report-range filter; no state is changed.
		$days = isset( $_GET['days'] ) ? absint( wp_unslash( $_GET['days'] ) ) : 7;
		if ( ! in_array( $days, array( 1, 7, 30 ), true ) ) {
			$days = 7; }
		$r = $this->report->build( $days );
		$this->header( 'KProtect セキュリティレポート' );
		echo '<p class="description kp-ui-description">ローカルに保存されたログ・通知を集計した読み取り専用レポートです。外部サービスへデータは送信されません。</p>';
		echo '<div class="kp-notification-toolbar">';
		foreach ( array(
			1  => '今日',
			7  => '7日間',
			30 => '30日間',
		) as $value => $label ) {
			echo '<a class="button' . ( $days === $value ? ' button-primary' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=kprotect-reports&days=' . $value ) ) . '">' . esc_html( $label ) . '</a> '; }
		echo '</div><p class="kp-ui-meta"><strong>対象期間：</strong>' . esc_html( $r['range']['start_local'] . ' 〜 ' . $r['range']['end_local'] ) . '</p>';
		echo '<div class="kprotect-cards kp-four"><div class="kprotect-card"><span>安全度</span><strong>' . esc_html( (string) $r['score'] ) . '</strong><small>' . esc_html( (string) $r['level'] ) . '</small></div><div class="kprotect-card"><span>検知件数</span><strong>' . esc_html( (string) $r['total'] ) . '</strong></div><div class="kprotect-card"><span>遮断件数</span><strong>' . esc_html( (string) $r['blocked'] ) . '</strong><small>遮断率 ' . esc_html( (string) $r['block_rate'] ) . '%</small></div><div class="kprotect-card"><span>最大危険度</span><strong>' . esc_html( (string) $r['max_risk'] ) . '</strong><small>平均 ' . esc_html( (string) $r['avg_risk'] ) . '</small></div></div>';
		echo '<div class="kp-dashboard-grid"><section class="kp-panel"><h2>主な検知種類</h2>';
		if ( empty( $r['types'] ) ) {
			echo '<p>対象期間の検知はありません。</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>種類</th><th>件数</th><th>遮断</th><th>最大危険度</th></tr></thead><tbody>';
			foreach ( $r['types'] as $row ) {
				echo '<tr><td>' . esc_html( (string) $row['event_type'] ) . '</td><td>' . esc_html( (string) $row['total'] ) . '</td><td>' . esc_html( (string) $row['blocked'] ) . '</td><td>' . esc_html( (string) $row['max_risk'] ) . '</td></tr>';
			} echo '</tbody></table>'; }
		echo '</section><section class="kp-panel"><h2>推奨対応</h2><ol class="kp-report-advice">';
		foreach ( $r['advice'] as $item ) {
			echo '<li><strong>[' . esc_html( $item['priority'] ) . '] ' . esc_html( $item['title'] ) . '</strong><p>' . esc_html( $item['message'] ) . '</p><a href="' . esc_url( admin_url( 'admin.php?page=' . $item['page'] ) ) . '">関連画面を開く</a></li>'; }
		echo '</ol></section></div><section class="kp-panel"><h2>重要通知</h2>';
		if ( empty( $r['important'] ) ) {
			echo '<p>対象期間に危険度75以上の通知はありません。</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>最終発生</th><th>通知</th><th>危険度</th><th>発生</th><th>状態</th></tr></thead><tbody>';
			foreach ( $r['important'] as $row ) {
				$timestamp = strtotime( (string) $row['updated_at'] . ' UTC' );
				echo '<tr><td>' . esc_html( $timestamp ? wp_date( 'Y-m-d H:i:s', $timestamp ) : (string) $row['updated_at'] ) . '</td><td>' . esc_html( (string) $row['title'] ) . '</td><td>' . esc_html( (string) $row['risk_score'] ) . '</td><td>' . esc_html( (string) $row['occurrences'] ) . '回</td><td>' . esc_html( (string) $row['status'] ) . '</td></tr>';
			} echo '</tbody></table>'; }
		echo '</section><p class="description">安全度は期間内の最大危険度・検知件数・遮断状況から算出する説明可能な目安であり、安全性を保証するものではありません。</p></div>';
	}

	public function notifications(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notification view filter; no state is changed.
		$view = isset( $_REQUEST['view'] ) ? sanitize_key( wp_unslash( $_REQUEST['view'] ) ) : 'pending';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Legacy read-only notification filter.
		if ( isset( $_GET['status'] ) && ! isset( $_GET['view'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Legacy read-only notification filter.
			$legacy_status = sanitize_key( wp_unslash( $_GET['status'] ) );
			$view          = in_array( $legacy_status, array( 'unread', 'read' ), true ) ? $legacy_status : 'all';
		}
		$allowed_views = array( 'pending', 'processed', 'unread', 'read', 'all' );
		if ( ! in_array( $view, $allowed_views, true ) ) {
			$view = 'pending';
		}

		$rows   = $this->notifications->latest_by_view( 100, $view );
		$counts = $this->notifications->workflow_counts();
		$this->header( 'KProtect 通知センター' );
		echo '<p class="description kp-ui-description">未対応通知と処理済み履歴を分けて管理します。管理者判定を行った通知は自動的に既読になります。</p>';

		$purge_result_key = 'kprotect_purge_result_' . get_current_user_id();
		$purge_result     = get_transient( $purge_result_key );
		if ( is_array( $purge_result ) ) {
			delete_transient( $purge_result_key );
			$purge_status  = sanitize_key( (string) ( $purge_result['status'] ?? '' ) );
			$purge_changed = absint( $purge_result['changed'] ?? 0 );
			if ( 'deleted' === $purge_status ) {
				$purge_message = $purge_changed > 0 ? '処理済み通知を' . $purge_changed . '件削除しました。' : '削除対象の処理済み通知はありませんでした。';
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $purge_message ) . '</p></div>';
			} else {
				echo '<div class="notice notice-error"><p>処理済み通知を削除できませんでした。通知テーブルの状態を確認してください。</p></div>';
			}
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect notice flag.
		if ( isset( $_GET['kp_notice'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect notice flag.
			$notice = sanitize_key( wp_unslash( $_GET['kp_notice'] ) );
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect count.
			$changed = isset( $_GET['changed'] ) ? absint( wp_unslash( $_GET['changed'] ) ) : 0;
			if ( 'deleted' === $notice ) {
				$message = $changed > 0 ? '処理済み通知を' . $changed . '件削除しました。' : '削除対象の処理済み通知はありませんでした。';
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
			} elseif ( 'delete_failed' === $notice ) {
				echo '<div class="notice notice-error"><p>処理済み通知を削除できませんでした。データベース権限と通知テーブルを確認してください。</p></div>';
			} elseif ( 'invalid_action' === $notice ) {
				echo '<div class="notice notice-error"><p>無効な通知操作です。</p></div>';
			} else {
				echo '<div class="notice notice-success is-dismissible"><p>通知を更新しました（変更 ' . esc_html( (string) $changed ) . '件）。</p></div>';
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect test flag.
		if ( isset( $_GET['kp_test'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>テスト通知を作成しました。</p></div>';
		}

		$settings        = KProtect_Utils::settings();
		$table_ok        = $this->notifications->table_exists();
		$feedback_counts = $this->notifications->feedback_counts();
		echo '<div class="kp-notification-diagnostics kp-ui-info"><strong>通知診断：</strong> 管理画面通知 ' . ( ! empty( $settings['admin_notifications'] ) ? '有効' : '無効' ) . ' ／ しきい値 ' . esc_html( (string) $settings['notification_threshold'] ) . ' ／ 通知テーブル ' . ( $table_ok ? '正常' : '未作成' ) . ' ／ 保存件数 ' . esc_html( (string) $counts['total'] ) . '</div>';
		echo '<div class="kp-notification-diagnostics kp-ui-info"><strong>フィードバック：</strong> 正しい検知 ' . esc_html( (string) $feedback_counts['confirmed'] ) . ' ／ 誤検知 ' . esc_html( (string) $feedback_counts['false_positive'] ) . ' ／ 要確認 ' . esc_html( (string) $feedback_counts['review'] ) . ' ／ 承認済み変更 ' . esc_html( (string) $feedback_counts['approved_change'] ) . '</div>';
		echo '<p><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_test_notification' ), 'kprotect_test_notification' ) ) . '">テスト通知を作成</a></p>';

		$tabs = array(
			'pending'   => '未対応 ' . $counts['pending'],
			'processed' => '処理済み ' . $counts['processed'],
			'unread'    => '未読 ' . $counts['unread'],
			'read'      => '既読 ' . $counts['read'],
			'all'       => 'すべて ' . $counts['total'],
		);
		echo '<div class="kp-notification-toolbar">';
		foreach ( $tabs as $tab_key => $tab_label ) {
			$url = add_query_arg(
				array(
					'page' => 'kprotect-notifications',
					'view' => $tab_key,
				),
				admin_url( 'admin.php' )
			);
			echo '<a class="button' . ( $view === $tab_key ? ' button-primary' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $tab_label ) . '</a> ';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="kp-inline-form">';
		echo '<input type="hidden" name="action" value="kprotect_notification_action"><input type="hidden" name="do" value="mark_all"><input type="hidden" name="return_view" value="' . esc_attr( $view ) . '">';
		wp_nonce_field( 'kprotect_notification_action' );
		echo '<button type="submit" class="button">すべて既読</button></form> ';
		$purge_url = wp_nonce_url(
			add_query_arg(
				array(
					'page'    => 'kprotect-notifications',
					'view'    => 'processed',
					'kp_task' => 'purge_processed',
				),
				admin_url( 'admin.php' )
			),
			'kprotect_purge_processed_notifications'
		);
		echo '<a class="button" href="' . esc_url( $purge_url ) . '">処理済みを削除</a></div>';

		if ( empty( $rows ) ) {
			echo '<div class="kprotect-notice"><p>この区分に表示する通知はありません。</p></div></div>';
			return;
		}

		echo '<div class="kp-notification-list">';
		foreach ( $rows as $row ) {
			$id              = (int) $row['id'];
			$severity        = sanitize_key( (string) $row['severity'] );
			$status          = sanitize_key( (string) $row['status'] );
			$is_unread       = KProtect_Notification_Center::STATUS_UNREAD === $status;
			$feedback        = sanitize_key( (string) ( $row['feedback_status'] ?? '' ) );
			$feedback_labels = KProtect_Notification_Center::feedback_labels();
			$is_processed    = ! $is_unread || isset( $feedback_labels[ $feedback ] );
			echo '<article class="kp-notification kp-severity-' . esc_attr( $severity ) . ( $is_unread ? ' is-unread' : '' ) . ( $is_processed ? ' is-processed' : '' ) . '">';
			$updated_local = get_date_from_gmt( (string) $row['updated_at'], 'Y-m-d H:i:s' );
			echo '<div class="kp-notification-main"><div class="kp-notification-meta"><span class="kp-severity">' . esc_html( strtoupper( $severity ) ) . '</span><span>危険度 ' . esc_html( (string) $row['risk_score'] ) . '</span><span>発生 ' . esc_html( (string) $row['occurrences'] ) . '回</span><span>最終 ' . esc_html( $updated_local ) . '</span><span class="kp-workflow-state">' . esc_html( $is_processed ? '処理済み' : '未対応' ) . '</span></div>';
			$presentation = KProtect_Notification_Center::presentation( (string) $row['event_type'], (int) $row['risk_score'], (string) $row['message'] );
			echo '<h2>' . esc_html( $presentation['title'] ) . '</h2>';
			if ( ! empty( $presentation['is_test'] ) ) {
				echo '<p><strong>これはテスト通知です。実際の攻撃ではありません。</strong></p>';
			}
			echo '<p>' . esc_html( $presentation['summary'] ) . '</p><p><strong>想定される影響：</strong> ' . esc_html( $presentation['impact'] ) . '</p>';
			if ( ! empty( $presentation['actions'] ) ) {
				echo '<p><strong>推奨対応：</strong></p><ul>';
				foreach ( $presentation['actions'] as $action ) {
					echo '<li>' . esc_html( $action ) . '</li>';
				}
				echo '</ul>';
			}
			if ( ! empty( $presentation['evidence'] ) ) {
				echo '<details><summary>技術的な根拠</summary><ul>';
				foreach ( $presentation['evidence'] as $evidence ) {
					echo '<li>' . esc_html( $evidence ) . '</li>';
				}
				echo '</ul></details>';
			}
			echo '</div>';
			if ( isset( $feedback_labels[ $feedback ] ) ) {
				echo '<p class="kp-feedback-current"><strong>判定：</strong> ' . esc_html( $feedback_labels[ $feedback ] ) . '</p>';
			}
			echo '<div class="kp-notification-actions">';
			if ( $is_unread ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="kp-inline-form"><input type="hidden" name="action" value="kprotect_notification_action"><input type="hidden" name="do" value="mark_read"><input type="hidden" name="id" value="' . esc_attr( (string) $id ) . '"><input type="hidden" name="return_view" value="' . esc_attr( $view ) . '">';
				wp_nonce_field( 'kprotect_notification_action' );
				echo '<button type="submit" class="button">既読にする</button></form>';
			}
			foreach ( $feedback_labels as $feedback_key => $feedback_label ) {
				$button_class = $feedback === $feedback_key ? 'button button-primary' : 'button';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="kp-inline-form"><input type="hidden" name="action" value="kprotect_notification_action"><input type="hidden" name="do" value="feedback"><input type="hidden" name="id" value="' . esc_attr( (string) $id ) . '"><input type="hidden" name="feedback" value="' . esc_attr( $feedback_key ) . '"><input type="hidden" name="return_view" value="' . esc_attr( $view ) . '">';
				wp_nonce_field( 'kprotect_notification_action' );
				echo '<button type="submit" class="' . esc_attr( $button_class ) . '">' . esc_html( $feedback_label ) . '</button></form>';
			}
			echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=kprotect-logs&keyword=' . rawurlencode( (string) $row['event_type'] ) ) ) . '">関連ログ</a></div></article>';
		}
		echo '</div></div>';
	}

	public function test_notification(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' ); }
		check_admin_referer( 'kprotect_test_notification' );
		$this->notifications->record( 'test_notification', 90, array( 'manual_test', 'notification_center_check' ), true );
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-notifications&kp_test=1' ) );
		exit;
	}

	public function test_discord(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 ); }
		check_admin_referer( 'kprotect_test_discord' );
		$result = ( new KProtect_Discord_Notifier() )->send( 'test_notification', 90, array( 'manual_test', 'discord_connection_check' ), true );
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'            => 'kprotect-settings',
						'kp_discord_test' => 'error',
						'kp_message'      => rawurlencode( $result->get_error_message() ),
					),
					admin_url( 'admin.php' )
				)
			);
			exit;
		}
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'            => 'kprotect-settings',
					'kp_discord_test' => 'success',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}



	/**
	 * Handle notification purge before the admin screen sends output.
	 *
	 * @return void
	 */
	public function maybe_delete_processed_notifications(): void {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$task = isset( $_GET['kp_task'] ) ? sanitize_key( wp_unslash( $_GET['kp_task'] ) ) : '';
		if ( 'kprotect-notifications' !== $page || 'purge_processed' !== $task ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to perform this action.', 'kprotect-ai-security' ), 403 );
		}
		check_admin_referer( 'kprotect_purge_processed_notifications' );

		$return_view = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'processed';
		if ( ! in_array( $return_view, array( 'pending', 'processed', 'unread', 'read', 'all' ), true ) ) {
			$return_view = 'processed';
		}

		$result  = $this->notifications->delete_processed();
		$message = false === $result ? 'delete_failed' : 'deleted';
		$changed = false === $result ? 0 : max( 0, (int) $result );

		set_transient(
			'kprotect_purge_result_' . get_current_user_id(),
			array(
				'status'  => $message,
				'changed' => $changed,
			),
			MINUTE_IN_SECONDS
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => 'kprotect-notifications',
					'view' => 'processed',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Delete processed notifications through a dedicated admin POST action.
	 *
	 * Keeping this separate from the other notification actions prevents the
	 * neighbouring "mark all read" form from being submitted accidentally.
	 *
	 * @return void
	 */
	public function delete_processed_notifications(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}
		check_admin_referer( 'kprotect_delete_processed_notifications' );

		$return_view = isset( $_REQUEST['return_view'] ) ? sanitize_key( wp_unslash( $_REQUEST['return_view'] ) ) : 'processed';
		if ( ! in_array( $return_view, array( 'pending', 'processed', 'unread', 'read', 'all' ), true ) ) {
			$return_view = 'processed';
		}

		$result  = $this->notifications->delete_processed();
		$message = false === $result ? 'delete_failed' : 'deleted';
		$changed = false === $result ? 0 : max( 0, (int) $result );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'      => 'kprotect-notifications',
					'view'      => $return_view,
					'kp_notice' => $message,
					'changed'   => $changed,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	public function notification_action(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		}
		check_admin_referer( 'kprotect_notification_action' );

		$do          = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$return_view = isset( $_POST['return_view'] ) ? sanitize_key( wp_unslash( $_POST['return_view'] ) ) : 'pending';
		if ( ! in_array( $return_view, array( 'pending', 'processed', 'unread', 'read', 'all' ), true ) ) {
			$return_view = 'pending';
		}
		$result  = 0;
		$message = 'updated';

		if ( 'mark_read' === $do ) {
			$result = $this->notifications->mark_read( isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0 );
		} elseif ( 'mark_all' === $do ) {
			$result = $this->notifications->mark_all_read();
		} elseif ( in_array( $do, array( 'delete_read', 'delete_processed' ), true ) ) {
			$result  = $this->notifications->delete_processed();
			$message = false === $result ? 'delete_failed' : 'deleted';
		} elseif ( 'feedback' === $do ) {
			$id       = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
			$feedback = isset( $_POST['feedback'] ) ? sanitize_key( wp_unslash( $_POST['feedback'] ) ) : '';
			$result   = $this->notifications->set_feedback_and_mark_read( $id, $feedback ) ? 1 : 0;
		} else {
			$message = 'invalid_action';
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'      => 'kprotect-notifications',
					'view'      => $return_view,
					'kp_notice' => $message,
					'changed'   => max( 0, (int) $result ),
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}


	public function queue_page(): void {
		$stats             = $this->queue->stats();
		$rows              = $this->queue->latest( 100 );
		$state             = $this->queue->runtime_state();
		$logs              = $this->queue->process_logs();
		$next_run          = $this->queue->next_scheduled();
		$test_rows         = $this->deliveries->latest_tests( 12 );
		$integrity_pending = $this->queue->pending_file_integrity_count();
		$this->header( '通知キュー' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect queue status flag.
		if ( isset( $_GET['kp_queue'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>通知キューを処理しました。</p></div>'; }
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect cleanup status flag.
		if ( isset( $_GET['kp_queue_cleanup'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect deleted-count value.
			$deleted = isset( $_GET['deleted'] ) ? absint( wp_unslash( $_GET['deleted'] ) ) : 0;
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(
				sprintf( '待機中のファイル整合性通知を%d件削除しました。', $deleted )
			) . '</p></div>';
		}
		echo '<p class="description">同一イベントを集約し、1回に最大10件ずつ配信します。失敗時は段階的に再試行し、4回失敗すると停止します。</p>';
		echo '<div class="kprotect-cards kp-four">';
		foreach ( array(
			'pending'    => '待機中',
			'processing' => '処理中',
			'sent'       => '送信済み',
			'failed'     => '失敗',
		) as $key => $label ) {
			echo '<div class="kprotect-card"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( (string) ( $stats[ $key ] ?? 0 ) ) . '</strong></div>'; }
		echo '</div>';
		if ( 0 === (int) ( $stats['pending'] ?? 0 ) && 0 === (int) ( $stats['processing'] ?? 0 ) ) {
			echo '<div class="notice notice-success inline"><p><strong>現在キューは空です（正常）。</strong> 配信待ちの通常セキュリティイベントはありません。</p></div>';
		}
		if ( $integrity_pending > 0 ) {
			echo '<div class="notice notice-warning inline"><p><strong>' . esc_html(
				sprintf( '待機中のファイル整合性通知が%d件あります。', $integrity_pending )
			) . '</strong></p>';
			echo '<p>この操作は待機中のファイル整合性通知だけを削除します。処理中、送信済み、失敗履歴、その他の検知通知は保持されます。</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'kprotect_delete_pending_file_integrity_queue' );
			echo '<input type="hidden" name="action" value="kprotect_delete_pending_file_integrity_queue">';
			echo '<p><label><input type="checkbox" name="confirm" value="1" required> 削除対象と件数を確認しました</label></p>';
			submit_button( '待機中のファイル整合性通知を削除', 'delete', 'submit', false );
			echo '</form></div>';
		}
		$last_run  = ! empty( $state['last_run_gmt'] ) ? get_date_from_gmt( (string) $state['last_run_gmt'], 'Y-m-d H:i:s' ) : '未実行';
		$next_text = $next_run > 0 ? wp_date( 'Y-m-d H:i:s', $next_run ) : ( (int) ( $stats['pending'] ?? 0 ) > 0 ? '未予約（手動処理を推奨）' : '予定なし（キューが空のため正常）' );
		echo '<h2 class="kp-ui-section-title">処理状態</h2><div class="kprotect-cards kp-four kp-queue-state-cards">';
		echo '<div class="kprotect-card"><span>最終処理</span><strong>' . esc_html( $last_run ) . '</strong></div>';
		echo '<div class="kprotect-card"><span>前回処理件数</span><strong>' . esc_html( (string) ( $state['processed'] ?? 0 ) ) . '</strong><small>' . esc_html( (string) ( $state['duration_ms'] ?? 0 ) ) . ' ms</small></div>';
		echo '<div class="kprotect-card"><span>前回結果</span><strong>' . esc_html( (string) ( $state['succeeded'] ?? 0 ) ) . ' 成功</strong><small>' . esc_html( (string) ( $state['failed'] ?? 0 ) ) . ' 失敗</small></div>';
		echo '<div class="kprotect-card"><span>次回Cron実行</span><strong>' . esc_html( $next_text ) . '</strong></div>';
		echo '</div><p><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_process_queue' ), 'kprotect_process_queue' ) ) . '">今すぐキューを処理</a></p>';

		echo '<h2 class="kp-ui-section-title">接続テスト履歴</h2><p class="description kp-ui-description">接続テストはキューを経由せず直接送信されます。ここでは配信履歴から直近のテスト結果を表示します。</p>';
		if ( empty( $test_rows ) ) {
			echo '<div class="kprotect-notice"><p>接続テスト履歴はありません。</p></div>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>日時</th><th>送信先</th><th>結果</th><th>HTTP</th><th>処理時間</th></tr></thead><tbody>';
			foreach ( $test_rows as $test ) {
				$created = get_date_from_gmt( (string) $test['created_at'], 'Y-m-d H:i:s' );
				echo '<tr><td>' . esc_html( $created ) . '</td><td>' . esc_html( strtoupper( (string) $test['channel'] ) ) . '</td><td>' . esc_html( 'success' === $test['status'] ? '成功' : '失敗' ) . '</td><td>' . esc_html( (string) $test['http_code'] ) . '</td><td>' . esc_html( (string) $test['duration_ms'] ) . ' ms</td></tr>';
			}
			echo '</tbody></table>';
		}

		echo '<h2 class="kp-ui-section-title">キュー処理ログ</h2>';
		if ( empty( $logs ) ) {
			echo '<div class="kprotect-notice"><p>処理ログはまだありません。「今すぐキューを処理」を押すと、0件の場合も記録されます。</p></div>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>日時</th><th>処理</th><th>成功</th><th>失敗</th><th>残件</th><th>処理時間</th></tr></thead><tbody>';
			foreach ( $logs as $log ) {
				$created = ! empty( $log['created_at_gmt'] ) ? get_date_from_gmt( (string) $log['created_at_gmt'], 'Y-m-d H:i:s' ) : '—';
				echo '<tr><td>' . esc_html( $created ) . '</td><td>' . esc_html( (string) ( $log['processed'] ?? 0 ) ) . '</td><td>' . esc_html( (string) ( $log['succeeded'] ?? 0 ) ) . '</td><td>' . esc_html( (string) ( $log['failed'] ?? 0 ) ) . '</td><td>' . esc_html( (string) ( $log['pending_after'] ?? 0 ) ) . '</td><td>' . esc_html( (string) ( $log['duration_ms'] ?? 0 ) ) . ' ms</td></tr>';
			}
			echo '</tbody></table>';
		}

		echo '<h2 class="kp-ui-section-title">キュー履歴</h2>';
		if ( empty( $rows ) ) {
			echo '<div class="kprotect-notice"><p>通常イベントのキュー履歴はありません。</p></div></div>';
			return; }
		echo '<table class="widefat striped"><thead><tr><th>更新日時</th><th>送信先</th><th>状態</th><th>検知</th><th>危険度</th><th>集約数</th><th>クールダウン抑制</th><th>試行</th><th>次回/詳細</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			$updated = get_date_from_gmt( (string) $row['updated_at'], 'Y-m-d H:i:s' );

			if ( 'pending' === $row['status'] ) {
				$available_timestamp = strtotime( (string) $row['available_at'] . ' UTC' );
				$remaining_seconds   = max( 0, (int) $available_timestamp - time() );
				$remaining_minutes   = (int) ceil( $remaining_seconds / MINUTE_IN_SECONDS );
				$remaining_retries   = KProtect_Notification_Queue::remaining_retries( (int) $row['attempts'] );

				$detail = sprintf(
					'%s（約%d分後 / 残り%d回）',
					get_date_from_gmt( (string) $row['available_at'], 'Y-m-d H:i:s' ),
					$remaining_minutes,
					$remaining_retries
				);
			} else {
				$detail = $row['last_error'] ?: '—';
			}
			echo '<tr><td>' . esc_html( $updated ) . '</td><td>' . esc_html( strtoupper( (string) $row['channel'] ) ) . '</td><td>' . esc_html( (string) $row['status'] ) . '</td><td>' . esc_html( (string) $row['event_type'] ) . '</td><td>' . esc_html( (string) $row['risk_score'] ) . '</td><td>' . esc_html( (string) $row['occurrences'] ) . '</td><td><strong>' . esc_html( (string) ( $row['cooldown_hits'] ?? 0 ) ) . '</strong></td><td>' . esc_html( (string) $row['attempts'] ) . '</td><td>' . esc_html( $detail ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public function process_queue(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'kprotect-ai-security' ), 403 ); }
		check_admin_referer( 'kprotect_process_queue' );
		$this->queue->process( 10 );
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-queue&kp_queue=1' ) );
		exit;
	}

	/**
	 * Delete only pending file-integrity queue rows after explicit confirmation.
	 */
	public function delete_pending_file_integrity_queue(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'kprotect-ai-security' ), 403 );
		}
		check_admin_referer( 'kprotect_delete_pending_file_integrity_queue' );

		$confirmed = isset( $_POST['confirm'] )
			&& '1' === sanitize_key( wp_unslash( $_POST['confirm'] ) );
		if ( ! $confirmed ) {
			wp_die( esc_html__( '削除対象の確認が必要です。', 'kprotect-ai-security' ), 400 );
		}

		$deleted = $this->queue->delete_pending_file_integrity();
		wp_safe_redirect(
			admin_url( 'admin.php?page=kprotect-queue&kp_queue_cleanup=1&deleted=' . max( 0, $deleted ) )
		);
		exit;
	}


	public function delivery_history(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only delivery-history filter.
		$channel = isset( $_GET['channel'] ) ? sanitize_key( wp_unslash( $_GET['channel'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only delivery-history filter.
		$status           = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$allowed_channels = array( '', 'email', 'discord', 'slack', 'webhook' );
		if ( ! in_array( $channel, $allowed_channels, true ) ) {
			$channel = ''; }
		if ( ! in_array( $status, array( '', 'success', 'failed' ), true ) ) {
			$status = ''; }
		$rows  = $this->deliveries->latest( 200, $channel, $status );
		$stats = $this->deliveries->stats( 1 );
		$this->header( '通知配信履歴' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect retry status flag.
		if ( isset( $_GET['kp_retry'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect retry status flag.
			$ok = 'success' === sanitize_key( wp_unslash( $_GET['kp_retry'] ) );
			echo '<div class="notice ' . ( $ok ? 'notice-success' : 'notice-error' ) . ' is-dismissible"><p>' . ( $ok ? '通知を再送しました。' : '通知の再送に失敗しました。設定と送信先を確認してください。' ) . '</p></div>';
		}
		echo '<p class="description">メール・Discord・Slack・Webhookの送信結果を記録します。IPアドレス、リクエスト本文、フォーム入力内容は保存しません。</p>';
		echo '<div class="kprotect-cards kp-four">';
		foreach ( array(
			'email'   => 'メール',
			'discord' => 'Discord',
			'slack'   => 'Slack',
			'webhook' => 'Webhook',
		) as $key => $label ) {
			$data = $stats[ $key ] ?? array(
				'success' => 0,
				'failed'  => 0,
				'total'   => 0,
			);
			echo '<div class="kprotect-card"><span>' . esc_html( $label . '（24時間）' ) . '</span><strong>' . esc_html( (string) $data['success'] ) . ' 成功</strong><small>' . esc_html( (string) $data['failed'] ) . ' 失敗</small></div>';
		}
		echo '</div>';
		echo '<p><a class="button' . ( '' === $channel ? ' button-primary' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=kprotect-deliveries' ) ) . '">すべて</a> ';
		foreach ( array(
			'email'   => 'メール',
			'discord' => 'Discord',
			'slack'   => 'Slack',
			'webhook' => 'Webhook',
		) as $key => $label ) {
			echo '<a class="button' . ( $channel === $key ? ' button-primary' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=kprotect-deliveries&channel=' . $key ) ) . '">' . esc_html( $label ) . '</a> ';
		}
		echo '<a class="button' . ( 'failed' === $status ? ' button-primary' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=kprotect-deliveries&status=failed' ) ) . '">失敗のみ</a></p>';
		if ( empty( $rows ) ) {
			echo '<div class="kprotect-notice"><p>配信履歴はありません。</p></div></div>';
			return; }
		echo '<table class="widefat striped"><thead><tr><th>日時</th><th>送信先</th><th>結果</th><th>検知</th><th>危険度</th><th>HTTP</th><th>時間</th><th>詳細</th><th>操作</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			$created   = get_date_from_gmt( (string) $row['created_at'], 'Y-m-d H:i:s' );
			$is_failed = 'failed' === $row['status'];
			echo '<tr><td>' . esc_html( $created ) . '</td><td>' . esc_html( strtoupper( (string) $row['channel'] ) ) . ( ! empty( $row['is_test'] ) ? ' <span class="kp-severity">TEST</span>' : '' ) . '</td>';
			echo '<td><strong>' . ( $is_failed ? '失敗' : '成功' ) . '</strong></td><td>' . esc_html( (string) $row['event_type'] ) . '</td><td>' . esc_html( (string) $row['risk_score'] ) . '</td><td>' . esc_html( (string) ( $row['http_code'] ?: '-' ) ) . '</td><td>' . esc_html( (string) $row['duration_ms'] ) . ' ms</td>';
			echo '<td>' . ( $is_failed ? esc_html( (string) $row['error_message'] ) : '—' ) . '</td><td>';
			if ( $is_failed ) {
				$url = wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_retry_delivery&id=' . (int) $row['id'] ), 'kprotect_retry_delivery' );
				echo '<a class="button" href="' . esc_url( $url ) . '">再送</a>';
			} else {
				echo '—'; }
			echo '</td></tr>';
		}
		echo '</tbody></table><p class="description">再送すると新しい履歴が1件追加されます。大量配信を避けるため、失敗した通知だけを手動で再送してください。</p></div>';
	}

	public function retry_delivery(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'kprotect-ai-security' ), 403 ); }
		check_admin_referer( 'kprotect_retry_delivery' );
		$id  = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0;
		$row = $this->deliveries->get( $id );
		if ( ! $row || 'failed' !== $row['status'] ) {
			wp_safe_redirect( admin_url( 'admin.php?page=kprotect-deliveries&kp_retry=error' ) );
			exit; }
		$payload    = json_decode( (string) $row['payload'], true );
		$event_type = sanitize_key( (string) ( $payload['event_type'] ?? $row['event_type'] ) );
		$score      = max( 0, min( 100, (int) ( $payload['risk_score'] ?? $row['risk_score'] ) ) );
		$reasons    = isset( $payload['reasons'] ) && is_array( $payload['reasons'] ) ? array_map( 'sanitize_text_field', $payload['reasons'] ) : array( 'manual_retry' );
		$is_test    = ! empty( $payload['is_test'] );
		switch ( $row['channel'] ) {
			case 'email':
				$result = ( new KProtect_Notifier() )->send_email( $event_type, $score, $reasons, $is_test );
				break;
			case 'discord':
				$result = ( new KProtect_Discord_Notifier() )->send( $event_type, $score, $reasons, $is_test );
				break;
			case 'slack':
				$result = ( new KProtect_Slack_Notifier() )->send( $event_type, $score, $reasons, $is_test );
				break;
			case 'webhook':
				$result = ( new KProtect_Webhook_Notifier() )->send( $event_type, $score, $reasons, $is_test );
				break;
			default:
				$result = new WP_Error( 'kprotect_unknown_channel', '不明な通知チャンネルです。' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-deliveries&kp_retry=' . ( is_wp_error( $result ) ? 'error' : 'success' ) ) );
		exit;
	}



	public function test_slack(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'kprotect-ai-security' ) ); }
		check_admin_referer( 'kprotect_test_slack' );
		$result = ( new KProtect_Slack_Notifier() )->send( 'test_notification', 90, array( 'manual_test', 'slack_connection_check' ), true );
		$args   = array(
			'page'          => 'kprotect-settings',
			'kp_slack_test' => is_wp_error( $result ) ? 'error' : 'success',
		);
		if ( is_wp_error( $result ) ) {
			$args['kp_slack_message'] = rawurlencode( $result->get_error_message() ); }
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	public function test_webhook(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '権限がありません。', 'kprotect-ai-security' ) ); }
		check_admin_referer( 'kprotect_test_webhook' );
		$result = ( new KProtect_Webhook_Notifier() )->send( 'test_notification', 90, array( 'manual_test', 'webhook_connection_check' ), true );
		$args   = array(
			'page'            => 'kprotect-settings',
			'kp_webhook_test' => is_wp_error( $result ) ? 'error' : 'success',
		);
		if ( is_wp_error( $result ) ) {
			$args['kp_webhook_message'] = rawurlencode( $result->get_error_message() ); }
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	public function run_cleanup(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' ); }
		check_admin_referer( 'kprotect_run_cleanup' );
		$this->maintenance->run_cleanup();
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-maintenance&kp_cleanup=1' ) );
		exit;
	}

	public function maintenance(): void {
		$status   = $this->maintenance->status();
		$settings = KProtect_Utils::settings();
		$this->header( '保守・パフォーマンス' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect cleanup status flag.
		if ( isset( $_GET['kp_cleanup'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['kp_cleanup'] ) ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>手動クリーンアップが完了しました。</p></div>'; }
		echo '<p class="kp-ui-description">ログ・通知の保持状況、アップグレード履歴、スキャン負荷を確認できます。手動クリーンアップは保持期間を過ぎたデータだけを削除します。</p>';
		echo '<div class="kprotect-cards kp-four">';
		foreach ( array(
			'保存ログ'   => $status['counts']['logs'],
			'保存通知'   => $status['counts']['notifications'],
			'ブロック履歴' => $status['counts']['blocks'],
			'DBスキーマ' => $status['schema'] ?: '未記録',
		) as $label => $value ) {
			echo '<div class="kprotect-card"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( (string) $value ) . '</strong></div>'; }
		echo '</div>';
		echo '<section class="kp-panel kp-ui-panel"><h2 class="kp-ui-section-title">ローテーション設定</h2><p>ログ保持：' . esc_html( (string) $settings['log_retention_days'] ) . '日 ／ 通知保持：' . esc_html( (string) $settings['notification_retention_days'] ) . '日</p>';
		$next = ! empty( $status['next_cleanup'] ) ? wp_date( 'Y-m-d H:i:s', (int) $status['next_cleanup'] ) : '未予約';
		echo '<p>次回自動実行：' . esc_html( $next ) . '</p><p><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_run_cleanup' ), 'kprotect_run_cleanup' ) ) . '">今すぐクリーンアップ</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=kprotect-settings' ) ) . '">保持期間を変更</a></p>';
		$last = (array) $status['last_cleanup'];
		if ( $last ) {
			echo '<p class="description">前回：' . esc_html( (string) ( $last['completed_at'] ?? '' ) ) . ' ／ ログ ' . esc_html( (string) ( $last['logs_deleted'] ?? 0 ) ) . '件、通知 ' . esc_html( (string) ( $last['notifications_deleted'] ?? 0 ) ) . '件、ブロック履歴 ' . esc_html( (string) ( $last['blocks_deleted'] ?? 0 ) ) . '件を削除 ／ ' . esc_html( (string) ( $last['duration_ms'] ?? 0 ) ) . 'ms</p>'; }
		echo '</section>';
		echo '<section class="kp-panel kp-ui-panel"><h2 class="kp-ui-section-title">直近のスキャン負荷</h2><table class="widefat striped"><thead><tr><th>処理</th><th>実行日時</th><th>時間</th><th>追加メモリ</th><th>結果</th></tr></thead><tbody>';
		$labels = array(
			'uploads_scan'   => 'uploadsスキャン',
			'integrity_scan' => '改ざん検知',
		);
		foreach ( $labels as $key => $label ) {
			$m = (array) ( $status['metrics'][ $key ] ?? array() );
			echo '<tr><td>' . esc_html( $label ) . '</td><td>' . esc_html( (string) ( $m['recorded_at'] ?? '未実行' ) ) . '</td><td>' . esc_html( isset( $m['duration_ms'] ) ? (string) $m['duration_ms'] . ' ms' : '—' ) . '</td><td>' . esc_html( isset( $m['memory_delta_bytes'] ) ? size_format( (int) $m['memory_delta_bytes'] ) : '—' ) . '</td><td>' . esc_html( isset( $m['files_scanned'] ) ? '走査 ' . (string) $m['files_scanned'] . '件／検出 ' . (string) ( $m['findings'] ?? 0 ) . '件' : ( isset( $m['changes'] ) ? '変更 ' . (string) $m['changes'] . '件' : '—' ) ) . '</td></tr>'; }
		echo '</tbody></table><p class="description">数値はPHPプロセス内の目安です。サーバー全体のCPU使用率ではありません。</p></section>';
		echo '<section class="kp-panel kp-ui-panel"><h2 class="kp-ui-section-title">アップグレード状態</h2><p>インストール済みバージョン：' . esc_html( (string) $status['installed'] ) . '</p><table class="widefat striped"><thead><tr><th>更新日時</th><th>変更前</th><th>変更後</th></tr></thead><tbody>';
		$history = array_reverse( (array) $status['upgrade_history'] );
		if ( ! $history ) {
			echo '<tr><td colspan="3">履歴はありません。</td></tr>'; }
		foreach ( array_slice( $history, 0, 10 ) as $row ) {
			echo '<tr><td>' . esc_html( (string) ( $row['updated_at'] ?? '' ) ) . '</td><td>' . esc_html( (string) ( $row['from'] ?? '' ) ) . '</td><td>' . esc_html( (string) ( $row['to'] ?? '' ) ) . '</td></tr>'; }
		echo '</tbody></table></section></div>';
	}


	/**
	 * Render the local AI Rule Builder.
	 */
	public function rule_builder(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden', 403 );
		}

		$repo        = new KProtect_Rule_Repository();
		$draft       = null;
		$editing_id  = '';
		$instruction = '';
		$errors      = array();
		$notice      = '';
		$test_result = null;
		$similar     = array();

		if ( isset( $_POST['kp_rule_action'] ) ) {
			check_admin_referer( 'kprotect_rule_builder' );
			$action = sanitize_key( wp_unslash( (string) $_POST['kp_rule_action'] ) );

			if ( 'draft' === $action ) {
				$instruction = sanitize_textarea_field( wp_unslash( (string) ( $_POST['instruction'] ?? '' ) ) );
				if ( '' === trim( $instruction ) ) {
					$errors[] = 'ルールの内容を入力してください。';
				} else {
					$validation = KProtect_Rule_Validator::validate( KProtect_AI_Rule_Drafter::draft( $instruction ) );
					$draft      = $validation['rule'];
					$errors     = $validation['errors'];
				}
			} elseif ( 'save' === $action || 'update' === $action ) {
				$rule       = $this->rule_from_post();
				$validation = KProtect_Rule_Validator::validate( $rule );
				$errors     = $validation['errors'];
				if ( $validation['valid'] ) {
					$exclude_id = 'update' === $action ? sanitize_key( wp_unslash( (string) ( $_POST['original_rule_id'] ?? $_POST['rule_id'] ?? '' ) ) ) : '';
					$similar    = $repo->similar( $validation['rule'], $exclude_id );
					if ( ! empty( $similar ) && empty( $_POST['confirm_similar'] ) ) {
						$draft    = $validation['rule'];
						$errors[] = '同じ条件と集計期間のルールが既にあります。内容を確認し、それでも保存する場合は「類似ルールを確認済み」にチェックしてください。';
					} elseif ( 'update' === $action ) {
						$editing_id               = sanitize_key( wp_unslash( (string) ( $_POST['original_rule_id'] ?? $_POST['rule_id'] ?? '' ) ) );
						$validation['rule']['id'] = $editing_id;
						if ( $repo->update( $editing_id, $validation['rule'] ) ) {
							$notice     = 'ルールを更新しました。現在の有効・無効状態は維持されています。';
							$editing_id = '';
						} else {
							$errors[] = 'ルールを更新できませんでした。';
							$draft    = $validation['rule'];
						}
					} elseif ( $repo->save( $validation['rule'] ) ) {
						$notice = 'ルール案を無効状態で保存しました。';
					} else {
						$errors[] = 'ルールを保存できませんでした。';
						$draft    = $validation['rule'];
					}
				}
			} elseif ( 'test' === $action ) {
				$rule             = $this->rule_from_post();
				$original_rule_id = sanitize_key( wp_unslash( (string) ( $_POST['original_rule_id'] ?? $_POST['rule_id'] ?? '' ) ) );
				if ( '' !== $original_rule_id ) {
					$rule['id'] = $original_rule_id;
				}
				$validation = KProtect_Rule_Validator::validate( $rule );
				$errors     = $validation['errors'];
				$draft      = $validation['rule'];
				$editing_id = $original_rule_id;
				if ( '' !== $editing_id && is_array( $draft ) ) {
					$draft['id'] = $editing_id;
				}
				if ( $validation['valid'] ) {
					$test_result = KProtect_Rule_Tester::test( $draft ); }
			} elseif ( 'edit' === $action ) {
				$editing_id = sanitize_key( wp_unslash( (string) ( $_POST['rule_id'] ?? '' ) ) );
				$draft      = $repo->find( $editing_id );
				if ( null === $draft ) {
					$errors[]   = '編集するルールが見つかりません。';
					$editing_id = '';
				}
			} elseif ( 'toggle' === $action ) {
				$id          = sanitize_key( wp_unslash( (string) ( $_POST['rule_id'] ?? '' ) ) );
				$enabled_raw = isset( $_POST['enabled'] ) ? sanitize_key( wp_unslash( $_POST['enabled'] ) ) : '0';
				$enabled     = '1' === $enabled_raw;
				if ( $repo->set_enabled( $id, $enabled ) ) {
					$notice = $enabled ? 'ルールを有効にしました。' : 'ルールを無効にしました。';
				} else {
					$errors[] = 'ルールの状態を変更できませんでした。';
				}
			} elseif ( 'delete' === $action ) {
				$id = sanitize_key( wp_unslash( (string) ( $_POST['rule_id'] ?? '' ) ) );
				if ( $repo->delete( $id ) ) {
					$notice = '保存済みルールを削除しました。';
				} else {
					$errors[] = '削除するルールが見つかりませんでした。';
				}
			}
		}

		$this->header( 'AI Rule Builder' );
		if ( '' !== $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $notice ) . '</p></div>';
		}
		foreach ( $errors as $error ) {
			echo '<div class="notice notice-error"><p>' . esc_html( (string) $error ) . '</p></div>';
		}

		echo '<p class="description kp-ui-description">自然な日本語からルール案を作成し、内容を確認して保存できます。新規ルールは必ず無効で保存されます。有効化しても、この版では通知・監査・優先度付けだけが許可され、自動遮断・削除・隔離は行いません。</p>';
		echo '<section class="kp-panel"><h2>ルール案を作成</h2><form method="post">';
		wp_nonce_field( 'kprotect_rule_builder' );
		echo '<input type="hidden" name="kp_rule_action" value="draft"><textarea name="instruction" rows="5" class="large-text" placeholder="例：15分以内に危険度90以上の未遮断イベントが3件以上あれば、高優先度で管理者へ通知する">' . esc_textarea( $instruction ) . '</textarea><p><button class="button button-primary" type="submit">ルール案を作成</button></p></form></section>';

		if ( is_array( $draft ) && empty( $errors ) ) {
			$this->render_rule_editor( $draft, $editing_id, $test_result, $similar );
		}

		$rules = $repo->all();
		echo '<section class="kp-panel"><h2>保存済みルール</h2>';
		if ( empty( $rules ) ) {
			echo '<p>保存済みルールはありません。</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>名前</th><th>状態</th><th>条件</th><th>期間</th><th>更新日時</th><th>操作</th></tr></thead><tbody>';
			foreach ( $rules as $rule ) {
				$id      = sanitize_key( (string) ( $rule['id'] ?? '' ) );
				$enabled = ! empty( $rule['enabled'] );
				echo '<tr><td><strong>' . esc_html( (string) ( $rule['name'] ?? '' ) ) . '</strong><br><small>' . esc_html( (string) ( $rule['description'] ?? '' ) ) . '</small></td>';
				echo '<td><strong>' . esc_html( $enabled ? '有効' : '無効' ) . '</strong></td>';
				echo '<td>' . esc_html( $this->rule_summary( $rule ) ) . '</td>';
				echo '<td>' . esc_html( (string) ( $rule['window']['value'] ?? 15 ) ) . '分</td>';
				echo '<td>' . esc_html( (string) ( $rule['updated_at'] ?? $rule['created_at'] ?? '' ) ) . '</td><td><div style="display:flex;gap:6px;flex-wrap:wrap">';
				$this->rule_action_form( 'edit', $id, '編集', 'button' );
				$this->rule_toggle_form( $id, ! $enabled );
				$this->rule_action_form( 'delete', $id, '削除', 'button', 'このルールを削除しますか？' );
				echo '</div></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</section></div>';
	}

	/** @return array<string,mixed> */
	private function rule_from_post(): array {
		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended -- rule_builder() verifies the kprotect_rule_builder nonce before calling this helper.
		$conditions = array();
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Values are unslashed here and sanitized with array_map() immediately below.
		$fields_raw = isset( $_POST['condition_field'] ) ? (array) wp_unslash( $_POST['condition_field'] ) : array();
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Values are unslashed here and sanitized with array_map() immediately below.
		$operators_raw = isset( $_POST['condition_operator'] ) ? (array) wp_unslash( $_POST['condition_operator'] ) : array();
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Values are unslashed here and sanitized with array_map() immediately below.
		$values_raw = isset( $_POST['condition_value'] ) ? (array) wp_unslash( $_POST['condition_value'] ) : array();
		$fields     = array_map( 'sanitize_key', $fields_raw );
		$operators  = array_map( 'sanitize_text_field', $operators_raw );
		$values     = array_map( 'sanitize_text_field', $values_raw );
		foreach ( $fields as $index => $field ) {
			$field = sanitize_key( (string) $field );
			$value = $values[ $index ] ?? '';
			if ( 'blocked' === $field ) {
				$value = in_array( strtolower( trim( (string) $value ) ), array( '1', 'true', 'yes', 'on' ), true );
			} elseif ( 'event_type' === $field && in_array( (string) ( $operators[ $index ] ?? '' ), array( 'in', 'not_in' ), true ) ) {
				$value = array_values( array_filter( array_map( 'trim', explode( ',', (string) $value ) ) ) );
			}
			$conditions[] = array(
				'field'    => $field,
				'operator' => sanitize_text_field( (string) ( $operators[ $index ] ?? '' ) ),
				'value'    => $value,
			);
		}

		$actions = array();
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Values are unslashed here and sanitized with array_map() immediately below.
		$types_raw = isset( $_POST['action_type'] ) ? (array) wp_unslash( $_POST['action_type'] ) : array();
		$types     = array_map( 'sanitize_key', $types_raw );
		foreach ( $types as $type ) {
			$actions[] = array( 'type' => sanitize_key( (string) $type ) );
		}

		return array(
			'id'          => sanitize_key( wp_unslash( (string) ( $_POST['rule_id'] ?? wp_generate_uuid4() ) ) ),
			'name'        => sanitize_text_field( wp_unslash( (string) ( $_POST['rule_name'] ?? '' ) ) ),
			'description' => sanitize_textarea_field( wp_unslash( (string) ( $_POST['rule_description'] ?? '' ) ) ),
			'conditions'  => $conditions,
			'window'      => array(
				'value' => absint( wp_unslash( $_POST['window_value'] ?? 15 ) ),
				'unit'  => 'minutes',
			),
			'actions'     => $actions,
			'created_at'  => sanitize_text_field( wp_unslash( (string) ( $_POST['created_at'] ?? current_time( 'mysql', true ) ) ) ),
		);
		// phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended
	}

	/** @param array<string,mixed> $rule */
	private function render_rule_editor( array $rule, string $editing_id, ?array $test_result = null, array $similar = array() ): void {
		$is_edit = '' !== $editing_id;
		echo '<section class="kp-panel"><h2>' . esc_html( $is_edit ? '保存済みルールを編集' : '構造化プレビュー' ) . '</h2><form method="post">';
		wp_nonce_field( 'kprotect_rule_builder' );
		echo '<input type="hidden" name="rule_id" value="' . esc_attr( (string) ( $rule['id'] ?? '' ) ) . '"><input type="hidden" name="original_rule_id" value="' . esc_attr( $editing_id ) . '"><input type="hidden" name="created_at" value="' . esc_attr( (string) ( $rule['created_at'] ?? '' ) ) . '">';
		echo '<table class="form-table"><tr><th><label for="kp-rule-name">ルール名</label></th><td><input id="kp-rule-name" class="regular-text" name="rule_name" value="' . esc_attr( (string) ( $rule['name'] ?? '' ) ) . '" required></td></tr>';
		echo '<tr><th><label for="kp-rule-description">説明</label></th><td><textarea id="kp-rule-description" class="large-text" rows="3" name="rule_description">' . esc_textarea( (string) ( $rule['description'] ?? '' ) ) . '</textarea></td></tr>';
		echo '<tr><th><label for="kp-rule-window">集計期間</label></th><td><input id="kp-rule-window" type="number" min="1" max="1440" name="window_value" value="' . esc_attr( (string) ( $rule['window']['value'] ?? 15 ) ) . '"> 分</td></tr></table>';
		echo '<h3>条件</h3><table class="widefat striped"><thead><tr><th>項目</th><th>演算子</th><th>値</th></tr></thead><tbody>';
		foreach ( (array) ( $rule['conditions'] ?? array() ) as $condition ) {
			$value = $condition['value'] ?? '';
			if ( is_array( $value ) ) {
				$value = implode( ', ', $value );
			} elseif ( is_bool( $value ) ) {
				$value = $value ? 'true' : 'false';
			}
			echo '<tr><td><select name="condition_field[]">';
			foreach ( KProtect_Rule_Schema::fields() as $field ) {
				echo '<option value="' . esc_attr( $field ) . '"' . selected( (string) ( $condition['field'] ?? '' ), $field, false ) . '>' . esc_html( KProtect_Rule_Schema::field_label( $field ) ) . '</option>';
			}
			echo '</select></td><td><select name="condition_operator[]">';
			foreach ( KProtect_Rule_Schema::operators() as $operator ) {
				echo '<option value="' . esc_attr( $operator ) . '"' . selected( (string) ( $condition['operator'] ?? '' ), $operator, false ) . '>' . esc_html( KProtect_Rule_Schema::operator_label( $operator ) ) . '</option>';
			}
			echo '</select></td><td><input class="regular-text" name="condition_value[]" value="' . esc_attr( (string) $value ) . '"></td></tr>';
		}
		echo '</tbody></table><h3>実行内容</h3>';
		$selected_actions = array_map( static fn( $action ) => (string) ( $action['type'] ?? '' ), (array) ( $rule['actions'] ?? array() ) );
		foreach ( KProtect_Rule_Schema::actions() as $action ) {
			echo '<label style="display:block;margin:6px 0"><input type="checkbox" name="action_type[]" value="' . esc_attr( $action ) . '"' . checked( in_array( $action, $selected_actions, true ), true, false ) . '> ' . esc_html( KProtect_Rule_Schema::action_label( $action ) ) . '</label>';
		}
		if ( is_array( $test_result ) ) {
			echo '<div class="notice notice-info inline"><p><strong>過去ログでのテスト結果：</strong> ' . esc_html( (string) $test_result['summary'] ) . '</p><ul>';
			foreach ( (array) $test_result['advice'] as $item ) {
				echo '<li>' . esc_html( (string) $item ) . '</li>'; }
			echo '</ul></div>';
		}
		if ( ! empty( $similar ) ) {
			echo '<div class="notice notice-warning inline"><p><strong>類似ルール：</strong>同じ条件と集計期間のルールが' . esc_html( (string) count( $similar ) ) . '件あります。</p><label><input type="checkbox" name="confirm_similar" value="1"> 類似ルールを確認済み</label></div>';
		}
		echo '<p><button class="button" type="submit" name="kp_rule_action" value="test">過去ログでテスト</button> <button class="button button-primary" type="submit" name="kp_rule_action" value="' . esc_attr( $is_edit ? 'update' : 'save' ) . '">' . esc_html( $is_edit ? '変更を保存' : '無効状態で保存' ) . '</button>';
		if ( $is_edit ) {
			echo ' <a class="button" href="' . esc_url( admin_url( 'admin.php?page=kprotect-rule-builder' ) ) . '">編集をキャンセル</a>';
		}
		echo '</p></form></section>';
	}


	/** @param array<string,mixed> $rule */
	private function rule_summary( array $rule ): string {
		$parts = array();
		foreach ( (array) ( $rule['conditions'] ?? array() ) as $condition ) {
			$field    = (string) ( $condition['field'] ?? '' );
			$operator = (string) ( $condition['operator'] ?? '' );
			$value    = $condition['value'] ?? '';
			if ( is_array( $value ) ) {
				$value = implode( '・', $value ); } elseif ( is_bool( $value ) ) {
				$value = $value ? '遮断済み' : '未遮断'; }
				$parts[] = KProtect_Rule_Schema::field_label( $field ) . ' ' . KProtect_Rule_Schema::operator_label( $operator ) . ' ' . (string) $value;
		}
		return implode( '／', $parts );
	}

	private function rule_action_form( string $action, string $id, string $label, string $css_class = 'button', string $confirm = '' ): void {
		echo '<form method="post" style="display:inline">';
		wp_nonce_field( 'kprotect_rule_builder' );
		echo '<input type="hidden" name="kp_rule_action" value="' . esc_attr( $action ) . '"><input type="hidden" name="rule_id" value="' . esc_attr( $id ) . '"><button class="' . esc_attr( $class ) . '" type="submit"' . ( '' !== $confirm ? ' onclick="return confirm(\'' . esc_js( $confirm ) . '\');"' : '' ) . '>' . esc_html( $label ) . '</button></form>';
	}

	private function rule_toggle_form( string $id, bool $enable ): void {
		echo '<form method="post" style="display:inline">';
		wp_nonce_field( 'kprotect_rule_builder' );
		echo '<input type="hidden" name="kp_rule_action" value="toggle"><input type="hidden" name="rule_id" value="' . esc_attr( $id ) . '"><input type="hidden" name="enabled" value="' . esc_attr( $enable ? '1' : '0' ) . '"><button class="button" type="submit">' . esc_html( $enable ? '有効化' : '無効化' ) . '</button></form>';
	}

	public function settings(): void {
		$s = KProtect_Utils::settings();
		$this->header( 'KProtect 設定' );
		$this->discord_test_notice();
		$this->slack_test_notice();
		$this->webhook_test_notice();
		echo '<form method="post" action="options.php">';
		settings_fields( 'kprotect_group' );
		echo '<table class="form-table">';
		$this->checkbox( 'enabled', '防壁を有効化', $s );
		$this->number( 'block_threshold', '自動遮断の危険度（0〜100）', $s );
		$this->number( 'log_threshold', 'ログ記録の危険度（0〜100）', $s );
		$this->number( 'block_minutes', '通常ブロック時間（分）', $s );
		$this->number( 'rate_limit_requests', '許可リクエスト数', $s );
		$this->number( 'rate_limit_window', 'レート判定時間（秒）', $s );
		$this->number( 'login_failures', 'ログイン失敗許容回数', $s );
		$this->number( 'login_block_minutes', 'ログインブロック時間（分）', $s );
		$this->checkbox( 'disable_xmlrpc', 'XML-RPCを無効化', $s );
		$this->checkbox( 'log_ip_address', 'IPアドレスを平文保存', $s );
		$this->number( 'log_retention_days', 'ログ保持日数', $s );
		$this->checkbox( 'admin_notifications', '管理画面通知', $s );
		$this->number( 'notification_threshold', '管理画面通知の危険度（0〜100）', $s );
		$this->number( 'notification_retention_days', '通知保持日数', $s );
		$this->checkbox( 'email_notifications', '高危険度メール通知', $s );
		$this->number( 'email_threshold', 'メール通知の危険度（0〜100）', $s );
		$this->event_type_checkboxes( 'email_event_types', 'メール通知する検知種類', $s, 'メール' );
		$this->number( 'email_cooldown_minutes', '同種通知の抑制時間（分）', $s );
		$this->email( 'notification_email', '通知先メールアドレス', $s );
		$this->discord_settings( $s );
		$this->slack_settings( $s );
		$this->webhook_settings( $s );
		$this->rest_api_settings( $s );
		$this->textarea( 'trusted_ips', '信頼IP / CIDR', $s, '1行に1件。現在の接続元を誤って遮断しないよう注意してください。' );
		$this->textarea( 'blocked_ips', '常時ブロックIP / CIDR', $s, '1行に1件。' );
		$this->textarea( 'excluded_paths', 'ファイアウォール除外パス', $s, '1行に1件。完全一致で除外します。末尾が / のルールだけ、その配下も除外します。例: /payment/callback または /wp-json/example/' );
		echo '</table>';
		submit_button();
		echo '</form></div>';
	}
	private function checkbox( string $k, string $label, array $s ): void {
		echo '<tr><th>' . esc_html( $label ) . '</th><td><label><input type="checkbox" name="kprotect_settings[' . esc_attr( $k ) . ']" value="1" ' . checked( 1, (int) $s[ $k ], false ) . '> 有効</label></td></tr>';}
	private function number( string $k, string $label, array $s ): void {
		echo '<tr><th><label for="kp-' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td><input class="small-text" type="number" id="kp-' . esc_attr( $k ) . '" name="kprotect_settings[' . esc_attr( $k ) . ']" value="' . esc_attr( (string) $s[ $k ] ) . '" min="0"></td></tr>';}
	private function event_type_checkboxes( string $k, string $label, array $s, string $channel = 'メール' ): void {
		$selected = isset( $s[ $k ] ) && is_array( $s[ $k ] ) ? array_map( 'sanitize_key', $s[ $k ] ) : array();
		echo '<tr><th>' . esc_html( $label ) . '</th><td><fieldset>';
		foreach ( KProtect_Notification_Rules::event_types() as $value => $text ) {
			echo '<label style="display:block;margin:0 0 6px"><input type="checkbox" name="kprotect_settings[' . esc_attr( $k ) . '][]" value="' . esc_attr( $value ) . '" ' . checked( true, in_array( $value, $selected, true ), false ) . '> ' . esc_html( $text ) . '</label>';
		}
		echo '<p class="description">チェックした種類だけを' . esc_html( $channel ) . '送信します。管理画面通知とログ記録には影響しません。</p></fieldset></td></tr>';
	}

	private function discord_settings( array $s ): void {
		echo '<tr><th colspan="2"><h2>Discord通知</h2><p class="description">Discord Incoming Webhookへサイト名、危険度、検知種類、時刻、管理画面リンクを送信します。IP、リクエストURL、フォーム本文は送信しません。</p></th></tr>';
		$this->checkbox( 'discord_notifications', 'Discord通知', $s );
		$this->number( 'discord_threshold', 'Discord通知の危険度（0〜100）', $s );
		$this->event_type_checkboxes( 'discord_event_types', 'Discord通知する検知種類', $s, 'Discordへ' );
		$this->number( 'discord_cooldown_minutes', 'Discord同種通知の抑制時間（分）', $s );
		echo '<tr><th><label for="kp-discord_webhook_url">Discord Webhook URL</label></th><td><input class="large-text code" type="password" id="kp-discord_webhook_url" name="kprotect_settings[discord_webhook_url]" value="' . esc_attr( (string) ( $s['discord_webhook_url'] ?? '' ) ) . '" autocomplete="off"><p class="description">Discordのチャンネル設定からIncoming Webhookを作成し、HTTPS URLを保存してください。URLは秘密情報として扱ってください。</p>';
		if ( ! empty( $s['discord_webhook_url'] ) ) {
			echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_test_discord' ), 'kprotect_test_discord' ) ) . '">Discord接続テスト</a></p>';}
		echo '</td></tr>';
	}
	private function discord_test_notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect test status; no state is changed.
		$status = isset( $_GET['kp_discord_test'] ) ? sanitize_key( wp_unslash( $_GET['kp_discord_test'] ) ) : '';
		if ( 'success' === $status ) {
			echo '<div class="notice notice-success is-dismissible"><p>Discordへテスト通知を送信しました。</p></div>';
			return;}
		if ( 'error' === $status ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect error message.
			$message = isset( $_GET['kp_message'] ) ? sanitize_text_field( wp_unslash( $_GET['kp_message'] ) ) : '送信に失敗しました。';
			echo '<div class="notice notice-error is-dismissible"><p>Discord接続テストに失敗しました：' . esc_html( $message ) . '</p></div>';}
	}

	private function slack_settings( array $s ): void {
		echo '<tr><th colspan="2"><h2>Slack通知</h2><p class="description">Slack Incoming Webhookへプライバシーを抑えた通知を送信します。IP、リクエストURL、フォーム本文は送信しません。</p></th></tr>';
		$this->checkbox( 'slack_notifications', 'Slack通知', $s );
		$this->number( 'slack_threshold', 'Slack通知の危険度（0〜100）', $s );
		$this->event_type_checkboxes( 'slack_event_types', 'Slack通知する検知種類', $s, 'Slackへ' );
		$this->number( 'slack_cooldown_minutes', 'Slack同種通知の抑制時間（分）', $s );
		echo '<tr><th><label for="kp-slack_webhook_url">Slack Webhook URL</label></th><td><input class="large-text code" type="password" id="kp-slack_webhook_url" name="kprotect_settings[slack_webhook_url]" value="' . esc_attr( (string) ( $s['slack_webhook_url'] ?? '' ) ) . '" autocomplete="off"><p class="description">hooks.slack.com のIncoming Webhook HTTPS URLだけを受け付けます。</p>';
		if ( ! empty( $s['slack_webhook_url'] ) ) {
			echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_test_slack' ), 'kprotect_test_slack' ) ) . '">Slack接続テスト</a></p>';
		} echo '</td></tr>';
	}
	private function webhook_settings( array $s ): void {
		echo '<tr><th colspan="2"><h2>汎用Webhook通知</h2><p class="description">外部の自動化・監視システムへJSON POSTします。HTTPSの公開URLのみ対応し、ローカル／プライベートネットワーク宛ては拒否します。</p></th></tr>';
		$this->checkbox( 'webhook_notifications', '汎用Webhook通知', $s );
		$this->number( 'webhook_threshold', 'Webhook通知の危険度（0〜100）', $s );
		$this->event_type_checkboxes( 'webhook_event_types', 'Webhook通知する検知種類', $s, 'Webhookへ' );
		$this->number( 'webhook_cooldown_minutes', 'Webhook同種通知の抑制時間（分）', $s );
		echo '<tr><th><label for="kp-webhook_url">Webhook URL</label></th><td><input class="large-text code" type="url" id="kp-webhook_url" name="kprotect_settings[webhook_url]" value="' . esc_attr( (string) ( $s['webhook_url'] ?? '' ) ) . '" autocomplete="off"><p class="description">HTTPS必須。IP、アクセスURL、フォーム本文は送信しません。</p>';
		if ( ! empty( $s['webhook_url'] ) ) {
			echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_test_webhook' ), 'kprotect_test_webhook' ) ) . '">Webhook接続テスト</a></p>';
		} echo '</td></tr>';
		echo '<tr><th><label for="kp-webhook_secret">署名用シークレット（任意）</label></th><td><input class="regular-text code" type="password" id="kp-webhook_secret" name="kprotect_settings[webhook_secret]" value="' . esc_attr( (string) ( $s['webhook_secret'] ?? '' ) ) . '" autocomplete="new-password"><p class="description">設定すると X-KProtect-Signature にHMAC-SHA256署名を付けます。</p></td></tr>';
	}
	private function slack_test_notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect test status; no state is changed.
		$status = isset( $_GET['kp_slack_test'] ) ? sanitize_key( wp_unslash( $_GET['kp_slack_test'] ) ) : '';
		if ( 'success' === $status ) {
			echo '<div class="notice notice-success is-dismissible"><p>Slackへテスト通知を送信しました。</p></div>';
			return;
		} if ( 'error' === $status ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect error message.
			$message = isset( $_GET['kp_slack_message'] ) ? sanitize_text_field( wp_unslash( $_GET['kp_slack_message'] ) ) : '送信に失敗しました。';
			echo '<div class="notice notice-error is-dismissible"><p>Slack接続テストに失敗しました：' . esc_html( $message ) . '</p></div>';}}
	private function webhook_test_notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect test status; no state is changed.
		$status = isset( $_GET['kp_webhook_test'] ) ? sanitize_key( wp_unslash( $_GET['kp_webhook_test'] ) ) : '';
		if ( 'success' === $status ) {
			echo '<div class="notice notice-success is-dismissible"><p>Webhookへテスト通知を送信しました。</p></div>';
			return;
		} if ( 'error' === $status ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only post-redirect error message.
			$message = isset( $_GET['kp_webhook_message'] ) ? sanitize_text_field( wp_unslash( $_GET['kp_webhook_message'] ) ) : '送信に失敗しました。';
			echo '<div class="notice notice-error is-dismissible"><p>Webhook接続テストに失敗しました：' . esc_html( $message ) . '</p></div>';}}
	private function rest_api_settings( array $s ): void {
		echo '<tr><th colspan="2"><h2>REST API</h2><p class="description">将来のKProtect Cloudや管理ツール向けの読み取り専用APIです。初期状態は無効です。有効化しても、WordPressで認証された管理者だけが利用できます。</p></th></tr>';
		$this->checkbox( 'rest_api_enabled', '読み取り専用REST API', $s );
		echo '<tr><th>APIエンドポイント</th><td><code>' . esc_html( rest_url( 'kprotect/v1/status' ) ) . '</code><br><code>' . esc_html( rest_url( 'kprotect/v1/dashboard' ) ) . '</code><br><code>' . esc_html( rest_url( 'kprotect/v1/notifications' ) ) . '</code><br><code>' . esc_html( rest_url( 'kprotect/v1/integrity' ) ) . '</code><br><code>' . esc_html( rest_url( 'kprotect/v1/advisor' ) ) . '</code><br><code>' . esc_html( rest_url( 'kprotect/v1/reports' ) ) . '</code><p class="description">Cookie認証では X-WP-Nonce、外部クライアントではWordPressのApplication Passwordなど、WordPress標準の認証方法を利用してください。APIは設定変更やファイル操作を行いません。</p></td></tr>';
	}
	private function email( string $k, string $label, array $s ): void {
		echo '<tr><th><label for="kp-' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td><input class="regular-text" type="email" id="kp-' . esc_attr( $k ) . '" name="kprotect_settings[' . esc_attr( $k ) . ']" value="' . esc_attr( (string) $s[ $k ] ) . '"></td></tr>';}
	private function textarea( string $k, string $label, array $s, string $help ): void {
		echo '<tr><th><label for="kp-' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td><textarea class="large-text code" rows="5" id="kp-' . esc_attr( $k ) . '" name="kprotect_settings[' . esc_attr( $k ) . ']">' . esc_textarea( (string) $s[ $k ] ) . '</textarea><p class="description">' . esc_html( $help ) . '</p></td></tr>';}
	public function full_integrity(): void {
		$this->header( 'ファイル整合性' );
		$result  = $this->full_integrity->last_result();
		$summary = (array) ( $result['summary'] ?? array() );
		echo '<p class="kp-ui-description">WordPressコア、プラグイン、テーマ、uploadsのファイルハッシュを比較します。自動修復・削除・隔離は行いません。</p>';
		echo '<p class="kp-ui-meta"><strong>基準:</strong> ' . esc_html( $this->full_integrity->has_baseline() ? '作成済み' : '未作成' ) . ' ';
		$created = $this->full_integrity->baseline_created_at();
		if ( $created ) {
			echo esc_html( get_date_from_gmt( $created, 'Y-m-d H:i:s' ) );
		} echo '</p>';
		echo '<div class="kp-cards kp-ui-card-grid">';
		foreach ( array(
			'core'    => 'Core',
			'plugins' => 'Plugins',
			'themes'  => 'Themes',
			'uploads' => 'Uploads',
		) as $k => $label ) {
			echo '<div class="kp-card kp-ui-stat-card"><strong>' . esc_html( $label ) . '</strong><span>' . esc_html( (string) ( $summary[ $k ] ?? 0 ) ) . ' files</span></div>';
		} echo '</div>';
		if ( ! empty( $result['changes'] ) ) {
			echo '<table class="widefat striped"><thead><tr><th>分類</th><th>状態</th><th>ファイル</th></tr></thead><tbody>';
			foreach ( (array) $result['changes'] as $c ) {
				echo '<tr><td>' . esc_html( (string) $c['category'] ) . '</td><td>' . esc_html( (string) $c['type'] ) . '</td><td><code>' . esc_html( (string) $c['file'] ) . '</code></td></tr>';
			} echo '</tbody></table>';
		} elseif ( 'clean' === ( $result['status'] ?? '' ) ) {
			echo '<div class="notice notice-success inline"><p>差分は検出されていません。</p></div>'; }
		echo '<div class="kp-ui-toolbar"><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_full_integrity_scan' ), 'kprotect_full_integrity_scan' ) ) . '">今すぐスキャン</a> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=kprotect_full_integrity_baseline' ), 'kprotect_full_integrity_baseline' ) ) . '" onclick="return confirm(\'現在の状態を基準として保存しますか？\');">現在を新しい基準にする</a></div></div>';
	}

	public function full_integrity_scan(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		} check_admin_referer( 'kprotect_full_integrity_scan' );
		$this->full_integrity->scan();
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-full-integrity&scanned=1' ) );
		exit;
	}
	public function full_integrity_baseline(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Forbidden' );
		} check_admin_referer( 'kprotect_full_integrity_baseline' );
		$this->full_integrity->create_baseline();
		$this->full_integrity->scan();
		wp_safe_redirect( admin_url( 'admin.php?page=kprotect-full-integrity&baseline=1' ) );
		exit;
	}
}
