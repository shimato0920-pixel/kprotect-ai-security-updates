# Changelog

## 3.3.3

- Corrected the WordPress Stable tag and current release documentation.

- Consolidated documentation for features delivered from v3.0.1 through v3.3.2, including the GitHub updater, request inspection, firewall diagnostics, adaptive protection, distributed attack detection, Attack Trend, and Attack Intelligence.

- Verified release ZIP publication and SHA-256 integrity metadata.

- No database schema or protection-behavior changes.

## 3.0.0

- Functionality frozen after successful RC3.3.1 device testing.
- Finalized release metadata and pre-release verification documentation.
- Verified all registered administrator POST/AJAX handlers include capability and nonce checks.
- Verified no PHP syntax errors on the available PHP 8.4 runtime.
- Preserved the validated Admin UI 1.0 and dark-mode behavior without functional changes.
- Prepared the one-folder WordPress distribution package for final device testing.

## 3.0.0-rc3.3.1

- セキュリティ診断の説明文をAdmin UI 1.0の共通説明スタイルへ統一し、ダークモードの可読性を改善。

- Added KProtect Admin UI 1.0 color and typography variables.
- Converted page descriptions, report ranges, notification diagnostics, feedback summaries, and queue section headings into high-contrast UI blocks.
- Improved dark-mode readability across AI reports, AI rules, reports, incidents, notifications, and notification queues.
- No database schema or security behavior changes.

## 3.0.0-rc3.1
- Improved shared admin header description contrast in mobile and forced dark mode.


- Added a shared KProtect administration page header to every plugin page.
- Fixed page-title visibility when browser, operating system, and WordPress dark-mode rendering do not agree.
- Added page descriptions and a consistent version badge.
- Improved responsive header layout without changing security features or database structure.

## 3.0.0-rc2.3

- Fixed dark-mode visibility of page-level and section heading titles across KProtect admin pages.
- Added higher-specificity WordPress admin selectors and text-fill safeguards for mobile dark mode.

## 3.0.0-rc2.2

- Comprehensive dark-mode contrast fixes for Advisor, priority plans, integrity, audit, malware scan, and settings pages.

## 3.0.0-rc2.2

- Fixed low-contrast text in mobile dark mode.
- Added explicit dark-mode colors for descriptions, links, forms, tables, AI cards, rule panels, and log explanations.

## 3.0.0-rc2

- Froze version 3 functionality after successful RC1 testing.
- Aligned version metadata and public documentation.
- Added the final RC2 update and regression checklist.
- Reduced the distribution package to runtime files and current user documentation.
- Preserved all RC1 functionality, storage, and security behavior.

## 3.0.0-rc1

- Added short-lived caching for AI Security Analyst aggregate queries.
- Added cache invalidation when security logs are written or cleaned up.
- Improved administration UI consistency, focus visibility, responsive behavior, reduced-motion support, and dark mode.
- Updated WordPress.org readme content for the v3 release candidate.
- Preserved existing settings, logs, notifications, AI rules, queue data, and integrity baselines.

## 3.0.0-alpha6.1

- Fixed the security log fatal error by restoring event explanation and event-label helpers.

# Changelog

## 3.0.0-alpha5.1
- Localized AI Rule Builder field, operator, and action labels.
- Added concise automatic rule names.
- Added safe historical-log rule testing.
- Added duplicate-rule detection and rule-tuning advice.


## 3.0.0-alpha4.1

- Completed the local AI Rule Builder management workflow.
- Added editable structured rule previews.
- Added rule update, enable, disable, and delete actions.
- Kept newly saved rules disabled by default.
- Restricted rules to notification, audit, and incident-priority actions.

## 3.0.0-alpha3
- Add local AI Rule Builder foundation.
- Generate validated, disabled rule drafts from Japanese instructions.
- Store and delete rule drafts without automatic blocking or file operations.

## 3.0.0-alpha2

- Fixed the processed-notification purge link to always return to the Processed view.
- Stored purge results per administrator so the result notice survives clean redirects.
- Removed the browser confirmation handler from the purge link to avoid client-side click cancellation.


## 2.2.0 — 2026-08-05

### Added

- Unified SOC-style local AI dashboard.
- Priority A-D Incident Queue.
- 24-hour Incident Report with previous-day and peak-hour context.
- Local AI Assistant with facts, assessment, actions, caution, and confidence.
- Privacy-preserving aggregate CSV export.
- Responsive dark-mode and high-contrast administration styles.

### Security and privacy

- All AI analysis remains local, deterministic, and read-only.
- No sensitive request data is transmitted to an external AI provider.
- CSV export requires administrator capability and a valid nonce.
- File scanning never deletes, repairs, or quarantines files automatically.

### Compatibility

- No database schema changes.
- Existing settings, logs, notification history, queue data, and integrity baselines are retained.

## 3.0.0-alpha1.3

- Split notifications into pending and processed workflow views.
- Mark administrator-classified notifications as read atomically.
- Added processed notification counts and safe bulk deletion.
- Converted notification state changes to POST requests with nonce protection.

## 3.0.0-beta1

- Enhanced the local AI Security Analyst with previous-24-hour comparison.
- Added top event-type analysis, peak-hour detection, and anonymous repeated-source trends.
- Added prioritized recommendations based on trend and concentration signals.
- Improved responsive analyst cards and dark-mode presentation.
- Kept all analysis read-only and local to WordPress.
