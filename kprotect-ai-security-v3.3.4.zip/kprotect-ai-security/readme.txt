=== KProtect AI Security ===
Contributors: shimato0920
Tags: security, firewall, login, monitoring, integrity
Requires at least: 6.4
Tested up to: 7.0
Requires PHP: 8.0
Stable tag: 3.3.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Local-first WordPress security monitoring with explainable risk scoring, prioritized incidents, reports, and administrator guidance.

== Description ==

KProtect AI Security provides request monitoring, login protection, temporary IP blocking, notifications, incident review, file-integrity checks, uploads scanning, security reports, and explainable local security guidance.

Version 3.3.4 is the current stable release of the version 3 series, including adaptive firewall protection, distributed attack detection, Attack Trend visualization, Attack Intelligence analytics, cache diagnostics, the local Security Analyst, AI Rule Builder, notification workflow, integrity monitoring, and Admin UI 1.0.

The local AI features are deterministic and read-only. No logs, IP addresses, request paths, passwords, form values, cookies, or file contents are sent to an external AI service.

The scanner never deletes, edits, repairs, or quarantines files automatically. Security detections can include false positives. Review the evidence and keep verified backups before changing or deleting files.

== Installation ==

1. Back up the WordPress site and database.
2. Upload the plugin ZIP from Plugins > Add New > Upload Plugin.
3. Activate KProtect AI Security.
4. Open KProtect AI in WordPress administration.
5. Review the protection and notification settings.
6. Create or update integrity baselines only after confirming that the current files are legitimate.
7. Keep WordPress, themes, and plugins updated and use KProtect together with backups, strong authentication, and the hosting provider's security controls.

== Frequently Asked Questions ==

= Does KProtect send site data to an external AI service? =
No. Version 3.3.4 uses deterministic local analysis and does not send security logs or sensitive site data to an external AI service.

= Does the scanner automatically delete or repair files? =
No. Scanning is read-only. KProtect reports differences and provides guidance, but does not automatically delete, repair, or quarantine files.

= Why can legitimate updates appear as file changes? =
WordPress, plugin, and theme updates legitimately modify files. Compare the detection time with update history before treating a change as malicious.

= What does the AI confidence percentage mean? =
It indicates how much local evidence is available for the answer. It is not a probability that the site is compromised or safe.

= Are AI rules activated automatically? =
No. Newly generated rules are saved disabled. An administrator must review and explicitly activate a rule.

= What happens to data when the plugin is deleted? =
KProtect intentionally retains its stored settings and security data. Reinstalling the plugin can reuse those records. Complete removal requires an explicit database cleanup by an administrator.

== Changelog ==

= 3.3.4 =

* Removed internal development notes, historical security reviews, and release-testing documents from the production ZIP.

* Preserved user documentation, licensing information, changelog, and all runtime plugin files.

* No database schema or protection-behavior changes.

= 3.3.3 =

* Corrected the Stable tag and public version documentation.

* Documented the security features delivered from v3.0.1 through v3.3.2, including adaptive protection, distributed attack detection, Attack Trend, and Attack Intelligence.

* Confirmed the GitHub updater metadata, release ZIP, and SHA-256 verification flow.

* No database schema or protection-behavior changes.

= 3.0.0 =
* Froze functionality after successful RC3.3.1 device testing.
* Aligned plugin headers, readme metadata, and release-candidate documentation.
* Added final verification for administrator permissions, nonces, packaging, and PHP syntax.
* Preserved settings, logs, notifications, AI rules, queues, and integrity baselines.
* Kept the validated Admin UI 1.0 and dark-mode behavior unchanged.

= 3.0.0-rc2 =
* Froze version 3 functionality after successful RC1 testing.
* Aligned plugin headers, readme metadata, documentation, and release-candidate version labels.
* Added a final release checklist covering updates, retained data, rules, notifications, logs, integrity checks, and responsive administration screens.
* Reduced the installable package to runtime files and current user documentation.
* Preserved the RC1 security behavior, database schema, settings, logs, notifications, rules, queues, and integrity baselines.

= 3.0.0-rc1 =
* Added a 60-second cache for AI Security Analyst aggregate queries and automatic invalidation when logs change.
* Finalized local AI Security Analyst comparisons, top event types, peak-hour analysis, and anonymous repeated-source trends.
* Finalized the Japanese AI Rule Builder workflow, including log testing, duplicate warnings, editing, activation, deactivation, and safe deletion.
* Finalized pending and processed notification workflows and reliable processed-notification deletion.
* Improved administration focus states, responsive layouts, reduced-motion support, dark mode, and visual consistency.
* Kept analysis local and read-only, with no automatic file deletion, quarantine, or external AI transmission.

= 2.2.0 =
* Unified the local AI Summary, Incident Queue, Incident Report, and AI Assistant into a responsive SOC-style dashboard.
* Added explainable priority A-D incident ordering with recommended actions.
* Added a privacy-preserving 24-hour incident report and aggregate CSV export.
* Preserved existing detection thresholds, blocking behavior, database schema, settings, logs, notifications, queue data, and integrity baselines.

= 2.0.0 =
* First stable KProtect AI Security release.

== Upgrade Notice ==

= 3.3.4 =

Reduces the production ZIP to runtime files and user-facing documentation without changing stored settings, logs, protection behavior, or database schema.
