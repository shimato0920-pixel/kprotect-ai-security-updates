<?php
/**
 * Update diagnostics for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_Update_Diagnostics {

	private const CACHE_KEY = 'kprotect_public_update_release';

	private const ERROR_KEY = 'kprotect_public_update_error';

	public static function status(): array {
		$cached = get_site_transient( self::CACHE_KEY );
		$error  = get_site_transient( self::ERROR_KEY );

		$cache_exists   = is_array( $cached );
		$cached_version = null;
		$checked_at     = null;
		$expires_at     = null;
		$remaining      = null;

		if ( $cache_exists && ! empty( $cached['version'] ) ) {
			$cached_version = sanitize_text_field(
				(string) $cached['version']
			);
		}

		if ( $cache_exists && isset( $cached['checked_at'] ) ) {
			$checked_at = max( 0, (int) $cached['checked_at'] );
			$expires_at = $checked_at + HOUR_IN_SECONDS;
			$remaining  = max( 0, $expires_at - time() );
		}

		$last_error_code        = null;
		$last_error_http_status = null;
		$last_error_at          = null;

		if ( is_array( $error ) ) {
			if ( ! empty( $error['code'] ) ) {
				$last_error_code = sanitize_text_field(
					(string) $error['code']
				);
			}

			if ( isset( $error['http_status'] ) ) {
				$last_error_http_status = max(
					0,
					(int) $error['http_status']
				);
			}

			if ( isset( $error['checked_at'] ) ) {
				$last_error_at = max(
					0,
					(int) $error['checked_at']
				);
			}
		}

		return array(
			'current_version'        => KPROTECT_VERSION,
			'last_error_code'        => $last_error_code,
			'last_error_http_status' => $last_error_http_status,
			'last_error_at'          => $last_error_at,
			'cache_exists'           => $cache_exists,
			'cached_version'         => $cached_version,
			'update_available'       => null !== $cached_version
				&& version_compare(
					KPROTECT_VERSION,
					$cached_version,
					'<'
				),
			'checked_at'             => $checked_at,
			'expires_at'             => $expires_at,
			'remaining_seconds'      => $remaining,
		);
	}
}
