<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Notification_Center {
	public const STATUS_UNREAD = 'unread';
	public const STATUS_READ   = 'read';

	public const FEEDBACK_CONFIRMED       = 'confirmed';
	public const FEEDBACK_FALSE_POSITIVE  = 'false_positive';
	public const FEEDBACK_REVIEW          = 'review';
	public const FEEDBACK_APPROVED_CHANGE = 'approved_change';

	/** @return array{severity:string,title:string,message:string} */
	public static function describe( string $event_type, int $score, array $reasons ): array {
		$severity = self::severity( $score );
		$labels   = array(
			'firewall'          => 'ファイアウォール検知',
			'rate_limit'        => '大量アクセスを遮断',
			'blocked_ip'        => '遮断中IPからのアクセス',
			'login_failed'      => 'ログイン失敗を検知',
			'login_blocked'     => 'ログイン攻撃を遮断',
			'integrity'         => '重要ファイルの変更を検知',
			'file_integrity'    => 'ファイル整合性の差分を検知',
			'malware_scan'      => 'uploadsスキャンで要確認項目',
			'test_notification' => '通知センターのテスト',
		);
		$clean    = array_values(
			array_filter(
				array_map(
					'sanitize_text_field',
					$reasons
				)
			)
		);

		$is_distributed_login =
			'login_failed' === sanitize_key( $event_type )
			&& in_array( 'distributed_account_attack', $clean, true );

		$title = $is_distributed_login
			? '分散ログイン攻撃を検知'
			: ( $labels[ sanitize_key( $event_type ) ] ?? 'セキュリティイベントを検知' );

		$message = empty( $clean )
			? '詳細な検知理由は記録されていません。'
			: '根拠: ' . implode(
				', ',
				array_map(
					array( __CLASS__, 'evidence_label' ),
					array_slice( $clean, 0, 8 )
				)
			);
		return array(
			'severity' => $severity,
			'title'    => $title,
			'message'  => $message,
		);
	}

	/**
	 * Convert a stored notification into a plain-language explanation.
	 *
	 * @return array{title:string,summary:string,impact:string,actions:array<int,string>,evidence:array<int,string>,is_test:bool}
	 */
	public static function presentation( string $event_type, int $score, string $stored_message ): array {
		$event_type           = sanitize_key( $event_type );
		$evidence             = self::extract_evidence( $stored_message );
		$is_test              = 'test_notification' === $event_type;
		$is_kprotect_change   = 'file_integrity' === $event_type && self::is_kprotect_change( $evidence );
		$is_distributed_login =
			'login_failed' === $event_type
			&& in_array( 'distributed_account_attack', $evidence, true );

		$catalog = array(
			'test_notification' => array(
				'title'   => '通知センターの動作確認',
				'summary' => '管理者が実行したテスト通知です。実際の攻撃や侵害を示すものではありません。',
				'impact'  => '対応は不要です。表示、既読操作、メール通知の確認に利用してください。',
				'actions' => array( '表示を確認したら既読にする', 'テスト後に通知しきい値を75以上へ戻す' ),
			),
			'login_failed'      => array(
				'title'   => 'ログイン失敗を検知',
				'summary' => 'WordPressへのログインが失敗しました。単発なら入力ミスの可能性がありますが、短時間に繰り返す場合は総当たり攻撃の疑いがあります。',
				'impact'  => '繰り返されると管理者アカウントが推測される可能性があります。',
				'actions' => array( '関連ログで発生回数を確認する', '管理者パスワードと二段階認証を確認する' ),
			),
			'login_blocked'     => array(
				'title'   => 'ログイン攻撃を自動遮断',
				'summary' => 'ログイン失敗が設定回数を超えたため、接続元を一時的に遮断しました。',
				'impact'  => '防御は作動していますが、同様の試行が続く場合は追加対策が必要です。',
				'actions' => array( '関連ログで攻撃頻度を確認する', 'ログイン失敗上限と遮断時間を見直す' ),
			),
			'firewall'          => array(
				'title'   => '不審なリクエストを検知',
				'summary' => 'URLや入力値に攻撃で使われる特徴が含まれていたため、ファイアウォールが検知しました。',
				'impact'  => 'SQLインジェクション、XSS、ファイル探索などを試みた可能性があります。',
				'actions' => array( '関連ログで検知理由と遮断結果を確認する', '同じ接続元から継続する場合はブロック状況を確認する' ),
			),
			'rate_limit'        => array(
				'title'   => '大量アクセスを自動制限',
				'summary' => '短時間のアクセス数が設定値を超えたため、レート制限が作動しました。',
				'impact'  => 'Bot、スクレイピング、DoSの一部、または正規サービスの集中アクセスの可能性があります。',
				'actions' => array( '関連ログとアクセス時刻を確認する', '正規アクセスなら制限値を慎重に調整する' ),
			),
			'integrity'         => array(
				'title'   => '重要ファイルの変更を検知',
				'summary' => '基準作成後に重要ファイルの内容が変わっています。正規アップデートでも発生します。',
				'impact'  => '心当たりのない変更の場合は改ざんの可能性があります。',
				'actions' => array( '変更ファイルと更新履歴を確認する', '確認前に新しい基準へ更新しない' ),
			),
			'file_integrity'    => array(
				'title'   => 'ファイル整合性の差分を検知',
				'summary' => '基準作成後にファイルの追加・変更・削除を検知しました。正規の更新でも発生します。',
				'impact'  => '心当たりのない差分は改ざんの可能性があります。更新直後の差分は、配布元とバージョンを確認してから承認してください。',
				'actions' => array( '変更対象と更新履歴を確認する', '正規更新と確認できた場合は「承認済み変更」を選び、新しい基準を作成する' ),
			),
			'malware_scan'      => array(
				'title'   => 'uploads内に要確認項目',
				'summary' => 'uploadsフォルダでPHP系ファイルまたは注意が必要なコードを検出しました。',
				'impact'  => '正規ファイルの可能性もありますが、Webシェルなどが置かれる場所でもあります。',
				'actions' => array( '削除前にバックアップを取得する', 'ファイル内容と作成日時を確認する' ),
			),
		);

		if ( $is_distributed_login ) {
			$item = array(
				'title'   => '分散ログイン攻撃を検知',
				'summary' => '複数の攻撃元から同一アカウントを狙う分散ログイン攻撃を検知しました。',
				'impact'  => '単一IPの遮断だけでは止まりにくい攻撃です。対象アカウントの保護状況と継続試行の有無を確認してください。',
				'actions' => array(
					'インシデントセンターで分散ログイン攻撃の発生状況を確認する',
					'管理者アカウントのパスワードと二段階認証を確認する',
					'関連ログで継続的な試行がないか確認する',
				),
			);
		} elseif ( $is_kprotect_change ) {
			$item = array(
				'title'   => 'KProtect更新後のファイル差分を検知',
				'summary' => 'KProtect AI Security自身のファイルが基準作成後に変更されています。プラグイン更新直後であれば、通常発生する差分です。',
				'impact'  => '更新元とバージョンが正しいことを確認できれば、攻撃対応は不要です。心当たりがない場合は改ざんとして調査してください。',
				'actions' => array( 'プラグイン一覧で現在のバージョンを確認する', '公式に入手したZIPで更新したことを確認する', '正規更新なら「承認済み変更」を選び、ファイル整合性の基準を更新する' ),
			);
		} else {
			$item = $catalog[ $event_type ] ?? array(
				'title'   => 'セキュリティイベントを検知',
				'summary' => 'KProtectが通常と異なる動作を検知しました。',
				'impact'  => $score >= 75 ? '危険度が高いため、関連ログの確認を推奨します。' : '直ちに侵害を示すものではありません。',
				'actions' => array( '関連ログを確認する' ),
			);
		}

		return array(
			'title'    => $item['title'],
			'summary'  => $item['summary'],
			'impact'   => $item['impact'],
			'actions'  => $item['actions'],
			'evidence' => array_map( array( __CLASS__, 'evidence_label' ), $evidence ),
			'is_test'  => $is_test,
		);
	}

	/** @param array<int,string> $evidence */
	private static function is_kprotect_change( array $evidence ): bool {
		foreach ( $evidence as $value ) {
			$path = strtolower( wp_normalize_path( (string) $value ) );
			if ( str_contains( $path, 'wp-content/plugins/kprotect-ai-security/' ) || str_contains( $path, 'wp-contentpluginskprotect-ai-security' ) ) {
				return true;
			}
		}
		return false;
	}

	/** @return array<int,string> */
	private static function extract_evidence( string $message ): array {
		$message = preg_replace( '/^根拠:\s*/u', '', $message );
		if ( ! is_string( $message ) || '' === trim( $message ) || '詳細な検知理由は記録されていません。' === $message ) {
			return array(); }
		return array_values( array_filter( array_map( 'trim', explode( ',', $message ) ) ) );
	}

	public static function evidence_label( string $key ): string {
		$labels = array(
			'manual_test'               => '管理者による手動テスト',
			'notification_center_check' => '通知センターの動作確認',
			'sql_injection'             => 'SQLインジェクションの特徴',
			'xss'                       => 'クロスサイトスクリプティングの特徴',
			'path_traversal'            => 'パストラバーサルの特徴',
			'empty_user_agent'          => 'User-Agentが空',
			'automation_user_agent'     => '自動化ツールのUser-Agent',
			'failed_login'              => 'ログイン失敗',
		);

		$raw = sanitize_text_field( $key );

		if ( str_starts_with( $raw, 'attack_type:' ) ) {
			$type = sanitize_key( substr( $raw, strlen( 'attack_type:' ) ) );

			$type_labels = array(
				'sql_injection'      => 'SQLインジェクション',
				'xss'                => 'クロスサイトスクリプティング',
				'path_traversal'     => 'パストラバーサル',
				'code_execution'     => 'コード実行攻撃',
				'sensitive_file'     => '機密ファイル探索',
				'webshell_probe'     => 'Webシェル探索',
				'suspicious_request' => '不審なリクエスト',
				'unknown'            => '不明',
			);

			return '攻撃タイプ: ' . ( $type_labels[ $type ] ?? str_replace( '_', ' ', $type ) );
		}

		if ( str_starts_with( $raw, 'attack_risk:' ) ) {
			$risk = sanitize_key( substr( $raw, strlen( 'attack_risk:' ) ) );

			$risk_labels = array(
				'low'      => '低',
				'medium'   => '中',
				'high'     => '高',
				'critical' => '重大',
			);

			return '分類危険度: ' . ( $risk_labels[ $risk ] ?? $risk );
		}

		if ( str_starts_with( $raw, 'attack_confidence:' ) ) {
			$confidence = max(
				0,
				min(
					100,
					(int) substr( $raw, strlen( 'attack_confidence:' ) )
				)
			);

			return '分類信頼度: ' . $confidence . '%';
		}

		$normalized = wp_normalize_path( $raw );

		if ( str_contains( $normalized, '/' ) || str_contains( $normalized, '.' ) ) {
			return $normalized;
		}

		$key     = sanitize_key( $raw );
		$labels += array(
			'file_integrity'    => 'ファイル整合性チェック',
			'plugins'           => 'プラグイン領域',
			'themes'            => 'テーマ領域',
			'core'              => 'WordPressコア',
			'uploads'           => 'uploads領域',
			'added'             => '新規追加',
			'modified'          => '内容変更',
			'missing'           => '基準から消失',
			'official_modified' => '公式チェックサムと不一致',
			'official_missing'  => '公式ファイルが欠落',
		);

		return $labels[ $key ] ?? str_replace( '_', ' ', $key );
	}

	public static function severity( int $score ): string {
		if ( $score >= 90 ) {
			return 'critical'; }
		if ( $score >= 75 ) {
			return 'high'; }
		if ( $score >= 50 ) {
			return 'medium'; }
		return 'low';
	}

	public static function fingerprint( string $event_type, array $reasons ): string {
		$event_type = sanitize_key( $event_type );
		$clean      = array_values(
			array_unique(
				array_map(
					'sanitize_key',
					$reasons
				)
			)
		);

		$is_distributed_login =
			'login_failed' === $event_type
			&& in_array( 'distributed_account_attack', $clean, true );

		if ( $is_distributed_login ) {
			$clean = array_values(
				array_filter(
					$clean,
					static fn( string $reason ): bool => ! str_starts_with( $reason, 'attempt_' )
				)
			);
		}

		sort( $clean );

		return hash(
			'sha256',
			$event_type . '|' . implode( '|', $clean )
		);
	}

	public function record( string $event_type, int $score, array $reasons, bool $force = false ): int {
		global $wpdb;
		$settings = KProtect_Utils::settings();
		if ( ! $force && ( empty( $settings['admin_notifications'] ) || $score < (int) $settings['notification_threshold'] ) ) {
			return 0;
		}

		$table = $wpdb->prefix . 'kprotect_notifications';
		if ( ! $this->table_exists() ) {
			KProtect_Installer::activate();
			if ( ! $this->table_exists() ) {
				return 0; }
		}
		$fingerprint = self::fingerprint( $event_type, $reasons );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Notification deduplication must use current KProtect workflow state; query is prepared and bounded.
		$existing = $wpdb->get_row( $wpdb->prepare( 'SELECT id, occurrences FROM %i WHERE fingerprint = %s LIMIT 1', $table, $fingerprint ), ARRAY_A );
		$desc     = self::describe( $event_type, $score, $reasons );
		$now      = current_time( 'mysql', true );

		if ( is_array( $existing ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Updating KProtect notification workflow state must be immediate and must not be cached.
			$wpdb->update(
				$table,
				array(
					'updated_at'  => $now,
					'risk_score'  => max( 0, min( 100, $score ) ),
					'severity'    => $desc['severity'],
					'message'     => $desc['message'],
					'status'      => self::STATUS_UNREAD,
					'occurrences' => (int) $existing['occurrences'] + 1,
				),
				array( 'id' => (int) $existing['id'] ),
				array( '%s', '%d', '%s', '%s', '%s', '%d' ),
				array( '%d' )
			);
			return (int) $existing['id'];
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- New KProtect notification records must be persisted immediately and must not be cached.
		$inserted = $wpdb->insert(
			$table,
			array(
				'created_at'          => $now,
				'updated_at'          => $now,
				'event_type'          => sanitize_key( $event_type ),
				'severity'            => $desc['severity'],
				'title'               => $desc['title'],
				'message'             => $desc['message'],
				'risk_score'          => max( 0, min( 100, $score ) ),
				'status'              => self::STATUS_UNREAD,
				'occurrences'         => 1,
				'feedback_status'     => '',
				'feedback_note'       => '',
				'feedback_updated_at' => null,
				'fingerprint'         => $fingerprint,
				'email_sent'          => 0,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s', '%d' )
		);

		if ( false === $inserted ) {
			return 0;
		}

		return (int) $wpdb->insert_id;
	}

	public function table_exists(): bool {
		global $wpdb;
		$table = $wpdb->prefix . 'kprotect_notifications';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Schema-presence check must reflect the current database state; query is prepared.
		return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
	}

	public function row_count(): int {
		global $wpdb;
		if ( ! $this->table_exists() ) {
			return 0; }
		$table = $wpdb->prefix . 'kprotect_notifications';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Administrative count must reflect current KProtect notification state; query is prepared.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) );
	}

	/** @return array<int,array<string,mixed>> */
	public function latest( int $limit = 100, string $status = '' ): array {
		$view = in_array( $status, array( self::STATUS_UNREAD, self::STATUS_READ ), true ) ? $status : 'all';
		return $this->latest_by_view( $limit, $view );
	}

	/**
	 * Return notifications for one workflow view.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function latest_by_view( int $limit = 100, string $view = 'pending' ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'kprotect_notifications';
		$limit = max( 1, min( 200, $limit ) );
		$view  = sanitize_key( $view );

		if ( ! $this->table_exists() ) {
			return array();
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Notification-center views must reflect current KProtect workflow state; all queries below are read-only, prepared, and bounded by limit.
		if ( 'pending' === $view ) {
			return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE LOWER(TRIM(status)) = %s AND COALESCE(TRIM(feedback_status), '') = '' ORDER BY updated_at DESC LIMIT %d", $table, self::STATUS_UNREAD, $limit ), ARRAY_A );
		}
		if ( 'processed' === $view ) {
			return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE LOWER(TRIM(status)) = %s OR COALESCE(TRIM(feedback_status), '') <> '' ORDER BY updated_at DESC LIMIT %d", $table, self::STATUS_READ, $limit ), ARRAY_A );
		}
		if ( in_array( $view, array( self::STATUS_UNREAD, self::STATUS_READ ), true ) ) {
			return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE LOWER(TRIM(status)) = %s ORDER BY updated_at DESC LIMIT %d', $table, $view, $limit ), ARRAY_A );
		}

		$result = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i ORDER BY updated_at DESC LIMIT %d', $table, $limit ), ARRAY_A );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $result;
	}

	/** @return array{pending:int,processed:int,unread:int,read:int,total:int} */
	public function workflow_counts(): array {
		global $wpdb;
		$out = array(
			'pending'   => 0,
			'processed' => 0,
			'unread'    => 0,
			'read'      => 0,
			'total'     => 0,
		);
		if ( ! $this->table_exists() ) {
			return $out;
		}
		$table = $wpdb->prefix . 'kprotect_notifications';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Workflow counters must reflect current KProtect notification state; query is read-only and prepared.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS total,
				SUM(CASE WHEN LOWER(TRIM(status)) = %s THEN 1 ELSE 0 END) AS unread,
				SUM(CASE WHEN LOWER(TRIM(status)) = %s THEN 1 ELSE 0 END) AS `read`,
				SUM(CASE WHEN LOWER(TRIM(status)) = %s AND COALESCE(TRIM(feedback_status), '') = '' THEN 1 ELSE 0 END) AS pending,
				SUM(CASE WHEN LOWER(TRIM(status)) = %s OR COALESCE(TRIM(feedback_status), '') <> '' THEN 1 ELSE 0 END) AS processed
				FROM %i",
				$table,
				self::STATUS_UNREAD,
				self::STATUS_READ,
				self::STATUS_UNREAD,
				self::STATUS_READ
			),
			ARRAY_A
		);
		if ( is_array( $row ) ) {
			foreach ( $out as $key => $value ) {
				$out[ $key ] = (int) ( $row[ $key ] ?? 0 );
			}
		}
		return $out;
	}

	public function unread_count(): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Admin unread badge must reflect current KProtect notification state; query is prepared.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $wpdb->prefix . 'kprotect_notifications', self::STATUS_UNREAD ) );
	}


	/** @return array<string,string> */
	public static function feedback_labels(): array {
		return array(
			self::FEEDBACK_CONFIRMED       => '正しい検知',
			self::FEEDBACK_FALSE_POSITIVE  => '誤検知',
			self::FEEDBACK_REVIEW          => '要確認',
			self::FEEDBACK_APPROVED_CHANGE => '承認済み変更',
		);
	}

	public function set_feedback( int $id, string $feedback, string $note = '' ): bool {
		return $this->set_feedback_and_mark_read( $id, $feedback, $note );
	}

	/**
	 * Store administrator feedback and mark the notification as read.
	 *
	 * A classified notification is no longer considered unread. Updating both
	 * values in one query prevents the UI state and feedback state diverging.
	 */
	public function set_feedback_and_mark_read( int $id, string $feedback, string $note = '' ): bool {
		global $wpdb;
		$feedback = sanitize_key( $feedback );
		if ( ! array_key_exists( $feedback, self::feedback_labels() ) || $id < 1 || ! $this->table_exists() ) {
			return false;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Administrator feedback changes KProtect workflow state and must be persisted immediately.
		$result = $wpdb->update(
			$wpdb->prefix . 'kprotect_notifications',
			array(
				'feedback_status'     => $feedback,
				'feedback_note'       => sanitize_textarea_field( $note ),
				'feedback_updated_at' => current_time( 'mysql', true ),
				'status'              => self::STATUS_READ,
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
		return false !== $result;
	}

	/** @return array{confirmed:int,false_positive:int,review:int,approved_change:int,total:int} */
	public function feedback_counts(): array {
		global $wpdb;
		$out = array(
			'confirmed'       => 0,
			'false_positive'  => 0,
			'review'          => 0,
			'approved_change' => 0,
			'total'           => 0,
		);
		if ( ! $this->table_exists() ) {
			return $out; }
		$table = $wpdb->prefix . 'kprotect_notifications';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Feedback counters must reflect current KProtect workflow state; query is read-only and prepared.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT feedback_status, COUNT(*) AS total FROM %i WHERE feedback_status <> '' GROUP BY feedback_status", $table ), ARRAY_A );
		foreach ( $rows as $row ) {
			$key = sanitize_key( (string) ( $row['feedback_status'] ?? '' ) );
			if ( array_key_exists( $key, $out ) ) {
				$out[ $key ]   = (int) $row['total'];
				$out['total'] += (int) $row['total']; }
		}
		return $out;
	}

	public function mark_read( int $id ): int {
		global $wpdb;
		if ( $id <= 0 || ! $this->table_exists() ) {
			return 0;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Marking a KProtect notification read is an immediate workflow-state write.
		$result = $wpdb->update( $wpdb->prefix . 'kprotect_notifications', array( 'status' => self::STATUS_READ ), array( 'id' => $id ), array( '%s' ), array( '%d' ) );
		return false === $result ? 0 : (int) $result;
	}

	public function mark_all_read(): int {
		global $wpdb;
		if ( ! $this->table_exists() ) {
			return 0;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Bulk read-state update is an immediate KProtect workflow-state write; SQL is prepared.
		$result = $wpdb->query( $wpdb->prepare( 'UPDATE %i SET status = %s WHERE LOWER(TRIM(status)) = %s', $wpdb->prefix . 'kprotect_notifications', self::STATUS_READ, self::STATUS_UNREAD ) );
		return false === $result ? 0 : (int) $result;
	}

	/** @return int|false Number of deleted rows, or false on database failure. */
	public function delete_processed() {
		global $wpdb;
		if ( ! $this->table_exists() ) {
			return false;
		}

		$table = $wpdb->prefix . 'kprotect_notifications';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Processed IDs must be read from current KProtect workflow state before deletion; query is prepared.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM %i WHERE LOWER(TRIM(status)) = %s OR COALESCE(TRIM(feedback_status), '') <> '' ORDER BY id ASC",
				$table,
				self::STATUS_READ
			)
		);

		if ( null === $ids ) {
			return false;
		}
		$ids = array_values( array_filter( array_map( 'absint', (array) $ids ) ) );
		if ( empty( $ids ) ) {
			return 0;
		}

		$deleted = 0;
		foreach ( $ids as $id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Administrator-requested deletion of processed KProtect notifications must be immediate.
			$result = $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
			if ( false === $result ) {
				return false;
			}
			$deleted += (int) $result;
		}

		return $deleted;
	}

	/** Backward-compatible alias. */
	public function delete_read() {
		return $this->delete_processed();
	}


	public function cleanup(): void {
		global $wpdb;
		$days   = max( 1, (int) KProtect_Utils::settings()['notification_retention_days'] );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * $days );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Retention cleanup deletes expired KProtect notification rows immediately; SQL is prepared.
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE updated_at < %s', $wpdb->prefix . 'kprotect_notifications', $cutoff ) );
	}
}
