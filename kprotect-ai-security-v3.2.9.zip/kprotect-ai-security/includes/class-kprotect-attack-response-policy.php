<?php
/**
 * Attack response policy for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies attack-type-aware protection adjustments.
 */
final class KProtect_Attack_Response_Policy {

	/**
	 * Adjust the effective block threshold for a classified attack.
	 *
	 * @param int   $block_threshold Effective block threshold.
	 * @param array $classification  Attack classification.
	 * @return int
	 */
	public static function block_threshold(
		int $block_threshold,
		array $classification
	): int {
		$block_threshold = max( 0, min( 100, $block_threshold ) );
		$type            = sanitize_key(
			(string) ( $classification['type'] ?? 'unknown' )
		);

		$critical_types = array(
			'code_execution',
			'webshell_probe',
			'sql_injection',
			'path_traversal',
		);

		$high_types = array(
			'xss',
			'sensitive_file',
		);

		if ( in_array( $type, $critical_types, true ) ) {
			return max( 40, $block_threshold - 10 );
		}

		if ( in_array( $type, $high_types, true ) ) {
			return max( 40, $block_threshold - 5 );
		}

		return $block_threshold;
	}
}
