<?php
/**
 * Logger for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Logger class.
 *
 * @package KProtect_AI_Security
 */
final class KProtect_Logger {
	public function log( string $type, int $score, array $reasons, bool $blocked = false, ?string $ip = null ): void {
		global $wpdb;
		$settings = KProtect_Utils::settings();
		$ip       = '' !== $ip
		? $ip
		: KProtect_Utils::client_ip();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Security events must be written immediately to the KProtect-owned log table and must not be cached.
		$wpdb->insert(
			$wpdb->prefix . 'kprotect_logs',
			array(
				'created_at'     => current_time( 'mysql', true ),
				'event_type'     => sanitize_key( $type ),
				'risk_score'     => max( 0, min( 100, $score ) ),
				'ip_hash'        => KProtect_Utils::ip_hash( $ip ),
				'ip_address'     => ! empty( $settings['log_ip_address'] ) ? $ip : '',
				'request_method' => isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '',
				'request_path'   => KProtect_Utils::current_path(),
				'reasons'        => wp_json_encode( array_values( array_map( 'sanitize_text_field', $reasons ) ), JSON_UNESCAPED_UNICODE ),
				'blocked'        => $blocked ? 1 : 0,
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d' )
		);
		KProtect_Security_Analyst::clear_cache();
		( new KProtect_Notifier() )->maybe_send( $type, $score, $reasons );
	}

	public function cleanup(): void {
		global $wpdb;
		$days   = max( 1, (int) KProtect_Utils::settings()['log_retention_days'] );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * $days );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Retention cleanup deletes expired rows from KProtect-owned tables; write operations must not be cached and SQL is prepared.
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE created_at < %s', $wpdb->prefix . 'kprotect_logs', $cutoff ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE active = 0 AND expires_at < %s', $wpdb->prefix . 'kprotect_blocks', gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * 7 ) ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		KProtect_Security_Analyst::clear_cache();
		KProtect_Threat_Level::clear_cache();
		KProtect_Attack_Trend::clear_cache();
	}
}
