<?php
/**
 * Attack classification engine for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Classifies detector reasons into normalized attack types.
 */
final class KProtect_Attack_Classifier {

	/**
	 * Classify a detected request.
	 *
	 * @param array $reasons Detector reasons.
	 * @param int   $score   Detector risk score.
	 * @return array{type:string,risk:string,confidence:int}
	 */
	public static function classify( array $reasons, int $score ): array {
		$reasons = array_values(
			array_unique(
				array_map(
					'strval',
					$reasons
				)
			)
		);

		$score = max( 0, min( 100, $score ) );

		$primary_types = array(
			'code_execution',
			'webshell_probe',
			'sql_injection',
			'path_traversal',
			'xss',
			'sensitive_file',
		);

		foreach ( $primary_types as $type ) {
			if ( in_array( $type, $reasons, true ) ) {
				return array(
					'type'       => $type,
					'risk'       => self::risk_for_type( $type ),
					'confidence' => 100,
				);
			}
		}

		if ( $score > 0 ) {
			return array(
				'type'       => 'suspicious_request',
				'risk'       => self::risk_for_score( $score ),
				'confidence' => self::suspicious_confidence( $score ),
			);
		}

		return array(
			'type'       => 'unknown',
			'risk'       => 'low',
			'confidence' => 0,
		);
	}

	/**
	 * Return risk level for a primary attack type.
	 */
	private static function risk_for_type( string $type ): string {
		$critical = array(
			'code_execution',
			'webshell_probe',
			'sql_injection',
			'path_traversal',
		);

		return in_array( $type, $critical, true )
			? 'critical'
			: 'high';
	}

	/**
	 * Convert numeric score into normalized risk level.
	 */
	private static function risk_for_score( int $score ): string {
		if ( $score >= 90 ) {
			return 'critical';
		}

		if ( $score >= 70 ) {
			return 'high';
		}

		if ( $score >= 25 ) {
			return 'medium';
		}

		return 'low';
	}

	/**
	 * Calculate confidence for requests without a primary signature.
	 */
	private static function suspicious_confidence( int $score ): int {
		return max( 1, min( 99, $score ) );
	}
}
