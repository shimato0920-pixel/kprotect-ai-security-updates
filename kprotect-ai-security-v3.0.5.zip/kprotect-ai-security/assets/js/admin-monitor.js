(function () {
	'use strict';
	if (!window.KProtectMonitor) return;

	var palette = ['#2271b1', '#00a32a', '#dba617', '#d63638', '#8c8f94', '#7e5bef', '#00a0d2', '#c9356e'];

	function parseInitialData() {
		var el = document.getElementById('kp-dashboard-data');
		if (!el) return null;
		try { return JSON.parse(el.textContent); } catch (e) { return null; }
	}

	function setupCanvas(canvas) {
		if (!canvas) return null;
		var rect = canvas.getBoundingClientRect();
		var ratio = window.devicePixelRatio || 1;
		var width = Math.max(320, Math.floor(rect.width || 600));
		var height = parseInt(canvas.getAttribute('height'), 10) || 240;
		canvas.width = width * ratio;
		canvas.height = height * ratio;
		canvas.style.height = height + 'px';
		var ctx = canvas.getContext('2d');
		ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
		return { ctx: ctx, width: width, height: height };
	}

	function drawTimeline(rows) {
		var canvas = document.getElementById('kp-timeline-chart');
		var view = setupCanvas(canvas);
		if (!view || !rows || !rows.length) return;
		var ctx = view.ctx, w = view.width, h = view.height;
		var pad = { top: 18, right: 18, bottom: 38, left: 38 };
		var plotW = w - pad.left - pad.right, plotH = h - pad.top - pad.bottom;
		var max = Math.max.apply(null, rows.map(function (r) { return Math.max(r.total || 0, r.blocked || 0); }).concat([1]));
		ctx.clearRect(0, 0, w, h);
		ctx.font = '12px sans-serif';
		ctx.fillStyle = '#646970';
		ctx.strokeStyle = '#dcdcde';
		ctx.lineWidth = 1;
		for (var i = 0; i <= 4; i++) {
			var y = pad.top + plotH * i / 4;
			ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(w - pad.right, y); ctx.stroke();
			ctx.fillText(String(Math.round(max * (4 - i) / 4)), 4, y + 4);
		}
		function line(key, color) {
			ctx.strokeStyle = color; ctx.lineWidth = 2.5; ctx.beginPath();
			rows.forEach(function (r, index) {
				var x = pad.left + (rows.length === 1 ? plotW / 2 : plotW * index / (rows.length - 1));
				var y = pad.top + plotH - ((r[key] || 0) / max * plotH);
				if (index === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
			});
			ctx.stroke();
		}
		line('total', palette[0]); line('blocked', palette[3]);
		ctx.fillStyle = '#646970';
		rows.forEach(function (r, index) {
			if (index % 2 !== 0 && rows.length > 8) return;
			var x = pad.left + (rows.length === 1 ? plotW / 2 : plotW * index / (rows.length - 1));
			ctx.fillText(r.label, Math.max(0, x - 16), h - 12);
		});
		ctx.fillStyle = palette[0]; ctx.fillRect(w - 170, 5, 14, 3); ctx.fillStyle = '#50575e'; ctx.fillText('検知', w - 150, 10);
		ctx.fillStyle = palette[3]; ctx.fillRect(w - 100, 5, 14, 3); ctx.fillStyle = '#50575e'; ctx.fillText('遮断', w - 80, 10);
	}

	function drawTypes(rows) {
		var canvas = document.getElementById('kp-type-chart');
		var view = setupCanvas(canvas);
		var legend = document.getElementById('kp-type-legend');
		if (!view || !legend) return;
		var ctx = view.ctx, w = view.width, h = view.height;
		ctx.clearRect(0, 0, w, h); legend.innerHTML = '';
		var total = (rows || []).reduce(function (sum, r) { return sum + (r.total || 0); }, 0);
		if (!total) { ctx.fillStyle = '#646970'; ctx.font = '14px sans-serif'; ctx.fillText('対象期間の検知はありません。', 24, 40); return; }
		var cx = w / 2, cy = h / 2 - 5, radius = Math.min(w, h) * 0.31, start = -Math.PI / 2;
		rows.forEach(function (r, index) {
			var angle = Math.PI * 2 * r.total / total;
			ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, radius, start, start + angle); ctx.closePath(); ctx.fillStyle = palette[index % palette.length]; ctx.fill(); start += angle;
			var item = document.createElement('span');
			item.innerHTML = '<i style="background:' + palette[index % palette.length] + '"></i>' + escapeHtml(r.label) + ' (' + r.total + ')';
			legend.appendChild(item);
		});
		ctx.beginPath(); ctx.arc(cx, cy, radius * 0.55, 0, Math.PI * 2); ctx.fillStyle = '#fff'; ctx.fill();
		ctx.fillStyle = '#1d2327'; ctx.textAlign = 'center'; ctx.font = 'bold 26px sans-serif'; ctx.fillText(String(total), cx, cy + 4);
		ctx.font = '12px sans-serif'; ctx.fillStyle = '#646970'; ctx.fillText('合計', cx, cy + 24); ctx.textAlign = 'start';
	}

	function escapeHtml(value) {
		return String(value || '').replace(/[&<>'"]/g, function (ch) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' })[ch]; });
	}

	function renderEvents(rows) {
		var body = document.getElementById('kp-live-events');
		if (!body) return;
		if (!rows || !rows.length) { body.innerHTML = '<tr><td colspan="6">直近の検知ログはありません。</td></tr>'; return; }
		body.innerHTML = rows.map(function (r) {
			var cls = r.risk >= 80 ? 'danger' : (r.risk >= 50 ? 'watch' : 'safe');
			return '<tr><td>' + escapeHtml(r.time) + '</td><td>' + escapeHtml(r.label) + '</td><td><span class="kp-risk-pill ' + cls + '">' + r.risk + '</span></td><td><code>' + escapeHtml(r.source) + '</code></td><td>' + (r.blocked ? '<strong>遮断</strong>' : '記録') + '</td><td>' + escapeHtml(r.reason) + '</td></tr>';
		}).join('');
	}


	function renderIncidentQueue(rows) {
		var container = document.getElementById('kp-incident-queue');
		if (!container) return;
		if (!rows || !rows.length) {
			container.innerHTML = '<p class="kp-incident-empty">現在、優先対応が必要なイベントはありません。</p>';
			return;
		}
		container.innerHTML = rows.map(function (item) {
			var priority = String(item.priority || 'D').replace(/[^A-D]/g, '') || 'D';
			return '<article class="kp-incident-item kp-incident-priority-' + priority.toLowerCase() + '">' +
				'<div class="kp-incident-priority"><strong>' + escapeHtml(priority) + '</strong><span>' + escapeHtml(item.priority_label) + '</span></div>' +
				'<div class="kp-incident-main"><div class="kp-incident-title"><h3>' + escapeHtml(item.label) + '</h3><span>' + escapeHtml(item.count) + '件</span></div>' +
				'<p>' + escapeHtml(item.reason) + '</p><small>推奨：' + escapeHtml(item.action) + '</small></div>' +
				'<div class="kp-incident-metrics"><span>最大危険度 <strong>' + escapeHtml(item.max_risk) + '</strong></span><span>未遮断 <strong>' + escapeHtml(item.unblocked_count) + '</strong></span></div>' +
			'</article>';
		}).join('');
	}


	function renderIncidentReport(report) {
		if (!report) return;
		var section = document.querySelector('.kp-incident-report');
		if (section) section.className = 'kp-panel kp-incident-report kp-report-' + escapeHtml(report.level || 'normal');
		var period = document.getElementById('kp-report-period');
		var trend = document.getElementById('kp-report-trend');
		var summary = document.getElementById('kp-report-summary');
		var peak = document.getElementById('kp-report-peak');
		var peakTotal = document.getElementById('kp-report-peak-total');
		var events = document.getElementById('kp-report-events');
		if (period) period.textContent = report.period || '直近24時間';
		if (trend) trend.textContent = report.trend_label || '前日比較データなし';
		if (summary) summary.textContent = report.summary || '';
		if (peak) peak.textContent = report.peak_label || '該当なし';
		if (peakTotal) peakTotal.textContent = report.peak_total || 0;
		if (events) {
			events.innerHTML = (report.top_events || []).map(function (event) {
				return '<li><span>' + escapeHtml(event.label) + '</span><strong>' + escapeHtml(event.total) + '件</strong></li>';
			}).join('') || '<li><span>対象イベントなし</span><strong>0件</strong></li>';
		}
		var metrics = document.querySelectorAll('.kp-report-metrics strong');
		[report.total || 0, report.blocked || 0, report.unblocked || 0, report.max_risk || 0].forEach(function (value, index) {
			if (metrics[index]) metrics[index].textContent = value;
		});
	}

	function renderIntelligence(data) {
		if (!data) return;
		var section = document.querySelector('.kp-ai-overview');
		if (section) section.className = 'kp-ai-overview kp-ai-' + escapeHtml(data.level || 'safe');
		var score = document.getElementById('kp-ai-score');
		var title = document.getElementById('kp-ai-title');
		var summary = document.getElementById('kp-ai-summary');
		var recommendation = document.getElementById('kp-ai-recommendation');
		var confidence = document.getElementById('kp-ai-confidence');
		var assessment = document.getElementById('kp-ai-assessment');
		var likelihood = document.getElementById('kp-ai-likelihood');
		var evidence = document.getElementById('kp-ai-evidence');
		var actions = document.getElementById('kp-ai-actions');
		var planPriority = document.getElementById('kp-ai-plan-priority');
		var planUrgency = document.getElementById('kp-ai-plan-urgency');
		var planTarget = document.getElementById('kp-ai-plan-target');
		var planReasons = document.getElementById('kp-ai-plan-reasons');
		var planDefer = document.getElementById('kp-ai-plan-defer');
		var signals = document.getElementById('kp-ai-signals');
		if (score) score.textContent = data.score || 0;
		if (title) title.textContent = data.title || '';
		if (summary) summary.textContent = data.summary || '';
		if (recommendation) recommendation.textContent = data.recommendation || '';
		if (confidence) confidence.textContent = data.confidence || '限定的';
		if (assessment) assessment.textContent = data.assessment || '';
		if (likelihood) likelihood.textContent = data.likelihood || '判定：追加確認が必要';
		if (evidence) {
			evidence.innerHTML = (data.evidence || []).map(function (item) {
				return '<li>' + escapeHtml(item) + '</li>';
			}).join('');
		}
		var plan = data.response_plan || {};
		if (planPriority) planPriority.textContent = plan.priority || 'D';
		if (planUrgency) planUrgency.textContent = plan.urgency || '定期点検時';
		if (planTarget) planTarget.textContent = plan.target || '';
		if (planReasons) {
			planReasons.innerHTML = (plan.reasons || []).map(function (reason) {
				return '<li>' + escapeHtml(reason) + '</li>';
			}).join('');
		}
		if (planDefer) {
			planDefer.innerHTML = (plan.defer_conditions || []).map(function (condition) {
				return '<li>' + escapeHtml(condition) + '</li>';
			}).join('');
		}
		if (actions) {
			actions.innerHTML = (plan.steps || data.actions || []).map(function (action) {
				return '<li>' + escapeHtml(action) + '</li>';
			}).join('');
		}
		if (signals) {
			signals.innerHTML = (data.signals || []).map(function (signal) {
				return '<div><span>' + escapeHtml(signal.label) + '</span><strong>' + escapeHtml(signal.value) + '</strong></div>';
			}).join('');
		}
	}

	function renderDashboard(data) {
		if (!data) return;
		drawTimeline(data.timeline || []);
		drawTypes(data.types || []);
		renderEvents(data.recent || []);
		renderIntelligence(data.intelligence || null);
		renderIncidentQueue((data.intelligence || {}).incident_queue || []);
		renderIncidentReport((data.intelligence || {}).incident_report || null);
	}

	function refresh() {
		var body = new URLSearchParams({ action: 'kprotect_monitor', nonce: KProtectMonitor.nonce });
		fetch(KProtectMonitor.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() })
			.then(function (r) { return r.json(); })
			.then(function (r) {
				if (!r.success) return;
				var d = r.data, status = document.getElementById('kp-status');
				if (document.getElementById('kp-hour')) document.getElementById('kp-hour').textContent = d.hour;
				if (document.getElementById('kp-risk')) document.getElementById('kp-risk').textContent = d.risk;
				if (document.getElementById('kp-updated')) document.getElementById('kp-updated').textContent = '最終更新 ' + d.updated;
				if (status) { status.textContent = d.status; status.className = 'kp-status ' + d.class; }
				renderDashboard(d.dashboard);
			}).catch(function () {});
	}


	function renderAssistantAnswer(answer) {
		var container = document.getElementById('kp-ai-chat-result');
		if (!container) return;
		var confidenceScore = Math.max(0, Math.min(100, Number(answer.confidence_score || 0)));
		container.innerHTML = '<article><div class="kp-ai-chat-answer-heading"><strong>' + escapeHtml(answer.headline || '回答') + '</strong><span>確度：' + escapeHtml(answer.confidence || '限定的') + ' ' + confidenceScore + '%</span></div>' +
			'<div class="kp-confidence-meter" role="meter" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + confidenceScore + '"><span style="width:' + confidenceScore + '%"></span></div>' +
			'<h3>確認できる事実</h3><ul>' + (answer.facts || []).map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul>' +
			'<h3>評価</h3><p>' + escapeHtml(answer.assessment || '') + '</p>' +
			'<h3>推奨対応</h3><ol>' + (answer.actions || []).map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ol>' +
			'<p class="kp-ai-chat-caution">' + escapeHtml(answer.caution || '') + '</p></article>';
	}

	function askAssistant(question) {
		var container = document.getElementById('kp-ai-chat-result');
		if (container) container.innerHTML = '<p>ローカルデータを確認しています…</p>';
		var body = new URLSearchParams({ action: 'kprotect_ai_assistant', nonce: KProtectMonitor.nonce, question: question || '' });
		fetch(KProtectMonitor.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() })
			.then(function (r) { return r.json(); })
			.then(function (r) {
				if (!r.success) throw new Error('assistant_error');
				renderAssistantAnswer(r.data || {});
			}).catch(function () {
				if (container) container.innerHTML = '<p class="kp-ai-chat-error">回答を生成できませんでした。ページを再読み込みして再試行してください。</p>';
			});
	}

	function setupAssistant() {
		var form = document.getElementById('kp-ai-chat-form');
		var input = document.getElementById('kp-ai-chat-question');
		if (form && input) {
			form.addEventListener('submit', function (event) {
				event.preventDefault();
				askAssistant(input.value);
			});
		}
		document.querySelectorAll('[data-kp-question]').forEach(function (button) {
			button.addEventListener('click', function () {
				var question = button.getAttribute('data-kp-question') || '';
				if (input) input.value = question;
				askAssistant(question);
			});
		});
	}

	var initial = parseInitialData();
	if (initial) renderDashboard(initial);
	setupAssistant();
	window.addEventListener('resize', function () { if (initial) renderDashboard(initial); });
	setInterval(refresh, 10000);
})();
