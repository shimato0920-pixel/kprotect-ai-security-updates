# Security Review 2.1.0-beta2.1

## Changes

- Authenticated administrators are never automatically blocked by the request firewall.
- Suspicious administrator requests at or above the log threshold are still recorded with the `administrator_session` reason.
- Rate-limit responses use HTTP 429 and include `Retry-After: 60`.
- Logged query values are redacted for additional credential and session-related names.

## Unchanged safety properties

- No automatic file deletion, editing, repair, or quarantine.
- No database schema change.
- Existing settings, logs, notifications, queue data, delivery history, and integrity baselines are preserved.
- The firewall still uses `REMOTE_ADDR` only; trusted-proxy support is not enabled implicitly.
