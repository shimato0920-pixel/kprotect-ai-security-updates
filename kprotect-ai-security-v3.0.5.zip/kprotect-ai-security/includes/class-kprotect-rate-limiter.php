<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Rate_Limiter {
	public function hit( string $ip ): bool {
		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) ) {
			return false; }
		$settings = KProtect_Utils::settings();
		$limit    = max( 10, (int) $settings['rate_limit_requests'] );
		$window   = max( 10, (int) $settings['rate_limit_window'] );
		$key      = 'kprotect_rate_' . substr( KProtect_Utils::ip_hash( $ip ), 0, 32 );
		$data     = get_transient( $key );
		if ( ! is_array( $data ) ) {
			$data = array(
				'count' => 0,
				'start' => time(),
			); }
		if ( time() - (int) $data['start'] >= $window ) {
			$data = array(
				'count' => 0,
				'start' => time(),
			); }
		++$data['count'];
		set_transient( $key, $data, $window + 5 );
		return $data['count'] > $limit;
	}
}
