<?php
/**
 * AI provider manager for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers providers, resolves the selected provider, and guarantees a local fallback.
 */
final class KProtect_AI_Provider_Manager {
	/**
	 * Option containing the selected provider identifier.
	 */
	private const OPTION_NAME = 'kprotect_ai_provider';

	/**
	 * Return registered providers keyed by stable identifier.
	 *
	 * Future integrations may add providers with the
	 * `kprotect_ai_providers` filter. A provider must implement the interface.
	 *
	 * @return array<string,KProtect_AI_Provider_Interface>
	 */
	public static function providers(): array {
		$providers = array(
			'local' => new KProtect_Local_AI_Provider(),
		);

		if ( function_exists( 'apply_filters' ) ) {
			$filtered = apply_filters( 'kprotect_ai_providers', $providers );
			if ( is_array( $filtered ) ) {
				$providers = $filtered;
			}
		}

		return array_filter(
			$providers,
			static fn( $provider ): bool => $provider instanceof KProtect_AI_Provider_Interface
		);
	}

	/**
	 * Return the selected provider identifier.
	 *
	 * @return string
	 */
	public static function selected_id(): string {
		$selected = function_exists( 'get_option' ) ? (string) get_option( self::OPTION_NAME, 'local' ) : 'local';
		$selected = preg_replace( '/[^a-z0-9_-]/', '', strtolower( $selected ) ) ?? 'local';
		return '' !== $selected ? $selected : 'local';
	}

	/**
	 * Resolve an available provider with an unconditional local fallback.
	 *
	 * @return KProtect_AI_Provider_Interface
	 */
	public static function current(): KProtect_AI_Provider_Interface {
		$providers = self::providers();
		$selected  = self::selected_id();
		$provider  = $providers[ $selected ] ?? null;

		if ( $provider instanceof KProtect_AI_Provider_Interface && $provider->is_available() ) {
			return $provider;
		}

		$local = $providers['local'] ?? new KProtect_Local_AI_Provider();
		return $local instanceof KProtect_AI_Provider_Interface ? $local : new KProtect_Local_AI_Provider();
	}

	/**
	 * Answer through the selected provider and fall back locally on failure.
	 *
	 * Provider exceptions are not exposed to the browser. External providers added
	 * later must not receive raw passwords, request bodies, cookies, or file contents.
	 *
	 * @param string              $question     Administrator question.
	 * @param array<string,mixed> $intelligence Normalized local intelligence.
	 * @return array<string,mixed>
	 */
	public static function answer( string $question, array $intelligence ): array {
		$provider = self::current();

		try {
			return $provider->answer( $question, $intelligence );
		} catch ( Throwable ) {
			if ( 'local' !== $provider->get_id() ) {
				$fallback = new KProtect_Local_AI_Provider();
				$answer   = $fallback->answer( $question, $intelligence );
				$answer['provider_fallback'] = true;
				return $answer;
			}

			return array(
				'provider'   => 'local',
				'headline'   => 'AI回答を生成できませんでした',
				'facts'      => array(),
				'assessment' => 'ローカル分析中に一時的な問題が発生しました。',
				'actions'    => array( '時間を置いて再試行する', 'セキュリティログを直接確認する' ),
				'caution'    => 'エラー内容や機密情報はブラウザへ返していません。',
			);
		}
	}
}
