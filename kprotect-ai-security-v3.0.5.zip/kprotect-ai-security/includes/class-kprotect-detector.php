<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Detector {
	public function inspect(): array {
		$target          = rawurldecode( KProtect_Utils::current_path() );
		$primary_matches = array();
		$modifiers       = array();
		$informational   = array();
		$rules           = array(
			'sql_injection'  => array( 90, '/(?:\bunion\s+(?:all\s+)?select\b|\bsleep\s*\(|\bbenchmark\s*\(|(?:\bor\b|\band\b)\s+[\'"]?\d+[\'"]?\s*=\s*[\'"]?\d+)/i' ),
			'xss'            => array( 85, '/(?:<\s*script\b|javascript\s*:|on(?:error|load|click)\s*=|<\s*iframe\b)/i' ),
			'path_traversal' => array( 90, '/(?:\.\.\/|\.\.\\\\|%2e%2e(?:%2f|%5c)|\/etc\/passwd|proc\/self\/environ)/i' ),
			'code_execution' => array( 100, '/(?:\b(?:eval|assert|system|passthru|shell_exec)\s*\(|base64_decode\s*\()/i' ),
			'sensitive_file' => array( 75, '/(?:^|\/)(?:\.env|\.git\/config|wp-config\.php(?:\.bak)?|composer\.(?:json|lock)|phpinfo\.php)(?:$|\?)/i' ),
			'webshell_probe' => array( 95, '/(?:c99|r57|wso|alfa|shell|cmd)\.(?:php|phtml|php5)(?:$|\?)/i' ),
		);

		foreach ( $rules as $name => $rule ) {
			if ( preg_match( $rule[1], $target ) ) {
				$primary_matches[ $name ] = (int) $rule[0];
			}
		}

		$ua       = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		$ua_lower = strtolower( $ua );
		if ( '' === $ua ) {
			$modifiers['empty_user_agent'] = 25;
		} elseif ( preg_match( '/(?:python-requests|curl\/|wget\/|libwww-perl|go-http-client|scrapy|masscan|nikto|sqlmap|nmap)/i', $ua ) ) {
			$modifiers['suspicious_automation'] = 35;
		} elseif ( preg_match( '/(?:googlebot|bingbot|duckduckbot|yandexbot)/i', $ua ) ) {
			$informational[] = 'known_search_bot_claim';
		}

		$request_method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '';
		if ( 'POST' === strtoupper( $request_method ) && false !== strpos( $target, 'wp-login.php' ) ) {
			$modifiers['login_post'] = 10;
		}
		if ( strlen( $target ) > 1800 ) {
			$modifiers['oversized_request_uri'] = 20;
		}
		if ( substr_count( $target, '%' ) > 40 ) {
			$modifiers['heavy_url_encoding'] = 15;
		}

		$result        = KProtect_Risk_Score_Calculator::calculate( $primary_matches, $modifiers, $informational );
		$result['bot'] = $this->bot_label( $ua_lower );
		return $result;
	}

	private function bot_label( string $ua ): string {
		if ( '' === $ua ) {
			return 'unknown_bot'; }
		if ( preg_match( '/(?:googlebot|bingbot|duckduckbot|yandexbot)/i', $ua ) ) {
			return 'search_bot_claim'; }
		if ( preg_match( '/(?:bot|crawler|spider|python|curl|wget|scrapy|http-client)/i', $ua ) ) {
			return 'automation'; }
		return 'browser';
	}
}
