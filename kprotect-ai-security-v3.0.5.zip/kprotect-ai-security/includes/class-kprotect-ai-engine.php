<?php
/**
 * Local explainable AI-style security engine.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds a deterministic site-wide security assessment from local aggregates.
 *
 * No external AI service is used and no request data is transmitted.
 */
final class KProtect_AI_Engine {
	/**
	 * Analyze dashboard aggregates.
	 *
	 * @param array<int,array<string,mixed>> $timeline Hourly aggregates.
	 * @param array<int,array<string,mixed>> $types    Event type aggregates.
	 * @param array<int,array<string,mixed>> $recent   Recent normalized events.
	 * @param array<string,int>              $comparison Current and previous 24-hour totals.
 * @return array<string,mixed>
	 */
	public static function analyze( array $timeline, array $types, array $recent, array $comparison = array() ): array {
		$total       = 0;
		$blocked     = 0;
		$max_risk    = 0;
		$high_events = 0;

		foreach ( $timeline as $bucket ) {
			$total    += max( 0, (int) ( $bucket['total'] ?? 0 ) );
			$blocked  += max( 0, (int) ( $bucket['blocked'] ?? 0 ) );
			$max_risk = max( $max_risk, max( 0, min( 100, (int) ( $bucket['max_risk'] ?? 0 ) ) ) );
		}

		foreach ( $recent as $event ) {
			if ( (int) ( $event['risk'] ?? 0 ) >= 80 ) {
				++$high_events;
			}
		}

		$unblocked       = max( 0, $total - $blocked );
		$volume_penalty  = min( 20, (int) floor( $total / 8 ) );
		$risk_penalty    = (int) round( $max_risk * 0.55 );
		$escape_penalty  = min( 20, $unblocked * 2 );
		$cluster_penalty = min( 15, $high_events * 5 );
		$risk_score      = min( 100, $volume_penalty + $risk_penalty + $escape_penalty + $cluster_penalty );
		$score           = 100 - $risk_score;
		$block_rate      = $total > 0 ? (int) round( ( $blocked / $total ) * 100 ) : 100;
		$top_type        = self::top_type( $types );
		$top_label       = self::top_label( $types );
		$actions         = self::actions_for( $top_type, $unblocked, $max_risk );
		$evidence        = self::evidence( $top_type, $total, $blocked, $max_risk, $recent );
		$assessment      = self::assessment( $top_type, $total, $blocked, $max_risk, $recent );
		$response_plan    = self::response_plan( $top_type, $total, $blocked, $max_risk, $unblocked, $actions, $assessment );
		$incident_queue   = self::incident_queue( $recent );
		$incident_report  = self::incident_report( $timeline, $types, $recent, $comparison );

		if ( $risk_score >= 75 ) {
			$level          = 'critical';
			$title          = '優先確認が必要なセキュリティ状態です';
			$summary        = '高危険度の検知または未遮断イベントが確認されています。単一ログだけで侵害を断定せず、関連ログと対象機能を確認してください。';
			$recommendation = $actions[0];
		} elseif ( $risk_score >= 50 ) {
			$level          = 'high';
			$title          = '注意が必要な検知が増えています';
			$summary        = '攻撃傾向または危険度の高いイベントがあります。防御は動作していますが、関連するログの確認を推奨します。';
			$recommendation = $actions[0];
		} elseif ( $risk_score >= 25 ) {
			$level          = 'watch';
			$title          = '監視を継続してください';
			$summary        = '重大な異常を示す状態ではありませんが、検知イベントがあります。増加傾向と未遮断イベントを確認してください。';
			$recommendation = $actions[0];
		} else {
			$level          = 'safe';
			$title          = '現在の防御状態は良好です';
			$summary        = '直近のローカルログから、重大な異常は確認されていません。これは侵害が絶対にないことを保証するものではありません。';
			$recommendation = '定期バックアップ、更新、改ざん検知を継続してください。';
			$actions        = array(
				'定期バックアップが復元可能か確認する',
				'WordPress・テーマ・プラグインを最新状態に保つ',
				'管理者アカウントと不要なユーザーを定期監査する',
			);
		}

		return array(
			'score'          => $score,
			'risk_score'     => $risk_score,
			'level'          => $level,
			'title'          => $title,
			'summary'        => $summary,
			'assessment'     => $assessment['text'],
			'likelihood'     => $assessment['likelihood'],
			'recommendation' => $recommendation,
			'actions'        => $actions,
			'response_plan'  => $response_plan,
			'incident_queue'  => $incident_queue,
			'incident_report' => $incident_report,
			'evidence'       => $evidence,
			'confidence'     => self::confidence( $total, $high_events ),
			'signals'        => array(
				array(
					'label' => '検知件数',
					'value' => (string) $total,
				),
				array(
					'label' => '遮断率',
					'value' => $block_rate . '%',
				),
				array(
					'label' => '最大危険度',
					'value' => (string) $max_risk,
				),
				array(
					'label' => '主な検知',
					'value' => $top_label,
				),
			),
			'privacy_note'   => '評価はWordPress内の集計済みローカルデータだけで生成され、外部AIサービスへ送信されません。',
			'components'     => array(
				'volume'    => $volume_penalty,
				'max_risk'  => $risk_penalty,
				'unblocked' => $escape_penalty,
				'clusters'  => $cluster_penalty,
			),
		);
	}


	/**
	 * Build an actionable response plan with urgency and safe defer conditions.
	 *
	 * @param string                            $type         Most common event type.
	 * @param int                               $total        Total events.
	 * @param int                               $blocked      Blocked events.
	 * @param int                               $max_risk     Maximum observed risk.
	 * @param int                               $unblocked    Number of unblocked events.
	 * @param array<int,string>                 $actions      Recommended actions.
	 * @param array{text:string,likelihood:string} $assessment Current assessment.
	 * @return array<string,mixed>
	 */
	private static function response_plan( string $type, int $total, int $blocked, int $max_risk, int $unblocked, array $actions, array $assessment ): array {
		if ( $max_risk >= 90 && $unblocked > 0 ) {
			$priority = 'A';
			$urgency  = '今すぐ（15分以内）';
			$target   = '未遮断の高危険度イベント';
		} elseif ( $max_risk >= 80 || $unblocked >= 5 ) {
			$priority = 'A';
			$urgency  = '本日中';
			$target   = '高危険度イベントと防御ルール';
		} elseif ( $max_risk >= 50 || $total >= 20 ) {
			$priority = 'B';
			$urgency  = '24時間以内';
			$target   = '増加している検知と関連ログ';
		} elseif ( $total > 0 ) {
			$priority = 'C';
			$urgency  = '次回の保守作業まで';
			$target   = '検知傾向と設定';
		} else {
			$priority = 'D';
			$urgency  = '定期点検時';
			$target   = 'バックアップと更新状態';
		}

		$reasons = array(
			'最大危険度 ' . $max_risk,
			'直近12時間の検知 ' . $total . '件',
			$unblocked > 0 ? '未遮断イベント ' . $unblocked . '件' : '検知イベントはすべて遮断または記録のみ',
		);

		$defer_conditions = array(
			'対象の変更・アクセスが管理者の予定した作業と一致している',
			'関連する高危険度イベントが増加していない',
			'復元可能な最新バックアップが確認できている',
		);

		if ( in_array( $type, array( 'integrity', 'file_integrity' ), true ) ) {
			$target = '変更されたファイルと直前の更新操作';
			$defer_conditions[0] = '変更ファイル、時刻、更新履歴がすべて一致している';
		}

		if ( in_array( $type, array( 'login_failed', 'login_blocked' ), true ) ) {
			$target = '対象ユーザーと攻撃元IP';
			$defer_conditions[0] = '対象アカウントに不審な成功ログインがない';
		}

		return array(
			'priority'         => $priority,
			'urgency'          => $urgency,
			'target'           => $target,
			'reasons'          => array_slice( array_values( array_unique( $reasons ) ), 0, 3 ),
			'steps'            => array_slice( array_values( array_unique( $actions ) ), 0, 3 ),
			'defer_conditions' => array_slice( array_values( array_unique( $defer_conditions ) ), 0, 3 ),
			'caution'          => (string) ( $assessment['text'] ?? '' ),
		);
	}

	/**
	 * Build prioritized, event-specific administrator actions.
	 *
	 * @param string $type      Most common event type.
	 * @param int    $unblocked Number of unblocked events.
	 * @param int    $max_risk  Maximum observed risk.
	 * @return array<int,string>
	 */
	private static function actions_for( string $type, int $unblocked, int $max_risk ): array {
		$catalog = array(
			'integrity'      => array(
				'直前の更新・インストール操作と変更ファイルを照合する',
				'意図した変更なら整合性基準を更新し、意図しない変更ならバックアップと正規配布物を比較する',
				'不審な変更がある場合は管理者パスワードと認証キーを更新する',
			),
			'file_integrity' => array(
				'直前の更新・インストール操作と変更ファイルを照合する',
				'意図した変更なら整合性基準を更新し、意図しない変更ならバックアップと正規配布物を比較する',
				'不審な変更がある場合は管理者パスワードと認証キーを更新する',
			),
			'login_failed'   => array(
				'失敗が集中したIPと対象ユーザー名を確認する',
				'管理者アカウントに強固なパスワードと二要素認証を設定する',
				'不要な管理者・休眠ユーザーを無効化する',
			),
			'login_blocked'  => array(
				'遮断対象IPとログイン対象ユーザーを確認する',
				'同じ攻撃元が継続する場合は遮断時間の延長を検討する',
				'管理者アカウントに二要素認証を設定する',
			),
			'xmlrpc'         => array(
				'XML-RPCを利用していない場合は無効化する',
				'Jetpackなど利用中サービスへの影響を確認する',
				'同一IPからの反復アクセスを確認する',
			),
			'rate_limit'     => array(
				'大量アクセスの対象パスと送信元を確認する',
				'正規クローラーや外部監視サービスによるアクセスか照合する',
				'攻撃の場合はレート制限または一時遮断を強化する',
			),
			'malware_scan'   => array(
				'検知ファイルを削除せず、隔離前にバックアップと正規配布物を確認する',
				'最近追加されたプラグイン・テーマと管理操作を照合する',
				'侵害が疑われる場合は認証情報とWordPressソルトを更新する',
			),
			'firewall'       => array(
				'高危険度イベントの対象パスと攻撃手法を確認する',
				'対象のWordPress・テーマ・プラグインを更新する',
				'未遮断イベントがある場合は該当ルールと例外設定を見直す',
			),
		);

		$actions = $catalog[ $type ] ?? array(
			'高危険度ログの対象パス・攻撃元・根拠を確認する',
			'WordPress・テーマ・プラグインを最新状態にする',
			'バックアップと管理者アカウントを確認する',
		);

		if ( $unblocked > 0 && $max_risk >= 80 ) {
			$actions[0] = '未遮断の高危険度イベントを最優先で確認する';
		}

		return array_slice( array_values( array_unique( $actions ) ), 0, 3 );
	}

	/**
	 * Build concise evidence statements for the dashboard.
	 *
	 * @param string                          $type     Most common event type.
	 * @param int                             $total    Total events.
	 * @param int                             $blocked  Blocked events.
	 * @param int                             $max_risk Maximum observed risk.
	 * @param array<int,array<string,mixed>> $recent   Recent normalized events.
	 * @return array<int,string>
	 */
	private static function evidence( string $type, int $total, int $blocked, int $max_risk, array $recent ): array {
		$evidence = array(
			'直近12時間で' . $total . '件を検知',
			'最大危険度は' . $max_risk,
			$blocked > 0 ? $blocked . '件を遮断' : '遮断済みイベントはありません',
		);

		if ( in_array( $type, array( 'integrity', 'file_integrity' ), true ) ) {
			$change_terms = 0;
			foreach ( $recent as $event ) {
				$reason = strtolower( (string) ( $event['reason'] ?? '' ) );
				if ( false !== strpos( $reason, 'modified' ) || false !== strpos( $reason, 'added' ) || false !== strpos( $reason, 'plugin' ) ) {
					++$change_terms;
				}
			}
			if ( $change_terms > 0 ) {
				$evidence[] = '直近ログにプラグイン更新・追加を示す変更記録があります';
			}
		}

		return array_slice( array_values( array_unique( $evidence ) ), 0, 4 );
	}

	/**
	 * Build a cautious interpretation of the current evidence.
	 *
	 * @param string                          $type     Most common event type.
	 * @param int                             $total    Total events.
	 * @param int                             $blocked  Blocked events.
	 * @param int                             $max_risk Maximum observed risk.
	 * @param array<int,array<string,mixed>> $recent   Recent normalized events.
	 * @return array{text:string,likelihood:string}
	 */
	private static function assessment( string $type, int $total, int $blocked, int $max_risk, array $recent ): array {
		if ( in_array( $type, array( 'integrity', 'file_integrity' ), true ) ) {
			$maintenance_signals = 0;
			foreach ( $recent as $event ) {
				$reason = strtolower( (string) ( $event['reason'] ?? '' ) );
				if ( false !== strpos( $reason, 'plugin' ) || false !== strpos( $reason, 'modified' ) || false !== strpos( $reason, 'added' ) ) {
					++$maintenance_signals;
				}
			}

			if ( $maintenance_signals >= 3 && 0 === $blocked ) {
				return array(
					'text'       => '複数ファイルが同時刻帯に変更され、プラグイン更新を示す記録が含まれています。正規更新による可能性がありますが、更新履歴との照合前に安全と断定しないでください。',
					'likelihood' => '正規更新の可能性：高め',
				);
			}

			return array(
				'text'       => 'ファイル変更が確認されています。正規更新でも発生するため、更新履歴・変更対象・配布元を照合して判断してください。',
				'likelihood' => '正規更新の可能性：判定保留',
			);
		}

		if ( $max_risk >= 80 && $total > $blocked ) {
			return array(
				'text'       => '高危険度かつ未遮断のイベントが含まれます。該当ログを優先して確認し、防御ルールが適用されなかった理由を調べてください。',
				'likelihood' => '要対応イベントの可能性：高い',
			);
		}

		if ( $blocked > 0 && $blocked === $total ) {
			return array(
				'text'       => '検知されたイベントはすべて遮断されています。直ちに侵害を示すものではありませんが、同じ攻撃が継続していないか監視してください。',
				'likelihood' => '防御成功の可能性：高い',
			);
		}

		return array(
			'text'       => '現在の集計だけでは正常アクセスと攻撃を確定できません。件数の増加、対象パス、同一送信元の継続性を確認してください。',
			'likelihood' => '判定：追加確認が必要',
		);
	}


	/**
	 * Build a concise local incident report for the previous 24 hours.
	 *
	 * @param array<int,array<string,mixed>> $timeline   Hourly aggregates.
	 * @param array<int,array<string,mixed>> $types      Event type aggregates.
	 * @param array<int,array<string,mixed>> $recent     Recent normalized events.
	 * @param array<string,int>              $comparison Current and previous totals.
	 * @return array<string,mixed>
	 */
	private static function incident_report( array $timeline, array $types, array $recent, array $comparison ): array {
		$total        = 0;
		$blocked      = 0;
		$max_risk     = 0;
		$peak_total   = 0;
		$peak_label   = '該当なし';
		$high_events  = 0;

		foreach ( $timeline as $bucket ) {
			$bucket_total = max( 0, (int) ( $bucket['total'] ?? 0 ) );
			$total       += $bucket_total;
			$blocked     += max( 0, (int) ( $bucket['blocked'] ?? 0 ) );
			$max_risk    = max( $max_risk, max( 0, min( 100, (int) ( $bucket['max_risk'] ?? 0 ) ) ) );
			if ( $bucket_total > $peak_total ) {
				$peak_total = $bucket_total;
				$peak_label = (string) ( $bucket['label'] ?? '該当なし' );
			}
		}

		foreach ( $recent as $event ) {
			if ( (int) ( $event['risk'] ?? 0 ) >= 80 ) {
				++$high_events;
			}
		}

		$unblocked      = max( 0, $total - $blocked );
		$current_total  = max( 0, (int) ( $comparison['current_total'] ?? $total ) );
		$previous_total = max( 0, (int) ( $comparison['previous_total'] ?? 0 ) );
		$trend_percent  = 0;
		$trend_label    = '前日比較データなし';

		if ( $previous_total > 0 ) {
			$trend_percent = (int) round( ( ( $current_total - $previous_total ) / $previous_total ) * 100 );
			if ( $trend_percent > 0 ) {
				$trend_label = '前日比 +' . $trend_percent . '%';
			} elseif ( $trend_percent < 0 ) {
				$trend_label = '前日比 ' . $trend_percent . '%';
			} else {
				$trend_label = '前日と同水準';
			}
		}

		$top_events = array();
		foreach ( array_slice( $types, 0, 4 ) as $type ) {
			$top_events[] = array(
				'label' => (string) ( $type['label'] ?? '不明' ),
				'total' => max( 0, (int) ( $type['total'] ?? 0 ) ),
			);
		}

		if ( 0 === $total ) {
			$level   = 'safe';
			$summary = '直近24時間に記録されたセキュリティイベントはありません。定期更新とバックアップ確認を継続してください。';
		} elseif ( $unblocked > 0 && $max_risk >= 80 ) {
			$level   = 'critical';
			$summary = '未遮断の高危険度イベントが含まれています。Incident Queueの優先度A・Bから確認してください。';
		} elseif ( $high_events > 0 ) {
			$level   = 'high';
			$summary = '高危険度イベントが記録されています。多くが遮断済みでも、同種の反復と対象機能を確認してください。';
		} elseif ( $current_total > $previous_total && $previous_total > 0 ) {
			$level   = 'watch';
			$summary = '前日より検知件数が増えています。ピーク時間帯と主な検知種別を確認し、増加が継続するか監視してください。';
		} else {
			$level   = 'normal';
			$summary = '直近24時間のイベントは記録されていますが、現在の集計だけで重大な侵害を示す状態とは断定できません。';
		}

		return array(
			'period'         => '直近24時間',
			'level'          => $level,
			'total'          => $total,
			'blocked'        => $blocked,
			'unblocked'      => $unblocked,
			'max_risk'       => $max_risk,
			'high_events'    => $high_events,
			'peak_label'     => $peak_label,
			'peak_total'     => $peak_total,
			'trend_percent'  => $trend_percent,
			'trend_label'    => $trend_label,
			'top_events'     => $top_events,
			'summary'        => $summary,
			'privacy_note'   => 'このレポートはWordPress内のローカル集計だけで生成されます。',
		);
	}


	/**
	 * Build a prioritized queue from recent normalized events.
	 *
	 * @param array<int,array<string,mixed>> $recent Recent normalized events.
	 * @return array<int,array<string,mixed>>
	 */
	private static function incident_queue( array $recent ): array {
		$groups = array();

		foreach ( $recent as $event ) {
			$type    = preg_replace( '/[^a-z0-9_\-]/i', '', (string) ( $event['type'] ?? 'unknown' ) );
			$label   = preg_replace( '/<[^>]*>/', '', (string) ( $event['label'] ?? self::event_type_label( $type ) ) );
			$risk    = max( 0, min( 100, (int) ( $event['risk'] ?? 0 ) ) );
			$blocked = ! empty( $event['blocked'] );
			$reason  = (string) ( $event['reason'] ?? '' );

			if ( ! isset( $groups[ $type ] ) ) {
				$groups[ $type ] = array(
					'type'            => $type,
					'label'           => '' !== $label ? $label : self::event_type_label( $type ),
					'count'           => 0,
					'max_risk'        => 0,
					'blocked_count'   => 0,
					'unblocked_count' => 0,
					'reasons'         => array(),
				);
			}

			++$groups[ $type ]['count'];
			$groups[ $type ]['max_risk'] = max( $groups[ $type ]['max_risk'], $risk );
			if ( $blocked ) {
				++$groups[ $type ]['blocked_count'];
			} else {
				++$groups[ $type ]['unblocked_count'];
			}
			if ( '' !== $reason ) {
				$groups[ $type ]['reasons'][] = $reason;
			}
		}

		$queue = array();
		foreach ( $groups as $group ) {
			$priority = self::incident_priority( $group );
			$queue[]  = array(
				'priority'        => $priority['code'],
				'priority_label'  => $priority['label'],
				'sort'            => $priority['sort'],
				'type'            => $group['type'],
				'label'           => $group['label'],
				'count'           => $group['count'],
				'max_risk'        => $group['max_risk'],
				'blocked_count'   => $group['blocked_count'],
				'unblocked_count' => $group['unblocked_count'],
				'reason'          => $priority['reason'],
				'action'          => self::incident_action( $group['type'], $priority['code'] ),
			);
		}

		usort(
			$queue,
			static function ( array $a, array $b ): int {
				if ( $a['sort'] !== $b['sort'] ) {
					return $a['sort'] <=> $b['sort'];
				}
				if ( $a['max_risk'] !== $b['max_risk'] ) {
					return $b['max_risk'] <=> $a['max_risk'];
				}
				return $b['count'] <=> $a['count'];
			}
		);

		return array_slice( $queue, 0, 6 );
	}

	/**
	 * Calculate the incident priority for one grouped event type.
	 *
	 * @param array<string,mixed> $group Grouped event data.
	 * @return array{code:string,label:string,sort:int,reason:string}
	 */
	private static function incident_priority( array $group ): array {
		$type      = (string) $group['type'];
		$risk      = (int) $group['max_risk'];
		$count     = (int) $group['count'];
		$unblocked = (int) $group['unblocked_count'];
		$reasons   = strtolower( implode( ' ', (array) $group['reasons'] ) );
		$sensitive = false !== strpos( $reasons, 'wp-config' ) || false !== strpos( $reasons, '.htaccess' ) || false !== strpos( $reasons, 'administrator' );

		if ( $sensitive || ( $risk >= 90 && $unblocked > 0 ) || ( 'malware_scan' === $type && $risk >= 80 ) ) {
			return array(
				'code'   => 'A',
				'label'  => '今すぐ確認',
				'sort'   => 1,
				'reason' => $sensitive ? '重要ファイルまたは管理者権限に関係する可能性があります。' : '未遮断の非常に高い危険度を含みます。',
			);
		}

		if ( $risk >= 80 || $unblocked >= 5 || in_array( $type, array( 'login_blocked', 'firewall' ), true ) ) {
			return array(
				'code'   => 'B',
				'label'  => '本日中に確認',
				'sort'   => 2,
				'reason' => '高危険度または継続的な攻撃傾向があります。',
			);
		}

		if ( $risk >= 50 || $count >= 10 || in_array( $type, array( 'login_failed', 'xmlrpc', 'rate_limit' ), true ) ) {
			return array(
				'code'   => 'C',
				'label'  => '監視・確認',
				'sort'   => 3,
				'reason' => '増加傾向または中程度の危険度を含みます。',
			);
		}

		return array(
			'code'   => 'D',
			'label'  => '情報・定期確認',
			'sort'   => 4,
			'reason' => '現時点では緊急性の低い記録です。',
		);
	}

	/**
	 * Return a concise administrator action for an incident type.
	 *
	 * @param string $type     Event type.
	 * @param string $priority Priority code.
	 * @return string
	 */
	private static function incident_action( string $type, string $priority ): string {
		$actions = array(
			'file_integrity' => '変更ファイルと更新履歴を照合する',
			'integrity'      => '変更ファイルと更新履歴を照合する',
			'login_failed'   => '対象ユーザーと攻撃元を確認する',
			'login_blocked'  => '遮断対象と成功ログインの有無を確認する',
			'firewall'       => '対象パスと検知根拠を確認する',
			'malware_scan'   => '削除せず正規配布物と比較する',
			'xmlrpc'         => 'XML-RPCの必要性と反復アクセスを確認する',
			'rate_limit'     => '正規クローラーか攻撃かを照合する',
		);

		return $actions[ $type ] ?? ( 'A' === $priority ? '関連ログと対象機能を直ちに確認する' : '関連ログの増加傾向を確認する' );
	}

	/**
	 * Return a Japanese event type label.
	 *
	 * @param string $type Event type.
	 * @return string
	 */
	private static function event_type_label( string $type ): string {
		$labels = array(
			'file_integrity' => 'ファイル整合性',
			'integrity'      => 'ファイル整合性',
			'login_failed'   => 'ログイン失敗',
			'login_blocked'  => 'ログイン遮断',
			'firewall'       => 'ファイアウォール',
			'malware_scan'   => 'マルウェア検知',
			'xmlrpc'         => 'XML-RPC',
			'rate_limit'     => '大量アクセス',
		);

		return $labels[ $type ] ?? str_replace( '_', ' ', $type );
	}

	/**
	 * Return a simple confidence label based on available evidence.
	 *
	 * @param int $total       Total events.
	 * @param int $high_events High-risk recent events.
	 * @return string
	 */
	private static function confidence( int $total, int $high_events ): string {
		if ( $total >= 20 || $high_events >= 3 ) {
			return '高い';
		}
		if ( $total >= 5 || $high_events > 0 ) {
			return '中程度';
		}
		return '限定的';
	}

	/**
	 * Return the most common event type.
	 *
	 * @param array<int,array<string,mixed>> $types Event type aggregates.
	 * @return string
	 */
	private static function top_type( array $types ): string {
		if ( empty( $types ) ) {
			return 'none';
		}

		$first = reset( $types );
		return is_array( $first )
			? preg_replace( '/[^a-z0-9_\-]/i', '', (string) ( $first['type'] ?? 'unknown' ) )
			: 'unknown';
	}

	/**
	 * Return the most common event label.
	 *
	 * @param array<int,array<string,mixed>> $types Event type aggregates.
	 * @return string
	 */
	private static function top_label( array $types ): string {
		if ( empty( $types ) ) {
			return 'なし';
		}

		$first = reset( $types );
		return is_array( $first )
			? preg_replace( '/<[^>]*>/', '', (string) ( $first['label'] ?? '不明' ) )
			: '不明';
	}
}
