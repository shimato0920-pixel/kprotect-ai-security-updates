<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Stores privacy-minimized notification delivery results.
 */
final class KProtect_Delivery_History {
	public const STATUS_SUCCESS = 'success';
	public const STATUS_FAILED  = 'failed';

	private function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'kprotect_delivery_history';
	}

	public function record( string $channel, string $event_type, int $score, array $reasons, bool $success, int $http_code = 0, int $duration_ms = 0, string $error = '', bool $is_test = false, int $attempts = 1 ): int {
		global $wpdb;
		$payload = array(
			'event_type' => sanitize_key( $event_type ),
			'risk_score' => max( 0, min( 100, $score ) ),
			'reasons'    => array_values( array_map( 'sanitize_text_field', $reasons ) ),
			'is_test'    => $is_test,
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Delivery results are audit history and must be persisted immediately to the KProtect-owned table.
		$wpdb->insert(
			$this->table(),
			array(
				'created_at'    => current_time( 'mysql', true ),
				'channel'       => sanitize_key( $channel ),
				'event_type'    => sanitize_key( $event_type ),
				'risk_score'    => max( 0, min( 100, $score ) ),
				'status'        => $success ? self::STATUS_SUCCESS : self::STATUS_FAILED,
				'http_code'     => max( 0, $http_code ),
				'duration_ms'   => max( 0, $duration_ms ),
				'error_message' => wp_html_excerpt( sanitize_text_field( $error ), 500, '' ),
				'attempts'      => max( 1, $attempts ),
				'is_test'       => $is_test ? 1 : 0,
				'payload'       => wp_json_encode( $payload ),
			),
			array( '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%d', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public function latest( int $limit = 100, string $channel = '', string $status = '' ): array {
		global $wpdb;
		$limit = max( 1, min( 500, $limit ) );
		$table          = $this->table();
		$channel_value  = sanitize_key( $channel );
		$channel_filter = '' !== $channel_value ? 1 : 0;
		$status_filter  = in_array( $status, array( self::STATUS_SUCCESS, self::STATUS_FAILED ), true ) ? 1 : 0;
		$status_value   = $status_filter ? $status : '';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Delivery-history view requires current KProtect audit records; query is read-only, prepared, and bounded.
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE ( %d = 0 OR channel = %s ) AND ( %d = 0 OR status = %s ) ORDER BY id DESC LIMIT %d',
				$table,
				$channel_filter,
				$channel_value,
				$status_filter,
				$status_value,
				$limit
			),
			ARRAY_A
		);
	}

	public function get( int $id ): ?array {
		global $wpdb;
		$table = $this->table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Single audit-record lookup must return current KProtect delivery state; query is prepared and bounded.
		$row   = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', $table, $id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	public function stats( int $days = 1 ): array {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', time() - max( 1, $days ) * DAY_IN_SECONDS );
		$table = $this->table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Delivery statistics intentionally reflect current KProtect audit history; query is prepared and bounded by date.
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT channel, status, COUNT(*) AS total FROM %i WHERE created_at >= %s GROUP BY channel, status', $table, $since ), ARRAY_A );
		$out   = array();
		foreach ( array( 'email', 'discord', 'slack', 'webhook' ) as $channel ) {
			$out[ $channel ] = array(
				'success' => 0,
				'failed'  => 0,
				'total'   => 0,
			); }
		foreach ( $rows as $row ) {
			$channel = sanitize_key( (string) $row['channel'] );
			$status  = sanitize_key( (string) $row['status'] );
			if ( ! isset( $out[ $channel ] ) ) {
				$out[ $channel ] = array(
					'success' => 0,
					'failed'  => 0,
					'total'   => 0,
				); }
			if ( isset( $out[ $channel ][ $status ] ) ) {
				$out[ $channel ][ $status ] = (int) $row['total']; }
			$out[ $channel ]['total'] += (int) $row['total'];
		}
		return $out;
	}

	public function latest_tests( int $limit = 20 ): array {
		global $wpdb;
		$limit = max( 1, min( 100, $limit ) );
		$table = $this->table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Connection-test history must show current KProtect audit records; query is prepared and bounded.
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE is_test = 1 ORDER BY id DESC LIMIT %d', $table, $limit ), ARRAY_A );
	}

	public function cleanup( int $days = 30 ): int {
		global $wpdb;
		$before = gmdate( 'Y-m-d H:i:s', time() - max( 1, $days ) * DAY_IN_SECONDS );
		$table = $this->table();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Retention cleanup deletes expired KProtect delivery history; write operation must not be cached and SQL is prepared.
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE created_at < %s', $table, $before ) );
	}
}
