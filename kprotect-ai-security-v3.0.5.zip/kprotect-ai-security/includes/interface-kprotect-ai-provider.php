<?php
/**
 * AI provider contract for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Defines the common contract for local and optional external AI providers.
 */
interface KProtect_AI_Provider_Interface {
	/**
	 * Return the stable provider identifier.
	 *
	 * @return string
	 */
	public function get_id(): string;

	/**
	 * Return the administrator-facing provider label.
	 *
	 * @return string
	 */
	public function get_label(): string;

	/**
	 * Report whether this provider can currently be used.
	 *
	 * @return bool
	 */
	public function is_available(): bool;

	/**
	 * Return provider capabilities without exposing secrets.
	 *
	 * @return array<string,bool>
	 */
	public function get_capabilities(): array;

	/**
	 * Answer an administrator question from normalized intelligence data.
	 *
	 * @param string              $question     Administrator question.
	 * @param array<string,mixed> $intelligence Normalized local intelligence.
	 * @return array<string,mixed>
	 */
	public function answer( string $question, array $intelligence ): array;
}
