<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class KProtect_AI_Rule_Drafter {
	/** @return array<string,mixed> */
	public static function draft( string $instruction ): array {
		$text = sanitize_textarea_field( $instruction );
		$risk = 80; $count = 1; $window = 15;
		if ( preg_match( '/(?:危険度|リスク)[^0-9]{0,8}(\d{1,3})/u', $text, $m ) ) { $risk = max( 0, min( 100, (int) $m[1] ) ); }
		if ( preg_match( '/(\d+)\s*(?:件|回)/u', $text, $m ) ) { $count = max( 1, min( 10000, (int) $m[1] ) ); }
		if ( preg_match( '/(\d+)\s*分/u', $text, $m ) ) { $window = max( 1, min( 1440, (int) $m[1] ) ); }
		$conditions = array( array( 'field' => 'risk_score', 'operator' => '>=', 'value' => $risk ) );
		if ( $count > 1 ) { $conditions[] = array( 'field' => 'count', 'operator' => '>=', 'value' => $count ); }
		if ( false !== strpos( $text, '未遮断' ) || false !== strpos( $text, '遮断されていない' ) ) { $conditions[] = array( 'field' => 'blocked', 'operator' => '=', 'value' => false ); }
		if ( false !== strpos( $text, 'ログイン' ) ) { $conditions[] = array( 'field' => 'event_type', 'operator' => 'contains', 'value' => 'login' ); }
		if ( false !== strpos( $text, 'ファイル' ) || false !== strpos( $text, '改ざん' ) ) { $conditions[] = array( 'field' => 'event_type', 'operator' => 'in', 'value' => array( 'integrity', 'file_integrity' ) ); }
		$actions = array( array( 'type' => 'admin_notification', 'priority' => $risk >= 90 ? 'critical' : 'high' ), array( 'type' => 'audit_log' ) );
		if ( false !== strpos( $text, 'メール' ) ) { $actions[] = array( 'type' => 'email_notification', 'priority' => 'high' ); }
		if ( false !== strpos( $text, '優先' ) || false !== strpos( $text, 'キュー' ) ) { $actions[] = array( 'type' => 'incident_priority', 'priority' => $risk >= 90 ? 'critical' : 'high' ); }
		$name = self::title_from_instruction( $text );
		return array(
			'id' => 'rule-' . wp_generate_password( 8, false, false ),
			'name' => '' !== $name ? $name : 'AI生成ルール案',
			'description' => $text,
			'enabled' => false,
			'conditions' => $conditions,
			'window' => array( 'value' => $window, 'unit' => 'minutes' ),
			'actions' => $actions,
			'created_at' => current_time( 'mysql', true ),
		);
	}
	/** Generate a concise title from the administrator instruction. */
	private static function title_from_instruction( string $text ): string {
		$risk = 0;
		if ( preg_match( '/(?:危険度|リスク)[^0-9]{0,8}(\d{1,3})/u', $text, $match ) ) {
			$risk = max( 0, min( 100, (int) $match[1] ) );
		}
		if ( false !== strpos( $text, 'ログイン' ) ) {
			return $risk > 0 ? '危険度' . $risk . '以上のログイン監視' : 'ログインイベント監視';
		}
		if ( false !== strpos( $text, 'ファイル' ) || false !== strpos( $text, '改ざん' ) ) {
			return 'ファイル変更監視';
		}
		if ( false !== strpos( $text, '未遮断' ) || false !== strpos( $text, '遮断されていない' ) ) {
			return $risk > 0 ? '危険度' . $risk . '以上の未遮断イベント通知' : '未遮断イベント通知';
		}
		return $risk > 0 ? '危険度' . $risk . '以上のイベント通知' : 'セキュリティイベント通知';
	}

}
