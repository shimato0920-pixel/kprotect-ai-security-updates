<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class KProtect_Rule_Tester {
	/** @return array{matched:int,required:int,triggered:bool,scanned:int,summary:string,advice:array<int,string>} */
	public static function test( array $rule ): array {
		global $wpdb;
		$table  = $wpdb->prefix . 'kprotect_logs';
		$window = max( 1, min( 1440, (int) ( $rule['window']['value'] ?? 15 ) ) );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - MINUTE_IN_SECONDS * $window );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Rule testing intentionally evaluates the current KProtect security-log window; query is read-only, prepared, time-bounded, and hard-limited to 1000 rows.
		$rows   = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, created_at, event_type, risk_score, request_method, blocked FROM %i WHERE created_at >= %s ORDER BY created_at DESC LIMIT 1000', $table, $cutoff ), ARRAY_A );
		$required = 1;
		$filters  = array();
		foreach ( (array) ( $rule['conditions'] ?? array() ) as $condition ) {
			if ( 'count' === (string) ( $condition['field'] ?? '' ) ) { $required = max( 1, (int) ( $condition['value'] ?? 1 ) ); }
			else { $filters[] = $condition; }
		}
		$matched = 0;
		foreach ( $rows as $row ) {
			$ok = true;
			foreach ( $filters as $condition ) { if ( ! self::matches( $row, $condition ) ) { $ok = false; break; } }
			if ( $ok ) { ++$matched; }
		}
		$triggered = $matched >= $required;
		return array(
			'matched' => $matched, 'required' => $required, 'triggered' => $triggered, 'scanned' => count( $rows ),
			'summary' => $window . '分間のログ' . count( $rows ) . '件を確認し、条件に' . $matched . '件一致しました。' . ( $triggered ? '現在は発動条件を満たします。' : '現在は発動条件を満たしません。' ),
			'advice' => self::advice( $rule, $matched, $required ),
		);
	}

	private static function matches( array $row, array $condition ): bool {
		$field = (string) ( $condition['field'] ?? '' ); $operator = (string) ( $condition['operator'] ?? '=' ); $expected = $condition['value'] ?? '';
		if ( 'hour' === $field || 'day_of_week' === $field ) { $ts = strtotime( (string) ( $row['created_at'] ?? '' ) . ' UTC' ); $actual = 'hour' === $field ? (int) gmdate( 'G', $ts ?: time() ) : (int) gmdate( 'w', $ts ?: time() ); }
		else { $actual = $row[ $field ] ?? ''; }
		if ( in_array( $field, array( 'risk_score', 'hour', 'day_of_week' ), true ) ) { $actual = (int) $actual; $expected = (int) $expected; }
		if ( 'blocked' === $field ) { $actual = ! empty( $actual ); $expected = (bool) $expected; }
		switch ( $operator ) {
			case '!=': return $actual != $expected;
			case '>=': return $actual >= $expected;
			case '<=': return $actual <= $expected;
			case 'in': return in_array( (string) $actual, array_map( 'strval', (array) $expected ), true );
			case 'not_in': return ! in_array( (string) $actual, array_map( 'strval', (array) $expected ), true );
			case 'contains': return false !== strpos( (string) $actual, (string) $expected );
			case 'starts_with': return 0 === strpos( (string) $actual, (string) $expected );
			default: return $actual == $expected;
		}
	}

	/** @return array<int,string> */
	private static function advice( array $rule, int $matched, int $required ): array {
		$advice = array(); $risk = null;
		foreach ( (array) ( $rule['conditions'] ?? array() ) as $condition ) { if ( 'risk_score' === (string) ( $condition['field'] ?? '' ) ) { $risk = (int) ( $condition['value'] ?? 0 ); } }
		if ( null !== $risk && $risk < 60 ) { $advice[] = '危険度の基準が低いため、通知が多くなる可能性があります。まず70以上での運用を検討してください。'; }
		if ( $required <= 1 ) { $advice[] = '1件で発動する設定です。誤検知を抑える場合は、2件以上または3件以上を検討してください。'; }
		if ( $matched > max( 20, $required * 10 ) ) { $advice[] = '現在のログで一致件数が多いため、危険度・イベント種別・件数条件を絞ることを推奨します。'; }
		if ( empty( $advice ) ) { $advice[] = '現在の条件は極端に広くありません。保存後も通知頻度を確認してください。'; }
		return $advice;
	}
}
