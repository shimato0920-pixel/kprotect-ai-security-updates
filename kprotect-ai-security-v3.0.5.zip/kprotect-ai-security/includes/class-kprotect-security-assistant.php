<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Builds an explainable site-level security report from local KProtect data.
 */
final class KProtect_Security_Assistant {
	private KProtect_Security_Auditor $auditor;

	public function __construct( KProtect_Security_Auditor $auditor ) {
		$this->auditor = $auditor;
	}

	/** @return array<string,mixed> */
	public function report(): array {
		$metrics                         = $this->collect_metrics();
		$checks                          = $this->auditor->audit();
		$metrics['audit_score']          = $this->auditor->score( $checks );
		$metrics['audit_checks']         = $checks;
		$metrics['integrity_changes']    = count( (array) get_option( 'kprotect_integrity_last_result', array() ) );
		$malware                         = (array) get_option( 'kprotect_malware_last_result', array() );
		$metrics['suspicious_uploads']   = count( (array) ( $malware['suspicious'] ?? array() ) );
		$metrics['uploads_php_files']    = count( (array) ( $malware['php_files'] ?? array() ) );
		$metrics['integrity_last_scan']  = (string) get_option( 'kprotect_integrity_last_scan', '' );
		$metrics['malware_last_scan']    = (string) get_option( 'kprotect_malware_last_scan', '' );
		$metrics['unread_notifications'] = $this->count_unread_notifications();

		return self::evaluate( $metrics );
	}

	/**
	 * Convert metrics into a deterministic, explainable report.
	 *
	 * @param array<string,mixed> $metrics Metrics from logs and local checks.
	 * @return array<string,mixed>
	 */
	public static function evaluate( array $metrics ): array {
		$today       = max( 0, (int) ( $metrics['today_events'] ?? 0 ) );
		$yesterday   = max( 0, (int) ( $metrics['yesterday_events'] ?? 0 ) );
		$max_risk    = max( 0, min( 100, (int) ( $metrics['today_max_risk'] ?? 0 ) ) );
		$audit_score = max( 0, min( 100, (int) ( $metrics['audit_score'] ?? 0 ) ) );
		$integrity   = max( 0, (int) ( $metrics['integrity_changes'] ?? 0 ) );
		$suspicious  = max( 0, (int) ( $metrics['suspicious_uploads'] ?? 0 ) );
		$php_uploads = max( 0, (int) ( $metrics['uploads_php_files'] ?? 0 ) );

		$attack_component = min( 45, (int) round( $max_risk * 0.30 ) + min( 15, (int) floor( $today / 20 ) ) );
		$config_component = (int) round( ( 100 - $audit_score ) * 0.25 );
		$file_component   = min( 30, ( $integrity * 10 ) + ( $suspicious * 12 ) + ( $php_uploads * 3 ) );
		$risk_score       = min( 100, $attack_component + $config_component + $file_component );
		$safety_score     = 100 - $risk_score;

		if ( $risk_score >= 70 ) {
			$level = 'high';
			$label = '高'; } elseif ( $risk_score >= 35 ) {
			$level = 'medium';
			$label = '中'; } else {
				$level = 'low';
				$label = '低'; }

			$change_percent = null;
			if ( $yesterday > 0 ) {
				$change_percent = (int) round( ( ( $today - $yesterday ) / $yesterday ) * 100 ); } elseif ( $today > 0 ) {
						$change_percent = 100; }

				$domains         = self::domain_scores( $metrics );
				$recommendations = self::recommendations( $metrics, $risk_score, $domains );
				$summary         = self::summary( $today, $yesterday, $risk_score, $integrity, $suspicious );

				return array(
					'safety_score'    => $safety_score,
					'risk_score'      => $risk_score,
					'risk_level'      => $level,
					'risk_label'      => $label,
					'summary'         => $summary,
					'change_percent'  => $change_percent,
					'recommendations' => array_slice( $recommendations, 0, 7 ),
					'domains'         => $domains,
					'trend'           => self::trend_summary( $metrics ),
					'metrics'         => $metrics,
					'components'      => array(
						'attack'        => $attack_component,
						'configuration' => $config_component,
						'files'         => $file_component,
					),
				);
	}

	/** @return array<string,array<string,mixed>> */
	private static function domain_scores( array $metrics ): array {
		$audit       = max( 0, min( 100, (int) ( $metrics['audit_score'] ?? 0 ) ) );
		$login       = max( 0, (int) ( $metrics['login_events'] ?? 0 ) );
		$max_risk    = max( 0, min( 100, (int) ( $metrics['today_max_risk'] ?? 0 ) ) );
		$integrity   = max( 0, (int) ( $metrics['integrity_changes'] ?? 0 ) );
		$suspicious  = max( 0, (int) ( $metrics['suspicious_uploads'] ?? 0 ) );
		$php_uploads = max( 0, (int) ( $metrics['uploads_php_files'] ?? 0 ) );
		$blocked     = max( 0, (int) ( $metrics['today_blocked'] ?? 0 ) );
		$events      = max( 0, (int) ( $metrics['today_events'] ?? 0 ) );
		$unread      = max( 0, (int) ( $metrics['unread_notifications'] ?? 0 ) );

		$identity   = max( 0, 100 - min( 55, $login * 3 ) - ( $login >= 10 ? 15 : 0 ) );
		$files      = max( 0, 100 - min( 70, $integrity * 25 + $suspicious * 30 + $php_uploads * 8 ) );
		$threat     = max( 0, 100 - min( 80, (int) round( $max_risk * 0.55 ) + min( 25, (int) floor( $events / 10 ) ) ) );
		$operations = max( 0, 100 - min( 45, $unread * 5 ) - ( self::scan_is_stale( (string) ( $metrics['integrity_last_scan'] ?? '' ) ) ? 20 : 0 ) - ( self::scan_is_stale( (string) ( $metrics['malware_last_scan'] ?? '' ) ) ? 20 : 0 ) );
		$network    = max( 0, 100 - min( 60, (int) round( $max_risk * 0.35 ) + max( 0, $events - $blocked ) ) );

		return array(
			'identity'      => self::domain( '認証・アカウント', $identity, 'ログイン攻撃とアカウント保護の状態' ),
			'configuration' => self::domain( 'WordPress設定', $audit, 'HTTPS、デバッグ、XML-RPC、ファイル編集など' ),
			'files'         => self::domain( 'ファイル整合性', $files, '改ざん差分とuploads内の要確認ファイル' ),
			'threat'        => self::domain( '脅威検知', $threat, '検知危険度、件数、遮断状況' ),
			'operations'    => self::domain( '運用・対応', $operations, '通知確認、定期スキャン、継続監視' ),
			'network'       => self::domain( 'アクセス防御', $network, '危険アクセスに対する遮断と残存リスク' ),
		);
	}

	/** @return array<string,mixed> */
	private static function domain( string $label, int $score, string $description ): array {
		$status = $score >= 85 ? 'good' : ( $score >= 65 ? 'watch' : 'danger' );
		return compact( 'label', 'score', 'status', 'description' );
	}

	/** @return array<int,array<string,mixed>> */
	private static function recommendations( array $metrics, int $risk_score, array $domains ): array {
		$items = array();
		if ( (int) ( $metrics['integrity_changes'] ?? 0 ) > 0 ) {
			$items[] = self::recommendation( 'critical', '重要ファイルの変更を確認', '改ざん検知で差分があります。正規更新か不審な変更かを確認し、未確認のまま基準を更新しないでください。', '不正変更を早期に切り分け、侵害の拡大を防ぎます。', '今すぐ', 'kprotect-integrity' );
		}
		if ( (int) ( $metrics['suspicious_uploads'] ?? 0 ) > 0 || (int) ( $metrics['uploads_php_files'] ?? 0 ) > 0 ) {
			$items[] = self::recommendation( 'critical', 'uploads内のPHPファイルを確認', 'uploadsスキャンでPHP系ファイルまたは要確認コードが見つかっています。削除前にバックアップを取得して内容を確認してください。', 'Webシェルなどの不正ファイルを見逃すリスクを下げます。', '今すぐ', 'kprotect-malware' );
		}
		foreach ( (array) ( $metrics['audit_checks'] ?? array() ) as $check ) {
			if ( ! empty( $check['passed'] ) ) {
				continue; }
			$items[] = self::recommendation( 'danger' === ( $check['severity'] ?? '' ) ? 'high' : 'medium', (string) ( $check['label'] ?? 'セキュリティ設定を確認' ), (string) ( $check['message'] ?? '設定を確認してください。' ), 'WordPressの基本設定に起因する攻撃面を減らします。', '24時間以内', 'kprotect-audit' );
		}
		if ( (int) ( $metrics['login_events'] ?? 0 ) >= 10 ) {
			$items[] = self::recommendation( 'high', 'ログイン防御を強化', '本日のログイン関連検知が多くなっています。二段階認証、強力なパスワード、不要な管理者アカウントの削除を確認してください。', '総当たり攻撃によるアカウント侵害の可能性を下げます。', '24時間以内', 'kprotect-logs' );
		}
		if ( (int) ( $metrics['today_max_risk'] ?? 0 ) >= 80 ) {
			$items[] = self::recommendation( 'high', '高危険度ログを確認', '本日、高危険度のアクセスを検知しています。遮断状況と検知理由をログで確認してください。', '実際の攻撃と誤検知を切り分け、必要な対応を早められます。', '24時間以内', 'kprotect-logs' );
		}
		if ( self::scan_is_stale( (string) ( $metrics['integrity_last_scan'] ?? '' ) ) ) {
			$items[] = self::recommendation( 'medium', '改ざん検知を実行', '改ざん検知の最終実行から時間が経過しているか、まだ未実行です。', '重要ファイルの変更を定期的に確認できます。', '7日以内', 'kprotect-integrity' );
		}
		if ( self::scan_is_stale( (string) ( $metrics['malware_last_scan'] ?? '' ) ) ) {
			$items[] = self::recommendation( 'medium', 'uploadsスキャンを実行', 'uploadsスキャンの最終実行から時間が経過しているか、まだ未実行です。', '不審なPHPファイルの見落としを減らします。', '7日以内', 'kprotect-malware' );
		}
		if ( empty( $items ) && $risk_score < 35 ) {
			$items[] = self::recommendation( 'low', '現在の設定を維持', '重大な異常は見つかっていません。WordPress・テーマ・プラグインの更新と定期バックアップを継続してください。', '現在の安全性を維持します。', '継続', 'kprotect-audit' );
		}
		usort( $items, static fn( $a, $b ) => (int) $b['priority'] <=> (int) $a['priority'] );
		return $items;
	}

	/** @return array<string,mixed> */
	private static function recommendation( string $severity, string $title, string $message, string $benefit, string $due, string $page ): array {
		$priority = array(
			'critical' => 5,
			'high'     => 4,
			'medium'   => 3,
			'low'      => 1,
		)[ $severity ] ?? 2;
		return compact( 'severity', 'priority', 'title', 'message', 'benefit', 'due', 'page' );
	}

	private static function summary( int $today, int $yesterday, int $risk_score, int $integrity, int $suspicious ): string {
		if ( $integrity > 0 || $suspicious > 0 ) {
			return 'ファイル関連の要確認項目があります。最優先で内容を確認してください。'; }
		if ( $risk_score >= 70 ) {
			return '高い危険度を示す検知または設定上の問題があります。推奨対策を上から順に確認してください。'; }
		if ( $risk_score >= 35 ) {
			return '直ちに侵害を示す状態ではありませんが、改善できる設定または増加傾向があります。'; }
		if ( $today > $yesterday && $today >= 10 ) {
			return '全体として安全ですが、昨日より検知件数が増えています。ログの傾向を確認してください。'; }
		return '現在、重大な異常は確認されていません。基本対策と定期確認を継続してください。';
	}

	/** @return array<string,mixed> */
	private static function trend_summary( array $metrics ): array {
		$daily    = array_values( (array) ( $metrics['daily_events'] ?? array() ) );
		$recent   = 0;
		$previous = 0;
		foreach ( $daily as $index => $row ) {
			if ( $index >= max( 0, count( $daily ) - 3 ) ) {
				$recent += (int) ( $row['total'] ?? 0 ); } else {
				$previous += (int) ( $row['total'] ?? 0 ); }
		}
		if ( $recent > $previous * 1.5 && $recent >= 10 ) {
			return array(
				'direction' => 'up',
				'label'     => '増加傾向',
				'message'   => '直近3日間の検知が、それ以前より増えています。',
			); }
		if ( $previous > 0 && $recent < $previous * 0.6 ) {
			return array(
				'direction' => 'down',
				'label'     => '減少傾向',
				'message'   => '直近の検知件数は減少しています。',
			); }
		return array(
			'direction' => 'stable',
			'label'     => '横ばい',
			'message'   => '大きな増減は確認されていません。',
		);
	}

	private static function scan_is_stale( string $value ): bool {
		if ( '' === trim( $value ) ) {
			return true; }
		$time = strtotime( $value . ' UTC' );
		return false === $time || $time < time() - 7 * DAY_IN_SECONDS;
	}

	private function count_unread_notifications(): int {
		global $wpdb;
		$table  = $wpdb->prefix . 'kprotect_notifications';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Security assistant needs the current KProtect notification state; queries are read-only and prepared.
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $exists !== $table ) {
			return 0; }
		$count = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $table, 'unread' ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $count;
	}

	/** @return array<string,mixed> */
	private function collect_metrics(): array {
		global $wpdb;
		$table            = $wpdb->prefix . 'kprotect_logs';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Security assistant metrics intentionally use current KProtect log data; all queries are prepared and bounded.
		$today_start      = gmdate( 'Y-m-d 00:00:00' );
		$yesterday_start  = gmdate( 'Y-m-d 00:00:00', time() - DAY_IN_SECONDS );
		$seven_days_start = gmdate( 'Y-m-d 00:00:00', time() - ( 6 * DAY_IN_SECONDS ) );
		$today            = $wpdb->get_row( $wpdb->prepare( 'SELECT COUNT(*) AS events, COALESCE(SUM(blocked),0) AS blocked, COALESCE(MAX(risk_score),0) AS max_risk, SUM(CASE WHEN event_type LIKE %s THEN 1 ELSE 0 END) AS login_events FROM %i WHERE created_at >= %s', 'login%', $table, $today_start ), ARRAY_A );
		$yesterday        = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE created_at >= %s AND created_at < %s', $table, $yesterday_start, $today_start ) );
		$types            = $wpdb->get_results( $wpdb->prepare( 'SELECT event_type, COUNT(*) AS total FROM %i WHERE created_at >= %s GROUP BY event_type ORDER BY total DESC LIMIT 5', $table, $today_start ), ARRAY_A );
		$daily            = $wpdb->get_results( $wpdb->prepare( 'SELECT DATE(created_at) AS day, COUNT(*) AS total, COALESCE(SUM(blocked),0) AS blocked FROM %i WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY day ASC', $table, $seven_days_start ), ARRAY_A );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return array(
			'today_events'     => (int) ( $today['events'] ?? 0 ),
			'today_blocked'    => (int) ( $today['blocked'] ?? 0 ),
			'today_max_risk'   => (int) ( $today['max_risk'] ?? 0 ),
			'login_events'     => (int) ( $today['login_events'] ?? 0 ),
			'yesterday_events' => $yesterday,
			'top_event_types'  => is_array( $types ) ? $types : array(),
			'daily_events'     => is_array( $daily ) ? $daily : array(),
		);
	}
}
