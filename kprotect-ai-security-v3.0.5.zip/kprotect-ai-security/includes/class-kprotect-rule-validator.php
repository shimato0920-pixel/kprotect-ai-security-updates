<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class KProtect_Rule_Validator {
	/** @return array{valid:bool,rule:array<string,mixed>,errors:array<int,string>} */
	public static function validate( array $rule ): array {
		$errors = array();
		$name = sanitize_text_field( (string) ( $rule['name'] ?? '' ) );
		if ( '' === $name ) { $errors[] = 'ルール名がありません。'; }
		$conditions = is_array( $rule['conditions'] ?? null ) ? $rule['conditions'] : array();
		if ( empty( $conditions ) ) { $errors[] = '条件がありません。'; }
		$clean_conditions = array();
		foreach ( $conditions as $condition ) {
			if ( ! is_array( $condition ) ) { continue; }
			$field = sanitize_key( (string) ( $condition['field'] ?? '' ) );
			$operator = sanitize_text_field( (string) ( $condition['operator'] ?? '' ) );
			$value = $condition['value'] ?? '';
			if ( ! in_array( $field, KProtect_Rule_Schema::fields(), true ) ) { $errors[] = '許可されていない条件項目です。'; continue; }
			if ( ! in_array( $operator, KProtect_Rule_Schema::operators(), true ) ) { $errors[] = '許可されていない演算子です。'; continue; }
			if ( in_array( $field, array( 'risk_score', 'count', 'hour', 'day_of_week' ), true ) ) { $value = (int) $value; }
			elseif ( 'blocked' === $field ) { $value = (bool) $value; }
			elseif ( is_array( $value ) ) { $value = array_values( array_filter( array_map( 'sanitize_text_field', $value ) ) ); }
			else { $value = sanitize_text_field( (string) $value ); }
			$clean_conditions[] = array( 'field' => $field, 'operator' => $operator, 'value' => $value );
		}
		$actions = is_array( $rule['actions'] ?? null ) ? $rule['actions'] : array();
		$clean_actions = array();
		foreach ( $actions as $action ) {
			if ( ! is_array( $action ) ) { continue; }
			$type = sanitize_key( (string) ( $action['type'] ?? '' ) );
			if ( ! in_array( $type, KProtect_Rule_Schema::actions(), true ) ) { $errors[] = '許可されていないアクションです。'; continue; }
			$item = array( 'type' => $type );
			if ( isset( $action['priority'] ) ) { $item['priority'] = sanitize_key( (string) $action['priority'] ); }
			$clean_actions[] = $item;
		}
		if ( empty( $clean_actions ) ) { $errors[] = '実行内容がありません。'; }
		$window_value = max( 1, min( 1440, (int) ( $rule['window']['value'] ?? 15 ) ) );
		$clean = array(
			'id' => sanitize_key( (string) ( $rule['id'] ?? wp_generate_uuid4() ) ),
			'name' => $name,
			'description' => sanitize_textarea_field( (string) ( $rule['description'] ?? '' ) ),
			'enabled' => false,
			'conditions' => $clean_conditions,
			'window' => array( 'value' => $window_value, 'unit' => 'minutes' ),
			'actions' => $clean_actions,
			'created_at' => sanitize_text_field( (string) ( $rule['created_at'] ?? current_time( 'mysql', true ) ) ),
		);
		return array( 'valid' => empty( $errors ), 'rule' => $clean, 'errors' => array_values( array_unique( $errors ) ) );
	}
}
