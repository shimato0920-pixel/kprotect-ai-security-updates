<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Sends a privacy-minimized JSON payload to a user supplied HTTPS endpoint.
 */
final class KProtect_Webhook_Notifier {
	private const LAST_SENT_OPTION = 'kprotect_last_webhook_notice';

	public function maybe_send( string $event_type, int $score, array $reasons ): void {
		$settings = KProtect_Utils::settings();
		if ( ! KProtect_Notification_Rules::webhook_allowed( $settings, $event_type, $score ) ) {
			return; }
		$key      = KProtect_Notification_Center::fingerprint( $event_type, $reasons );
		$last     = (array) get_option( self::LAST_SENT_OPTION, array() );
		$cooldown = max( 5, (int) ( $settings['webhook_cooldown_minutes'] ?? 60 ) ) * MINUTE_IN_SECONDS;
		if ( isset( $last[ $key ] ) && ( time() - (int) $last[ $key ] ) < $cooldown ) {
			return; }
		$result = $this->send( $event_type, $score, $reasons );
		if ( is_wp_error( $result ) ) {
			update_option(
				'kprotect_last_webhook_error',
				array(
					'message'     => sanitize_text_field( $result->get_error_message() ),
					'recorded_at' => current_time( 'mysql' ),
				),
				false
			);
			return;
		}
		$last[ $key ] = time();
		if ( count( $last ) > 200 ) {
			$last = array_slice( $last, -200, null, true ); }
		update_option( self::LAST_SENT_OPTION, $last, false );
		delete_option( 'kprotect_last_webhook_error' );
	}

	/** @return true|WP_Error */
	public function send( string $event_type, int $score, array $reasons, bool $is_test = false ) {
		$settings = KProtect_Utils::settings();
		$url      = self::sanitize_webhook_url( (string) ( $settings['webhook_url'] ?? '' ) );
		if ( '' === $url ) {
			return new WP_Error( 'kprotect_webhook_url', 'Webhook URLが未設定、無効、またはプライベートネットワークを指しています。' ); }
		$desc    = KProtect_Notification_Center::describe( $event_type, $score, $reasons );
		$payload = array(
			'schema_version' => 1,
			'source'         => 'kprotect-ai-security',
			'is_test'        => $is_test,
			'site_url'       => home_url( '/' ),
			'event_type'     => sanitize_key( $event_type ),
			'risk_score'     => max( 0, min( 100, $score ) ),
			'severity'       => sanitize_key( (string) ( $desc['severity'] ?? 'low' ) ),
			'title'          => $is_test ? 'KProtect Webhook 接続テスト' : sanitize_text_field( (string) ( $desc['title'] ?? 'セキュリティ通知' ) ),
			'message'        => $is_test ? 'Webhook通知の接続テストです。実際の攻撃ではありません。' : sanitize_textarea_field( (string) ( $desc['message'] ?? '' ) ),
			'occurred_at'    => wp_date( DATE_ATOM ),
			'admin_url'      => admin_url( 'admin.php?page=kprotect-notifications' ),
		);
		$headers = array(
			'Content-Type' => 'application/json; charset=utf-8',
			'User-Agent'   => 'KProtect-AI-Security/' . KPROTECT_VERSION,
		);
		$secret  = sanitize_text_field( (string) ( $settings['webhook_secret'] ?? '' ) );
		if ( '' !== $secret ) {
			$headers['X-KProtect-Signature'] = 'sha256=' . hash_hmac( 'sha256', wp_json_encode( $payload ), $secret ); }
		$args     = array(
			'timeout'             => 6,
			'redirection'         => 0,
			'reject_unsafe_urls'  => true,
			'limit_response_size' => 65536,
			'headers'             => $headers,
			'body'                => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			'data_format'         => 'body',
		);
		$started  = microtime( true );
		$attempts = 1;
		$response = wp_safe_remote_post( $url, $args );
		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 500 ) {
			$attempts = 2;
			$response = wp_safe_remote_post( $url, $args ); }
		$duration = (int) round( ( microtime( true ) - $started ) * 1000 );
		$history  = new KProtect_Delivery_History();
		if ( is_wp_error( $response ) ) {
			$history->record( 'webhook', $event_type, $score, $reasons, false, 0, $duration, $response->get_error_message(), $is_test, $attempts );
			return $response; }
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			$error = new WP_Error( 'kprotect_webhook_http', 'WebhookがHTTP ' . $code . 'を返しました。受信側の設定を確認してください。' );
			$history->record( 'webhook', $event_type, $score, $reasons, false, $code, $duration, $error->get_error_message(), $is_test, $attempts );
			return $error; }
		$history->record( 'webhook', $event_type, $score, $reasons, true, $code, $duration, '', $is_test, $attempts );
		return true;
	}

	public static function sanitize_webhook_url( string $url ): string {
		$url = esc_url_raw( trim( $url ), array( 'https' ) );
		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			return ''; }
		$parts = wp_parse_url( $url );
		$host  = strtolower( rtrim( (string) ( $parts['host'] ?? '' ), '.' ) );
		if ( '' === $host || 'localhost' === $host || str_ends_with( $host, '.local' ) || str_ends_with( $host, '.internal' ) ) {
			return ''; }
		if ( filter_var( $host, FILTER_VALIDATE_IP ) && ! filter_var( $host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return ''; }
		$ips = gethostbynamel( $host );
		if ( false === $ips || array() === $ips ) {
			return ''; }
		foreach ( $ips as $ip ) {
			if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
				return ''; }
		}
		return $url;
	}
}
