<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Sends selected security events to a Discord incoming webhook.
 *
 * Raw IP addresses, request paths, and submitted form data are never included.
 */
final class KProtect_Discord_Notifier {
	private const LAST_SENT_OPTION = 'kprotect_last_discord_notice';

	/**
	 * Send an event when the saved Discord rules allow it.
	 */
	public function maybe_send( string $event_type, int $score, array $reasons ): void {
		$settings = KProtect_Utils::settings();
		if ( ! KProtect_Notification_Rules::discord_allowed( $settings, $event_type, $score ) ) {
			return;
		}

		$key      = KProtect_Notification_Center::fingerprint( $event_type, $reasons );
		$last     = (array) get_option( self::LAST_SENT_OPTION, array() );
		$cooldown = max( 5, (int) ( $settings['discord_cooldown_minutes'] ?? 60 ) ) * MINUTE_IN_SECONDS;
		if ( isset( $last[ $key ] ) && ( time() - (int) $last[ $key ] ) < $cooldown ) {
			return;
		}

		$result = $this->send( $event_type, $score, $reasons );
		if ( is_wp_error( $result ) ) {
			update_option(
				'kprotect_last_discord_error',
				array(
					'message'     => sanitize_text_field( $result->get_error_message() ),
					'recorded_at' => current_time( 'mysql' ),
				),
				false
			);
			return;
		}

		$last[ $key ] = time();
		if ( count( $last ) > 200 ) {
			$last = array_slice( $last, -200, null, true );
		}
		update_option( self::LAST_SENT_OPTION, $last, false );
		delete_option( 'kprotect_last_discord_error' );
	}

	/**
	 * Send one Discord message. Returns true or a WP_Error.
	 *
	 * @return true|WP_Error
	 */
	public function send( string $event_type, int $score, array $reasons, bool $is_test = false ) {
		$settings = KProtect_Utils::settings();
		$url      = self::sanitize_webhook_url( (string) ( $settings['discord_webhook_url'] ?? '' ) );
		if ( '' === $url ) {
			return new WP_Error( 'kprotect_discord_url', 'Discord Webhook URLが未設定または無効です。' );
		}

		$desc     = KProtect_Notification_Center::describe( $event_type, $score, $reasons );
		$severity = strtoupper( (string) ( $desc['severity'] ?? 'low' ) );
		$title    = $is_test ? 'KProtect Discord 接続テスト' : (string) ( $desc['title'] ?? 'セキュリティ通知' );
		$message  = $is_test ? 'Discord通知の接続テストです。実際の攻撃ではありません。' : (string) ( $desc['message'] ?? '' );

		$payload = array(
			'username'         => 'KProtect AI Security',
			'allowed_mentions' => array( 'parse' => array() ),
			'embeds'           => array(
				array(
					'title'       => $title,
					'description' => $message,
					'fields'      => array(
						array(
							'name'   => 'サイト',
							'value'  => home_url( '/' ),
							'inline' => false,
						),
						array(
							'name'   => '危険度',
							'value'  => max( 0, min( 100, $score ) ) . ' / ' . $severity,
							'inline' => true,
						),
						array(
							'name'   => '検知種類',
							'value'  => sanitize_key( $event_type ),
							'inline' => true,
						),
						array(
							'name'   => '時刻',
							'value'  => wp_date( 'Y-m-d H:i:s T' ),
							'inline' => false,
						),
						array(
							'name'   => '管理画面',
							'value'  => admin_url( 'admin.php?page=kprotect-notifications' ),
							'inline' => false,
						),
					),
					'footer'      => array( 'text' => 'IP・リクエスト本文・フォーム内容は送信していません。' ),
				),
			),
		);

		$args = array(
			'timeout'     => 6,
			'redirection' => 0,
			'headers'     => array( 'Content-Type' => 'application/json; charset=utf-8' ),
			'body'        => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			'data_format' => 'body',
		);

		$started  = microtime( true );
		$attempts = 1;
		$response = wp_remote_post( $url, $args );
		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 500 ) {
			$attempts = 2;
			$response = wp_remote_post( $url, $args );
		}
		$duration = (int) round( ( microtime( true ) - $started ) * 1000 );
		$history  = new KProtect_Delivery_History();
		if ( is_wp_error( $response ) ) {
			$history->record( 'discord', $event_type, $score, $reasons, false, 0, $duration, $response->get_error_message(), $is_test, $attempts );
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			$error = new WP_Error( 'kprotect_discord_http', 'DiscordがHTTP ' . $code . 'を返しました。Webhook URLとDiscord側の設定を確認してください。' );
			$history->record( 'discord', $event_type, $score, $reasons, false, $code, $duration, $error->get_error_message(), $is_test, $attempts );
			return $error;
		}
		$history->record( 'discord', $event_type, $score, $reasons, true, $code, $duration, '', $is_test, $attempts );
		return true;
	}

	/**
	 * Allow only Discord incoming webhook endpoints.
	 */
	public static function sanitize_webhook_url( string $url ): string {
		$url = esc_url_raw( trim( $url ), array( 'https' ) );
		if ( '' === $url ) {
			return ''; }
		$parts         = wp_parse_url( $url );
		$host          = strtolower( (string) ( $parts['host'] ?? '' ) );
		$path          = (string) ( $parts['path'] ?? '' );
		$allowed_hosts = array( 'discord.com', 'www.discord.com', 'discordapp.com', 'www.discordapp.com', 'canary.discord.com', 'ptb.discord.com' );
		if ( ! in_array( $host, $allowed_hosts, true ) || ! preg_match( '#^/api/webhooks/[0-9]+/[A-Za-z0-9._-]+$#', $path ) ) {
			return '';
		}
		return $url;
	}
}
