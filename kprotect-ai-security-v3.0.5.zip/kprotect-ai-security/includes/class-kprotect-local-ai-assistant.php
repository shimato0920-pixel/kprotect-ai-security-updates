<?php
/**
 * Local AI assistant for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Answers administrator questions from local, normalized dashboard data.
 *
 * This class does not call external AI services and does not expose raw request
 * bodies, passwords, file contents, or query strings.
 */
final class KProtect_Local_AI_Assistant {
	/**
	 * Build a local answer for an administrator question.
	 *
	 * @param string              $question     Administrator question.
	 * @param array<string,mixed> $intelligence AI engine output.
	 * @return array<string,mixed>
	 */
	public static function answer( string $question, array $intelligence ): array {
		$question = self::normalize_question( $question );
		$report   = (array) ( $intelligence['incident_report'] ?? array() );
		$queue    = (array) ( $intelligence['incident_queue'] ?? array() );
		$plan     = (array) ( $intelligence['response_plan'] ?? array() );
		$topic    = self::detect_topic( $question );

		$answer = array(
			'question'   => $question,
			'topic'      => $topic,
			'headline'   => (string) ( $intelligence['title'] ?? '現在の状態を確認しました' ),
			'facts'      => self::base_facts( $intelligence, $report ),
			'assessment' => (string) ( $intelligence['assessment'] ?? $intelligence['summary'] ?? '' ),
			'actions'    => array_slice( (array) ( $plan['steps'] ?? $intelligence['actions'] ?? array() ), 0, 3 ),
			'caution'    => 'この回答はローカルログから作成した判断支援です。単一の回答だけで侵害の有無を断定しないでください。',
			'confidence'       => (string) ( $intelligence['confidence'] ?? '限定的' ),
			'confidence_score' => self::confidence_score( (string) ( $intelligence['confidence'] ?? '限定的' ), $report, $queue ),
		);

		if ( 'priority' === $topic ) {
			$answer['headline']   = '最優先の確認対象は「' . (string) ( $plan['target'] ?? '高危険度イベント' ) . '」です';
			$answer['assessment'] = '優先度' . (string) ( $plan['priority'] ?? 'D' ) . '、対応目安は' . (string) ( $plan['urgency'] ?? '定期点検時' ) . 'です。';
			$answer['facts']      = array_slice( (array) ( $plan['reasons'] ?? array() ), 0, 4 );
		} elseif ( 'report' === $topic ) {
			$answer['headline']   = '直近24時間のインシデント概要です';
			$answer['assessment'] = (string) ( $report['summary'] ?? '比較できる十分なログがありません。' );
			$answer['facts']      = array(
				'検知 ' . (int) ( $report['total'] ?? 0 ) . '件',
				'遮断 ' . (int) ( $report['blocked'] ?? 0 ) . '件',
				'未遮断 ' . (int) ( $report['unblocked'] ?? 0 ) . '件',
				'最大危険度 ' . (int) ( $report['max_risk'] ?? 0 ),
			);
		} elseif ( 'file' === $topic ) {
			$answer = self::topic_answer( $answer, $queue, array( 'integrity', 'file_integrity', 'malware_scan' ), 'ファイル変更・改ざん検知を確認しました', array(
				'直前の更新・インストール操作と検知時刻を照合する',
				'正規更新なら変更内容を確認して整合性基準を更新する',
				'心当たりがなければバックアップと正規配布物を比較する',
			) );
		} elseif ( 'login' === $topic ) {
			$answer = self::topic_answer( $answer, $queue, array( 'login_failed', 'login_blocked' ), 'ログイン関連の検知を確認しました', array(
				'対象ユーザーと攻撃元の履歴を確認する',
				'管理者アカウントへ二要素認証を設定する',
				'不要な管理者・休眠ユーザーを無効化する',
			) );
		} elseif ( 'firewall' === $topic ) {
			$answer = self::topic_answer( $answer, $queue, array( 'firewall', 'rate_limit', 'xmlrpc' ), 'ファイアウォール関連の検知を確認しました', array(
				'対象パスと攻撃手法を確認する',
				'未遮断イベントがあればルールと例外設定を見直す',
				'WordPress・テーマ・プラグインを更新する',
			) );
		} elseif ( 'false_positive' === $topic ) {
			$likelihood = (string) ( $intelligence['likelihood'] ?? '追加確認が必要' );
			$answer['headline']   = '誤検知かどうかは、現時点では断定できません';
			$answer['assessment'] = $likelihood . '。予定した更新・管理操作、時刻、対象ファイルまたは対象パスが一致するか確認してください。';
			$answer['actions']    = array(
				'予定した管理操作と検知時刻を照合する',
				'同じ種類の高危険度イベントが増えていないか確認する',
				'安全と確認できるまで基準更新や例外追加を急がない',
			);
		}

		$answer['facts']   = array_values( array_filter( array_unique( array_map( 'strval', (array) $answer['facts'] ) ) ) );
		$answer['actions'] = array_values( array_filter( array_unique( array_map( 'strval', (array) $answer['actions'] ) ) ) );
		return $answer;
	}


	/**
	 * Convert confidence wording into a transparent percentage.
	 *
	 * The percentage is an explanation aid based on available local evidence,
	 * not a probability that the site is safe or compromised.
	 *
	 * @param string                         $confidence Confidence wording.
	 * @param array<string,mixed>            $report     Incident report.
	 * @param array<int,array<string,mixed>> $queue      Incident queue.
	 * @return int
	 */
	private static function confidence_score( string $confidence, array $report, array $queue ): int {
		$score = array(
			'高い'   => 90,
			'中程度' => 70,
			'限定的' => 40,
		)[ $confidence ] ?? 50;

		$total = (int) ( $report['total'] ?? 0 );
		if ( $total >= 20 ) {
			$score += 5;
		} elseif ( 0 === $total ) {
			$score -= 10;
		}

		if ( ! empty( $queue ) ) {
			$score += 3;
		}

		return max( 20, min( 95, $score ) );
	}

	/**
	 * Normalize a question without depending on WordPress functions.
	 *
	 * @param string $question Raw question.
	 * @return string
	 */
	private static function normalize_question( string $question ): string {
		$question = trim( preg_replace( '/\s+/u', ' ', $question ) ?? '' );
		$question = trim( preg_replace( '/<[^>]*>/', '', $question ) ?? '' );
		if ( '' === $question ) {
			return '現在の状態を教えて';
		}
		return function_exists( 'mb_substr' ) ? mb_substr( $question, 0, 300 ) : substr( $question, 0, 900 );
	}

	/**
	 * Detect the requested topic.
	 *
	 * @param string $question Normalized question.
	 * @return string
	 */
	private static function detect_topic( string $question ): string {
		$catalog = array(
			'false_positive' => array( '誤検知', '正常', '安全', '問題ない' ),
			'priority'       => array( '最優先', '優先', '今すぐ', '何をすれば', '対応すべき' ),
			'report'         => array( '24時間', '今日', 'レポート', 'まとめ', '状況' ),
			'file'           => array( 'ファイル', '改ざん', '更新', 'プラグイン変更', 'マルウェア' ),
			'login'          => array( 'ログイン', 'パスワード', 'ブルートフォース', 'アカウント' ),
			'firewall'       => array( 'ファイアウォール', 'SQL', 'XSS', 'XML-RPC', '大量アクセス', '遮断' ),
		);
		foreach ( $catalog as $topic => $keywords ) {
			foreach ( $keywords as $keyword ) {
				if ( self::contains( $question, $keyword ) ) {
					return $topic;
				}
			}
		}
		return 'overview';
	}

	/**
	 * Check whether a question contains a keyword.
	 *
	 * @param string $question Question text.
	 * @param string $keyword  Keyword.
	 * @return bool
	 */
	private static function contains( string $question, string $keyword ): bool {
		if ( function_exists( 'mb_stripos' ) ) {
			return false !== mb_stripos( $question, $keyword );
		}
		return false !== strpos( $question, $keyword );
	}

	/**
	 * Build common factual statements.
	 *
	 * @param array<string,mixed> $intelligence AI engine output.
	 * @param array<string,mixed> $report       Incident report.
	 * @return array<int,string>
	 */
	private static function base_facts( array $intelligence, array $report ): array {
		return array(
			'安全度 ' . (int) ( $intelligence['score'] ?? 100 ) . '/100',
			'検知 ' . (int) ( $report['total'] ?? 0 ) . '件',
			'未遮断 ' . (int) ( $report['unblocked'] ?? 0 ) . '件',
			'最大危険度 ' . (int) ( $report['max_risk'] ?? 0 ),
		);
	}

	/**
	 * Build a topic-specific answer from incident queue entries.
	 *
	 * @param array<string,mixed>              $answer  Base answer.
	 * @param array<int,array<string,mixed>>   $queue   Incident queue.
	 * @param array<int,string>                $types   Matching event types.
	 * @param string                           $title   Headline.
	 * @param array<int,string>                $actions Recommended actions.
	 * @return array<string,mixed>
	 */
	private static function topic_answer( array $answer, array $queue, array $types, string $title, array $actions ): array {
		$matches = array_values(
			array_filter(
				$queue,
				static fn( array $item ): bool => in_array( (string) ( $item['type'] ?? '' ), $types, true )
			)
		);
		$answer['headline'] = $title;
		$answer['actions']  = $actions;
		if ( empty( $matches ) ) {
			$answer['assessment'] = '直近の優先キューには該当するイベントがありません。ログがないことは安全の保証ではないため、定期監視を継続してください。';
			$answer['facts']      = array( '該当する優先イベント 0件' );
			return $answer;
		}
		$first = $matches[0];
		$answer['assessment'] = (string) ( $first['reason'] ?? '関連イベントが記録されています。' );
		$answer['facts']      = array(
			'優先度 ' . (string) ( $first['priority'] ?? 'D' ),
			'検知 ' . (int) ( $first['count'] ?? 0 ) . '件',
			'未遮断 ' . (int) ( $first['unblocked_count'] ?? 0 ) . '件',
			'最大危険度 ' . (int) ( $first['max_risk'] ?? 0 ),
		);
		return $answer;
	}
}
