<?php
/**
 * Local AI provider for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adapts the deterministic local assistant to the provider contract.
 */
final class KProtect_Local_AI_Provider implements KProtect_AI_Provider_Interface {
	/**
	 * Return the provider identifier.
	 *
	 * @return string
	 */
	public function get_id(): string {
		return 'local';
	}

	/**
	 * Return the provider label.
	 *
	 * @return string
	 */
	public function get_label(): string {
		return 'Local Rule Engine';
	}

	/**
	 * The local provider is always available after plugin bootstrap.
	 *
	 * @return bool
	 */
	public function is_available(): bool {
		return class_exists( 'KProtect_Local_AI_Assistant' );
	}

	/**
	 * Return supported provider capabilities.
	 *
	 * @return array<string,bool>
	 */
	public function get_capabilities(): array {
		return array(
			'external_network' => false,
			'local_only'       => true,
			'explainable'      => true,
			'structured_output' => true,
		);
	}

	/**
	 * Answer using the existing deterministic local assistant.
	 *
	 * @param string              $question     Administrator question.
	 * @param array<string,mixed> $intelligence Normalized local intelligence.
	 * @return array<string,mixed>
	 */
	public function answer( string $question, array $intelligence ): array {
		if ( ! $this->is_available() ) {
			return array(
				'provider'   => $this->get_id(),
				'headline'   => 'ローカルAIを利用できません',
				'facts'      => array(),
				'assessment' => '必要なローカル分析クラスが読み込まれていません。',
				'actions'    => array( 'プラグインファイルが完全に配置されているか確認する' ),
				'caution'    => '設定変更や自動遮断は実行されていません。',
			);
		}

		$answer             = KProtect_Local_AI_Assistant::answer( $question, $intelligence );
		$answer['provider'] = $this->get_id();
		$answer['provider_label'] = $this->get_label();
		return $answer;
	}
}
