<?php
/**
 * Login protection for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Protects the WordPress login process.
 */
final class KProtect_Login_Guard {

	/**
	 * Security event logger.
	 *
	 * @var KProtect_Logger
	 */
	private KProtect_Logger $logger;

	/**
	 * IP address blocker.
	 *
	 * @var KProtect_IP_Blocker
	 */
	private KProtect_IP_Blocker $blocker;

	/**
	 * Constructor.
	 *
	 * @param KProtect_Logger     $logger  Security event logger.
	 * @param KProtect_IP_Blocker $blocker IP address blocker.
	 */
	public function __construct( KProtect_Logger $logger, KProtect_IP_Blocker $blocker ) {
		$this->logger  = $logger;
		$this->blocker = $blocker;
	}

	/**
	 * Check whether a login request should be allowed.
	 *
	 * @param mixed  $user     Current authentication result.
	 * @param string $username Submitted username.
	 * @param string $password Submitted password.
	 * @return mixed
	 */
	public function check( $user, string $username, string $password ) {
		$ip = KProtect_Utils::client_ip();

		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) ) {
			return $user;
		}

		if ( ! KProtect_Utils::is_trusted( $ip ) && $this->blocker->is_blocked( $ip ) ) {
			return new WP_Error(
				'kprotect_blocked',
				__(
					'セキュリティ保護により、一時的にログインできません。',
					'kprotect-ai-security'
				)
			);
		}

		return $user;
	}

	/**
	 * Record a failed login attempt.
	 *
	 * @param string $username Submitted username.
	 * @return void
	 */
	public function failed( string $username ): void {
		$settings = KProtect_Utils::settings();
		$ip       = KProtect_Utils::client_ip();

		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) || KProtect_Utils::is_trusted( $ip ) ) {
			return;
		}

		$key   = 'kprotect_login_' . substr( KProtect_Utils::ip_hash( $ip ), 0, 32 );
		$count = (int) get_transient( $key ) + 1;

		set_transient(
			$key,
			$count,
			max( 5, (int) $settings['login_block_minutes'] ) * MINUTE_IN_SECONDS
		);

		$this->logger->log(
			'login_failed',
			min( 95, 20 + $count * 12 ),
			array( 'failed_login', 'attempt_' . $count ),
			false,
			$ip
		);

		if ( $count >= max( 2, (int) $settings['login_failures'] ) ) {
			$this->blocker->block(
				$ip,
				'login_bruteforce',
				(int) $settings['login_block_minutes']
			);

			$this->logger->log(
				'login_blocked',
				95,
				array( 'login_bruteforce' ),
				true,
				$ip
			);
		}
	}

	/**
	 * Clear the failed-login counter after a successful login.
	 *
	 * @param string  $user_login Authenticated username.
	 * @param WP_User $user       Authenticated WordPress user.
	 * @return void
	 */
	public function success( string $user_login, WP_User $user ): void {
		$ip = KProtect_Utils::client_ip();

		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) ) {
			return;
		}

		delete_transient(
			'kprotect_login_' . substr( KProtect_Utils::ip_hash( $ip ), 0, 32 )
		);
	}
}
