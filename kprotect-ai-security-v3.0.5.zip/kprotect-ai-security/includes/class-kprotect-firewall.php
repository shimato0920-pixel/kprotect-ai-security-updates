<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Firewall {
	private KProtect_Logger $logger;
	private KProtect_IP_Blocker $blocker;
	private KProtect_Detector $detector;
	private KProtect_Rate_Limiter $rate;

	public function __construct( KProtect_Logger $logger, KProtect_IP_Blocker $blocker ) {
		$this->logger   = $logger;
		$this->blocker  = $blocker;
		$this->detector = new KProtect_Detector();
		$this->rate     = new KProtect_Rate_Limiter();
	}

	public function inspect(): void {
		$settings = KProtect_Utils::settings();
		if ( empty( $settings['enabled'] ) || ( defined( 'WP_CLI' ) && WP_CLI ) || wp_doing_cron() ) {
			return; }

		$ip = KProtect_Utils::client_ip();
		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) ) {
			return; }
		if ( KProtect_Utils::is_trusted( $ip ) ) {
			return; }

		$is_administrator = current_user_can( 'manage_options' );

		if ( ! $is_administrator && $this->blocker->is_blocked( $ip ) ) {
			$this->logger->log( 'blocked_ip', 100, array( 'active_block' ), true, $ip );
			$this->blocker->deny();
		}
		if ( ! $is_administrator && $this->rate->hit( $ip ) ) {
			$this->blocker->block( $ip, 'rate_limit', (int) $settings['block_minutes'] );
			$this->logger->log( 'rate_limit', 90, array( 'too_many_requests' ), true, $ip );
			$this->blocker->deny( 429 );
		}

		$result = $this->detector->inspect();
		if ( ! empty( $result['bot'] ) && 'browser' !== $result['bot'] ) {
			$result['reasons'][] = 'client:' . sanitize_key( $result['bot'] );
		}
		if ( $is_administrator && $result['score'] >= (int) $settings['log_threshold'] ) {
			$result['reasons'][] = 'administrator_session';
			$this->logger->log( 'firewall', $result['score'], $result['reasons'], false, $ip );
			return;
		}

		if ( $result['score'] >= (int) $settings['block_threshold'] ) {
			$this->blocker->block( $ip, implode( ',', $result['reasons'] ), (int) $settings['block_minutes'] );
			$this->logger->log( 'firewall', $result['score'], $result['reasons'], true, $ip );
			$this->blocker->deny();
		}
		if ( $result['score'] >= (int) $settings['log_threshold'] ) {
			$this->logger->log( 'firewall', $result['score'], $result['reasons'], false, $ip );
		}
	}

	public function disable_xmlrpc( bool $enabled ): bool {
		return ! empty( KProtect_Utils::settings()['disable_xmlrpc'] ) ? false : $enabled;
	}
}
