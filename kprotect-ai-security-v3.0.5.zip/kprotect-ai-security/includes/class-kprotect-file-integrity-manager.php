<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_File_Integrity_Manager {
	private const BASELINE_OPTION = 'kprotect_full_integrity_baseline';
	private const RESULT_OPTION   = 'kprotect_full_integrity_last_result';
	private const MAX_FILES       = 12000;

	private KProtect_Logger $logger;

	public function __construct( KProtect_Logger $logger ) {
		$this->logger = $logger; }

	public function create_baseline(): array {
		$inventory = $this->inventory();
		update_option(
			self::BASELINE_OPTION,
			array(
				'created_at' => current_time( 'mysql', true ),
				'files'      => $inventory,
			),
			false
		);
		return $inventory;
	}

	public function has_baseline(): bool {
		$baseline = get_option( self::BASELINE_OPTION, null );
		return is_array( $baseline ) && isset( $baseline['files'] ) && is_array( $baseline['files'] );
	}

	public function scan(): array {
		$started = microtime( true );
		$memory  = memory_get_usage( true );
		$current = $this->inventory();
		$base    = get_option( self::BASELINE_OPTION, array() );
		$files   = isset( $base['files'] ) && is_array( $base['files'] ) ? $base['files'] : array();
		$changes = array();

		if ( empty( $files ) && ! $this->has_baseline() ) {
			return array(
				'status'      => 'no_baseline',
				'changes'     => array(),
				'summary'     => $this->summary( $current ),
				'duration_ms' => 0,
			);
		}

		foreach ( $current as $path => $data ) {
			if ( ! isset( $files[ $path ] ) ) {
				$changes[] = array(
					'file'     => $path,
					'category' => $data['category'],
					'type'     => 'added',
				);
			} elseif ( ! hash_equals( (string) $files[ $path ]['hash'], (string) $data['hash'] ) ) {
				$changes[] = array(
					'file'     => $path,
					'category' => $data['category'],
					'type'     => 'modified',
				);
			}
		}
		foreach ( $files as $path => $data ) {
			if ( ! isset( $current[ $path ] ) ) {
				$changes[] = array(
					'file'     => $path,
					'category' => $data['category'] ?? 'unknown',
					'type'     => 'missing',
				);
			}
		}

		$official = $this->core_checksum_changes();
		foreach ( $official as $change ) {
			$changes[] = $change; }
		$changes = array_values( array_unique( $changes, SORT_REGULAR ) );
		$result  = array(
			'status'             => empty( $changes ) ? 'clean' : 'changed',
			'changes'            => $changes,
			'summary'            => $this->summary( $current ),
			'duration_ms'        => round( ( microtime( true ) - $started ) * 1000, 2 ),
			'memory_delta_bytes' => max( 0, memory_get_usage( true ) - $memory ),
			'scanned_at'         => current_time( 'mysql', true ),
		);
		update_option( self::RESULT_OPTION, $result, false );
		foreach ( $changes as $change ) {
			$risk = 'core' === $change['category'] ? 90 : 82;
			$this->logger->log( 'file_integrity', $risk, array( $change['category'], $change['type'], $change['file'] ), false, KProtect_Utils::client_ip() );
		}
		return $result;
	}

	public function last_result(): array {
		return (array) get_option( self::RESULT_OPTION, array() ); }
	public function baseline_created_at(): string {
		$base = get_option( self::BASELINE_OPTION, array() );
		return is_array( $base ) ? (string) ( $base['created_at'] ?? '' ) : '';
	}

	private function inventory(): array {
		$roots = array(
			'core'    => ABSPATH,
			'plugins' => WP_PLUGIN_DIR,
			'themes'  => get_theme_root(),
			'uploads' => wp_get_upload_dir()['basedir'] ?? '',
		);
		$out   = array();
		$count = 0;
		foreach ( $roots as $category => $root ) {
			if ( ! is_string( $root ) || '' === $root || ! is_dir( $root ) ) {
				continue; }
			$iterator = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, FilesystemIterator::SKIP_DOTS ) );
			foreach ( $iterator as $file ) {
				if ( $count >= self::MAX_FILES ) {
					break 2; }
				if ( ! $file->isFile() || $file->isLink() ) {
					continue; }
				$path = wp_normalize_path( $file->getPathname() );
				if ( $this->should_skip( $path, $category ) ) {
					continue; }
				$relative = $this->relative( $path );
				$hash     = @hash_file( 'sha256', $path );
				if ( false === $hash ) {
					continue; }
				$out[ $relative ] = array(
					'hash'     => $hash,
					'size'     => (int) $file->getSize(),
					'mtime'    => (int) $file->getMTime(),
					'category' => $category,
				);
				++$count;
			}
		}
		ksort( $out );
		return $out;
	}

	private function should_skip( string $path, string $category ): bool {
		$normalized = strtolower( $path );
		if ( str_contains( $normalized, '/.git/' ) || str_contains( $normalized, '/node_modules/' ) || str_contains( $normalized, '/cache/' ) ) {
			return true; }
		if ( 'core' === $category && ( str_starts_with( $path, wp_normalize_path( WP_CONTENT_DIR ) . '/' ) ) ) {
			return true; }
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		return in_array( $ext, array( 'log', 'tmp', 'cache', 'zip', 'gz', 'tar', 'mp4', 'mov', 'avi' ), true );
	}

	private function relative( string $path ): string {
		$root = trailingslashit( wp_normalize_path( ABSPATH ) );
		return str_starts_with( $path, $root ) ? substr( $path, strlen( $root ) ) : $path;
	}

	private function summary( array $inventory ): array {
		$summary = array(
			'core'    => 0,
			'plugins' => 0,
			'themes'  => 0,
			'uploads' => 0,
		);
		foreach ( $inventory as $data ) {
			$category = $data['category'] ?? '';
			if ( isset( $summary[ $category ] ) ) {
				++$summary[ $category ]; }
		}
		return $summary;
	}

	private function core_checksum_changes(): array {
		if ( ! function_exists( 'get_core_checksums' ) ) {
			require_once ABSPATH . 'wp-admin/includes/update.php'; }
		if ( ! function_exists( 'get_core_checksums' ) ) {
			return array(); }
		$checksums = get_core_checksums( get_bloginfo( 'version' ), get_locale() );
		if ( ! is_array( $checksums ) || empty( $checksums ) ) {
			return array(); }
		$changes = array();
		foreach ( $checksums as $relative => $expected ) {
			$relative = ltrim( wp_normalize_path( (string) $relative ), '/' );
			// wp-content is maintained independently (plugins, themes, and language packs)
			// and must not be treated as immutable WordPress core.
			if ( 'wp-content' === $relative || str_starts_with( $relative, 'wp-content/' ) ) {
				continue; }
			$file = ABSPATH . $relative;
			if ( ! is_file( $file ) ) {
				$changes[] = array(
					'file'     => (string) $relative,
					'category' => 'core',
					'type'     => 'official_missing',
				);
				continue; }
			$actual = @md5_file( $file );
			if ( false !== $actual && ! hash_equals( strtolower( (string) $expected ), strtolower( $actual ) ) ) {
				$changes[] = array(
					'file'     => (string) $relative,
					'category' => 'core',
					'type'     => 'official_modified',
				); }
		}
		return $changes;
	}
}
