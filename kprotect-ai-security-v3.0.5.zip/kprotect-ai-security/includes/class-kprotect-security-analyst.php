<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Produces a privacy-conscious local security analyst summary.
 */
final class KProtect_Security_Analyst {
	/** @return array<string,mixed> */
	private const CACHE_KEY = 'kprotect_security_analyst_v3';
	private const CACHE_TTL = 60;

	public static function analyze(): array {
		$cached = get_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- The complete analyst result is transient-cached for 60 seconds above; these prepared reads refresh that cache from KProtect-owned logs.

		$table = $wpdb->prefix . 'kprotect_logs';
		$now   = time();
		$day   = gmdate( 'Y-m-d H:i:s', $now - DAY_IN_SECONDS );
		$two_days = gmdate( 'Y-m-d H:i:s', $now - ( 2 * DAY_IN_SECONDS ) );
		$week  = gmdate( 'Y-m-d H:i:s', $now - ( 7 * DAY_IN_SECONDS ) );
		$month = gmdate( 'Y-m-d H:i:s', $now - ( 30 * DAY_IN_SECONDS ) );

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT
				SUM(CASE WHEN created_at >= %s THEN 1 ELSE 0 END) AS total_24h,
				SUM(CASE WHEN created_at >= %s AND created_at < %s THEN 1 ELSE 0 END) AS previous_24h,
				SUM(CASE WHEN created_at >= %s AND risk_score >= 90 THEN 1 ELSE 0 END) AS critical_24h,
				SUM(CASE WHEN created_at >= %s AND blocked = 0 THEN 1 ELSE 0 END) AS unblocked_24h,
				SUM(CASE WHEN created_at >= %s AND event_type LIKE %s THEN 1 ELSE 0 END) AS login_24h,
				MAX(CASE WHEN created_at >= %s THEN risk_score ELSE 0 END) AS max_risk_24h,
				SUM(CASE WHEN created_at >= %s THEN 1 ELSE 0 END) AS total_7d,
				COUNT(*) AS total_30d
				FROM %i WHERE created_at >= %s",
				$table,
				$day,
				$two_days,
				$day,
				$day,
				$day,
				$day,
				'login%',
				$day,
				$week,
				$month
			),
			ARRAY_A
		);

		$total_24h     = max( 0, (int) ( $row['total_24h'] ?? 0 ) );
		$previous_24h  = max( 0, (int) ( $row['previous_24h'] ?? 0 ) );
		$critical_24h  = max( 0, (int) ( $row['critical_24h'] ?? 0 ) );
		$unblocked_24h = max( 0, (int) ( $row['unblocked_24h'] ?? 0 ) );
		$login_24h     = max( 0, (int) ( $row['login_24h'] ?? 0 ) );
		$max_risk      = max( 0, min( 100, (int) ( $row['max_risk_24h'] ?? 0 ) ) );
		$total_7d      = max( 0, (int) ( $row['total_7d'] ?? 0 ) );
		$total_30d     = max( 0, (int) ( $row['total_30d'] ?? 0 ) );
		$daily_average = round( $total_7d / 7, 1 );
		$change        = self::percent_change( $total_24h, $daily_average );
		$day_change    = self::percent_change( $total_24h, $previous_24h );

		$top_types = self::top_event_types( $table, $day );
		$peak      = self::peak_hour( $table, $day );
		$repeat    = self::repeated_sources( $table, $month );

		$level = 'normal';
		if ( $critical_24h > 0 || $max_risk >= 90 ) {
			$level = 'critical';
		} elseif ( $unblocked_24h >= 3 || $change >= 100 || $day_change >= 150 || $max_risk >= 75 ) {
			$level = 'warning';
		} elseif ( $total_24h > 0 ) {
			$level = 'watch';
		}

		$title = '目立った異常は確認されていません';
		if ( 'critical' === $level ) {
			$title = '高危険度イベントを優先確認してください';
		} elseif ( 'warning' === $level ) {
			$title = '通常より注意が必要な状況です';
		} elseif ( 'watch' === $level ) {
			$title = '検知イベントを継続監視してください';
		}

		$summary = self::build_summary( $total_24h, $daily_average, $change, $day_change, $critical_24h, $login_24h, $unblocked_24h, $top_types, $peak );
		$actions = self::build_actions( $critical_24h, $unblocked_24h, $login_24h, $change, $day_change, $total_24h, $top_types, $repeat );

		$analysis = array(
			'level'             => $level,
			'title'             => $title,
			'summary'           => $summary,
			'actions'           => $actions,
			'total_24h'         => $total_24h,
			'previous_24h'      => $previous_24h,
			'daily_average'     => $daily_average,
			'change_percent'    => $change,
			'day_change_percent'=> $day_change,
			'critical_24h'      => $critical_24h,
			'unblocked_24h'     => $unblocked_24h,
			'login_24h'         => $login_24h,
			'max_risk'          => $max_risk,
			'top_types'         => $top_types,
			'peak_hour'         => $peak,
			'repeated_sources'  => $repeat,
			'confidence'        => $total_30d >= 50 ? '高い' : ( $total_30d >= 10 ? '中程度' : '限定的' ),
			'privacy_note'      => '分析はWordPress内の集計値と匿名化ハッシュだけを使用し、IP、URL、本文、パスワード、ファイル内容を外部送信しません。',
		);

		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		set_transient( self::CACHE_KEY, $analysis, self::CACHE_TTL );
		return $analysis;
	}

	public static function clear_cache(): void {
		delete_transient( self::CACHE_KEY );
	}

	private static function percent_change( float $current, float $baseline ): int {
		if ( $baseline <= 0 ) {
			return $current > 0 ? 100 : 0;
		}
		return (int) round( ( ( $current - $baseline ) / $baseline ) * 100 );
	}

	/** @return array<int,array{type:string,label:string,total:int,max_risk:int}> */
	private static function top_event_types( string $table, string $day ): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Called only while refreshing the 60-second cached analyst result; query is prepared and bounded.
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_type, COUNT(*) AS total, MAX(risk_score) AS max_risk FROM %i WHERE created_at >= %s GROUP BY event_type ORDER BY total DESC, max_risk DESC LIMIT 3",
				$table,
				$day
			),
			ARRAY_A
		);
		$out = array();
		foreach ( $rows as $row ) {
			$type  = sanitize_key( (string) ( $row['event_type'] ?? '' ) );
			$out[] = array(
				'type'     => $type,
				'label'    => KProtect_Risk_Score_Calculator::event_label( $type ),
				'total'    => max( 0, (int) ( $row['total'] ?? 0 ) ),
				'max_risk' => max( 0, min( 100, (int) ( $row['max_risk'] ?? 0 ) ) ),
			);
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $out;
	}

	/** @return array{hour:string,total:int} */
	private static function peak_hour( string $table, string $day ): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Called only while refreshing the 60-second cached analyst result; query is prepared and bounded.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT DATE_FORMAT(created_at, '%%H:00') AS peak_hour, COUNT(*) AS total FROM %i WHERE created_at >= %s GROUP BY DATE_FORMAT(created_at, '%%Y-%%m-%%d %%H') ORDER BY total DESC LIMIT 1",
				$table,
				$day
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return array(
			'hour'  => sanitize_text_field( (string) ( $row['peak_hour'] ?? '該当なし' ) ),
			'total' => max( 0, (int) ( $row['total'] ?? 0 ) ),
		);
	}

	/** @return array{groups:int,max_events:int} */
	private static function repeated_sources( string $table, string $month ): array {
		global $wpdb;
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Called only while refreshing the 60-second cached analyst result; query is prepared and bounded.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS source_groups, COALESCE(MAX(event_total),0) AS max_events FROM (SELECT ip_hash, COUNT(*) AS event_total FROM %i WHERE created_at >= %s AND ip_hash <> '' GROUP BY ip_hash HAVING COUNT(*) >= 3) AS repeated",
				$table,
				$month
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return array(
			'groups'     => max( 0, (int) ( $row['source_groups'] ?? 0 ) ),
			'max_events' => max( 0, (int) ( $row['max_events'] ?? 0 ) ),
		);
	}

	/** @param array<int,array{type:string,label:string,total:int,max_risk:int}> $top_types
	 *  @param array{hour:string,total:int} $peak
	 */
	private static function build_summary( int $total, float $average, int $change, int $day_change, int $critical, int $login, int $unblocked, array $top_types, array $peak ): string {
		if ( 0 === $total ) {
			return '直近24時間に検知イベントはありません。比較精度を高めるには、今後のログ蓄積が必要です。';
		}
		$trend = $change > 0 ? '7日の日平均より' . abs( $change ) . '%多い' : ( $change < 0 ? '7日の日平均より' . abs( $change ) . '%少ない' : '7日の日平均と同程度の' );
		$day_trend = $day_change > 0 ? '前の24時間より' . abs( $day_change ) . '%増加' : ( $day_change < 0 ? '前の24時間より' . abs( $day_change ) . '%減少' : '前の24時間と同程度' );
		$top = ! empty( $top_types ) ? '最多は「' . $top_types[0]['label'] . '」' . $top_types[0]['total'] . '件です。' : '';
		$peak_text = (int) $peak['total'] > 0 ? '集中時間帯は' . $peak['hour'] . '頃（' . $peak['total'] . '件）です。' : '';
		return '直近24時間は' . $total . '件で、' . $trend . '検知数です。' . $day_trend . 'しています。高危険度は' . $critical . '件、ログイン関連は' . $login . '件、未遮断は' . $unblocked . '件です。' . $top . $peak_text . '7日の日平均は' . $average . '件です。';
	}

	/** @param array<int,array{type:string,label:string,total:int,max_risk:int}> $top_types
	 *  @param array{groups:int,max_events:int} $repeat
	 *  @return array<int,string>
	 */
	private static function build_actions( int $critical, int $unblocked, int $login, int $change, int $day_change, int $total, array $top_types, array $repeat ): array {
		$actions = array();
		if ( $critical > 0 ) {
			$actions[] = '危険度90以上のイベントについて、検知理由と遮断結果を確認する';
		}
		if ( $unblocked > 0 ) {
			$actions[] = '未遮断イベントが正規アクセスか攻撃試行かを関連ログで確認する';
		}
		if ( $login >= 3 ) {
			$actions[] = 'ログイン失敗の集中がないか確認し、二要素認証と遮断設定を見直す';
		}
		if ( ( $change >= 100 || $day_change >= 150 ) && $total >= 5 ) {
			$actions[] = '検知数が通常より増えているため、発生時間帯とイベント種別を確認する';
		}
		if ( ! empty( $top_types ) && $top_types[0]['total'] >= 5 ) {
			$actions[] = '最も多い「' . $top_types[0]['label'] . '」の関連ログを優先的に確認する';
		}
		if ( $repeat['groups'] > 0 && $repeat['max_events'] >= 5 ) {
			$actions[] = '同一の匿名化された接続元から繰り返し検知されています。ブロック状況と正規アクセスの可能性を確認する';
		}
		if ( empty( $actions ) ) {
			$actions[] = '緊急対応は不要です。通常の監視と定期点検を継続する';
		}
		return array_slice( array_values( array_unique( $actions ) ), 0, 5 );
	}
}
