<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Builds a deterministic, privacy-preserving explanation for one security event.
 */
final class KProtect_Event_Advisor {
	/**
	 * Analyze one stored security event without external communication.
	 *
	 * @param string            $event_type Event type key.
	 * @param array<int,string> $reasons    Detector reason keys.
	 * @param int               $risk       Risk score from 0 to 100.
	 * @param bool              $blocked    Whether KProtect blocked the request.
	 * @param string            $path       Sanitized request path.
	 * @return array<string,mixed>
	 */
	public static function analyze( string $event_type, array $reasons, int $risk, bool $blocked, string $path = '' ): array {
		$risk       = max( 0, min( 100, $risk ) );
		$event_type = strtolower( preg_replace( '/[^a-z0-9_\-]/i', '', $event_type ) ?? '' );
		$path       = self::safe_path( $path );
		$category   = self::category( $event_type, $reasons );
		$level      = self::level( $risk );
		$confidence = self::confidence( $risk, $reasons );

		return array(
			'level'               => $level,
			'level_label'         => self::level_label( $level ),
			'confidence'          => $confidence,
			'confidence_label'    => self::confidence_label( $confidence ),
			'headline'            => self::headline( $category, $blocked ),
			'what_happened'       => self::what_happened( $category, $path ),
			'assessment'          => self::assessment( $risk, $blocked, count( $reasons ) ),
			'false_positive_note' => self::false_positive_note( $category, $path ),
			'actions'             => self::actions( $category, $risk, $blocked ),
			'privacy_note'        => 'この説明は保存済みのローカル情報だけで生成され、外部AIサービスへ送信されません。',
		);
	}

	/** @param array<int,string> $reasons */
	private static function category( string $event_type, array $reasons ): string {
		$haystack = strtolower( $event_type . ' ' . implode( ' ', $reasons ) );
		$map      = array(
			'file'      => array( 'file_integrity', 'integrity', 'official_modified', 'modified', 'missing', 'added' ),
			'login'     => array( 'login', 'bruteforce', 'credential' ),
			'sqli'      => array( 'sql_injection', 'sqli' ),
			'xss'       => array( 'cross_site_scripting', 'xss' ),
			'traversal' => array( 'path_traversal', 'directory_traversal', '../' ),
			'code'      => array( 'code_execution', 'command_injection', 'webshell', 'web_shell' ),
			'rate'      => array( 'rate_limit', 'too_many_requests' ),
			'malware'   => array( 'malware', 'suspicious_upload', 'uploads_php' ),
			'xmlrpc'    => array( 'xmlrpc', 'xml-rpc' ),
		);
		foreach ( $map as $category => $needles ) {
			foreach ( $needles as $needle ) {
				if ( false !== strpos( $haystack, $needle ) ) {
					return $category; }
			}
		}
		return 'generic';
	}

	private static function level( int $risk ): string {
		if ( $risk >= 90 ) {
			return 'critical'; }
		if ( $risk >= 70 ) {
			return 'high'; }
		if ( $risk >= 40 ) {
			return 'medium'; }
		return 'low';
	}

	private static function level_label( string $level ): string {
		return array(
			'critical' => '重大',
			'high'     => '高',
			'medium'   => '中',
			'low'      => '低',
		)[ $level ] ?? '低';
	}

	/** @param array<int,string> $reasons */
	private static function confidence( int $risk, array $reasons ): string {
		if ( $risk >= 85 && count( $reasons ) >= 2 ) {
			return 'high'; }
		if ( $risk >= 55 || count( $reasons ) >= 2 ) {
			return 'medium'; }
		return 'limited';
	}

	private static function confidence_label( string $confidence ): string {
		return array(
			'high'    => '高い',
			'medium'  => '中程度',
			'limited' => '限定的',
		)[ $confidence ] ?? '限定的';
	}

	private static function headline( string $category, bool $blocked ): string {
		$labels = array(
			'file'      => 'ファイル変更の正当性を確認してください',
			'login'     => 'ログイン試行の増加を確認してください',
			'sqli'      => 'SQLインジェクションの疑いがあります',
			'xss'       => 'スクリプト注入の疑いがあります',
			'traversal' => '非公開ファイル探索の疑いがあります',
			'code'      => 'コード実行を狙うアクセスの疑いがあります',
			'rate'      => '短時間にアクセスが集中しています',
			'malware'   => 'uploads内の要確認ファイルがあります',
			'xmlrpc'    => 'XML-RPC経由のアクセスを確認してください',
			'generic'   => '検知内容を確認してください',
		);
		return ( $labels[ $category ] ?? $labels['generic'] ) . ( $blocked ? '（遮断済み）' : '（監査記録）' );
	}

	private static function what_happened( string $category, string $path ): string {
		$texts = array(
			'file'      => '保存済みの基準状態と現在のファイル状態に差分が見つかりました。',
			'login'     => '認証画面に対する失敗または不審なログイン試行を検知しました。',
			'sqli'      => 'リクエスト内にデータベース操作を狙う特徴的な文字列が含まれていました。',
			'xss'       => 'リクエスト内にブラウザ上でスクリプトを動かす目的と一致する特徴がありました。',
			'traversal' => '通常公開されない上位ディレクトリや設定ファイルを参照する特徴がありました。',
			'code'      => 'サーバー上で命令やPHPコードを実行させる目的と一致する特徴がありました。',
			'rate'      => '同一のアクセス元から短時間に多数のリクエストが発生しました。',
			'malware'   => 'uploads領域でPHP系ファイルまたは要確認コードを検知しました。',
			'xmlrpc'    => 'XML-RPCエンドポイントへのアクセスを検知しました。',
			'generic'   => 'KProtectの検知ルールに一致する通常と異なるアクセスを記録しました。',
		);
		$text  = $texts[ $category ] ?? $texts['generic'];
		if ( '' !== $path ) {
			$text .= ' 対象は「' . $path . '」です。'; }
		return $text;
	}

	private static function assessment( int $risk, bool $blocked, int $reason_count ): string {
		$status = $blocked ? '自動遮断されているため、同じリクエストによる直接的な影響は抑えられています。' : '監査記録のみのため、関連ログとサイト状態を確認してください。';
		if ( $risk >= 90 ) {
			return '危険度が非常に高く、複数の根拠を含む可能性があります。' . $status; }
		if ( $risk >= 70 ) {
			return '危険度が高いため、正規操作か攻撃かを早めに切り分けてください。' . $status; }
		if ( $reason_count >= 2 ) {
			return '複数の弱い兆候が重なっています。単独の根拠より注意して確認してください。' . $status; }
		return '現時点の根拠は限定的です。単発であれば監視を継続し、繰り返す場合は詳しく確認してください。' . $status;
	}

	private static function false_positive_note( string $category, string $path ): string {
		if ( 'file' === $category ) {
			return 'WordPress・テーマ・プラグインの正規更新直後は、正常な変更でも検知されます。更新履歴と配布元を確認してください。'; }
		if ( 'login' === $category ) {
			return '管理者本人の入力ミスやパスワード管理ツールの再試行でも記録される場合があります。'; }
		if ( 'rate' === $category ) {
			return 'バックアップ、監視サービス、検索エンジンなどの正規アクセスが集中した可能性もあります。'; }
		if ( 'xmlrpc' === $category ) {
			return 'Jetpackやモバイルアプリなど、XML-RPCを利用する正規機能の場合があります。'; }
		if ( '' !== $path && false !== strpos( $path, '/wp-admin/' ) ) {
			return '管理画面内の正規操作が特殊な文字列を含み、誤検知した可能性もあります。'; }
		return '単一ログだけでは侵害を断定できません。同じ攻撃元・種類の繰り返し、サーバーログ、更新履歴も合わせて判断してください。';
	}

	/** @return array<int,string> */
	private static function actions( string $category, int $risk, bool $blocked ): array {
		$actions = array();
		if ( 'file' === $category ) {
			$actions = array( '直前の正規更新履歴と変更ファイルを照合する', '心当たりがなければバックアップを取得してファイル内容を調査する', '安全確認前に新しい基準へ更新しない' );
		} elseif ( 'login' === $category ) {
			$actions = array( '攻撃元と失敗回数を確認する', '管理者アカウントとパスワードの強度を確認する', '必要に応じて二段階認証を導入する' );
		} elseif ( 'malware' === $category || 'code' === $category ) {
			$actions = array( '対象ファイルやリクエストを削除せず先にバックアップする', '正規ファイルとハッシュまたは配布元を照合する', '不審な管理者・Cron・追加ファイルがないか確認する' );
		} else {
			$actions = array( '同じ攻撃元・種類の関連ログを確認する', '対象パスと直前の管理操作を照合する', $blocked ? '繰り返しがなければ監視を継続する' : '高危険度または繰り返しなら一時ブロックを検討する' );
		}
		if ( $risk >= 90 ) {
			array_unshift( $actions, 'サイトとデータベースの最新バックアップを確保する' ); }
		return array_slice( array_values( array_unique( $actions ) ), 0, 3 );
	}

	private static function safe_path( string $path ): string {
		$path = trim( $path );
		if ( '' === $path ) {
			return ''; }
		$parts = wp_parse_url( $path );
		if ( is_array( $parts ) && isset( $parts['path'] ) ) {
			$path = (string) $parts['path']; }
		return substr( $path, 0, 180 );
	}
}
