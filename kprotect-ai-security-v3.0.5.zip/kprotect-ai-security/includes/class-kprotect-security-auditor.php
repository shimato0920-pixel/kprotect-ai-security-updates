<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Security_Auditor {
	public function audit(): array {
		$checks   = array();
		$checks[] = $this->check(
			'wp_debug',
			'デバッグ表示',
			! ( defined( 'WP_DEBUG' ) && WP_DEBUG ),
			defined( 'WP_DEBUG' ) && WP_DEBUG ? 'WP_DEBUG が有効です。本番環境では無効を推奨します。' : 'WP_DEBUG は無効です。',
			'warning'
		);
		$checks[] = $this->check(
			'disallow_file_edit',
			'管理画面のファイル編集',
			defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
			defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ? 'テーマ・プラグインエディターは無効です。' : 'DISALLOW_FILE_EDIT が未設定です。',
			'warning'
		);
		$checks[] = $this->check(
			'force_ssl_admin',
			'管理画面HTTPS',
			is_ssl() || ( defined( 'FORCE_SSL_ADMIN' ) && FORCE_SSL_ADMIN ),
			is_ssl() || ( defined( 'FORCE_SSL_ADMIN' ) && FORCE_SSL_ADMIN ) ? '管理画面はHTTPSで利用されています。' : '管理画面のHTTPSを確認してください。',
			'danger'
		);
		$checks[] = $this->check(
			'xmlrpc',
			'XML-RPC保護',
			! empty( KProtect_Utils::settings()['disable_xmlrpc'] ),
			! empty( KProtect_Utils::settings()['disable_xmlrpc'] ) ? 'KProtectでXML-RPCを無効化しています。' : 'XML-RPC保護が無効です。利用しない場合は無効化を推奨します。',
			'warning'
		);
		$checks[] = $this->permission_check( ABSPATH . 'wp-config.php', 'wp-config.php権限' );
		if ( ! is_file( ABSPATH . 'wp-config.php' ) ) {
			$checks[] = $this->permission_check( dirname( ABSPATH ) . '/wp-config.php', 'wp-config.php権限' );
		}
		$checks[] = $this->permission_check( ABSPATH . '.htaccess', '.htaccess権限', true );
		$checks[] = $this->check(
			'auto_updates',
			'WordPress自動更新',
			! ( defined( 'AUTOMATIC_UPDATER_DISABLED' ) && AUTOMATIC_UPDATER_DISABLED ),
			defined( 'AUTOMATIC_UPDATER_DISABLED' ) && AUTOMATIC_UPDATER_DISABLED ? '自動更新が完全に無効化されています。' : '自動更新機構は利用可能です。',
			'warning'
		);
		return array_values( array_filter( $checks ) );
	}

	public function score( array $checks ): int {
		if ( empty( $checks ) ) {
			return 0; }
		$earned = 0;
		foreach ( $checks as $check ) {
			$earned += ! empty( $check['passed'] ) ? 1 : 0; }
		return (int) round( ( $earned / count( $checks ) ) * 100 );
	}

	private function permission_check( string $file, string $label, bool $optional = false ): ?array {
		if ( ! is_file( $file ) ) {
			return $optional ? null : $this->check( sanitize_key( $label ), $label, false, 'ファイルを確認できませんでした。', 'warning' );
		}
		$perms = fileperms( $file );
		if ( false === $perms ) {
			return $this->check( sanitize_key( $label ), $label, false, '権限を取得できませんでした。', 'warning' ); }
		$octal          = substr( sprintf( '%o', $perms ), -4 );
		$world_writable = ( ( $perms & 0x0002 ) !== 0 );
		$group_writable = ( ( $perms & 0x0010 ) !== 0 );
		$passed         = ! $world_writable && ! $group_writable;
		return $this->check( sanitize_key( $label ), $label, $passed, '現在の権限: ' . $octal . ( $passed ? '' : '（書き込み権限が広すぎる可能性があります）' ), 'danger' );
	}

	private function check( string $id, string $label, bool $passed, string $message, string $severity ): array {
		return compact( 'id', 'label', 'passed', 'message', 'severity' );
	}
}
