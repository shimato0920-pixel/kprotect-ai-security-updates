<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_Rule_Repository {
	private const OPTION = 'kprotect_ai_rules';

	/** @return array<int,array<string,mixed>> */
	public function all(): array {
		$rules = get_option( self::OPTION, array() );
		return is_array( $rules ) ? array_values( $rules ) : array();
	}

	/** @return array<string,mixed>|null */
	public function find( string $id ): ?array {
		$id = sanitize_key( $id );
		foreach ( $this->all() as $rule ) {
			if ( $id === sanitize_key( (string) ( $rule['id'] ?? '' ) ) ) {
				return $rule;
			}
		}
		return null;
	}

	public function save( array $rule ): bool {
		$result = KProtect_Rule_Validator::validate( $rule );
		if ( ! $result['valid'] ) {
			return false;
		}
		$clean            = $result['rule'];
		$clean['enabled'] = false;
		$rules            = $this->all();
		$rules[]          = $clean;
		return update_option( self::OPTION, $rules, false );
	}

	public function update( string $id, array $rule ): bool {
		$id       = sanitize_key( $id );
		$result   = KProtect_Rule_Validator::validate( $rule );
		$existing = $this->find( $id );
		if ( ! $result['valid'] || null === $existing ) {
			return false;
		}
		$clean               = $result['rule'];
		$clean['id']         = $id;
		$clean['enabled']    = ! empty( $existing['enabled'] );
		$clean['created_at'] = (string) ( $existing['created_at'] ?? $clean['created_at'] );
		$clean['updated_at'] = current_time( 'mysql', true );
		$rules               = $this->all();
		foreach ( $rules as $index => $stored ) {
			if ( $id === sanitize_key( (string) ( $stored['id'] ?? '' ) ) ) {
				$rules[ $index ] = $clean;
				$expected         = array_values( $rules );
				$updated          = update_option( self::OPTION, $expected, false );

				// update_option() legitimately returns false when the serialized value is
				// unchanged. It may also leave a stale value in an external object cache.
				// Always clear the option cache and verify the specific rule that was saved.
				wp_cache_delete( self::OPTION, 'options' );
				$saved = $this->find( $id );
				if ( null !== $saved && self::same_editable_values( $saved, $clean ) ) {
					return true;
				}

				return (bool) $updated;
			}
		}
		return false;
	}

	/** Compare the fields administrators can edit. */
	private static function same_editable_values( array $saved, array $expected ): bool {
		$keys = array( 'id', 'name', 'description', 'enabled', 'conditions', 'window', 'actions', 'created_at' );
		foreach ( $keys as $key ) {
			if ( ( $saved[ $key ] ?? null ) !== ( $expected[ $key ] ?? null ) ) {
				return false;
			}
		}
		return true;
	}

	public function set_enabled( string $id, bool $enabled ): bool {
		$id    = sanitize_key( $id );
		$rules = $this->all();
		foreach ( $rules as $index => $rule ) {
			if ( $id === sanitize_key( (string) ( $rule['id'] ?? '' ) ) ) {
				$rules[ $index ]['enabled']    = $enabled;
				$rules[ $index ]['updated_at'] = current_time( 'mysql', true );
				return update_option( self::OPTION, array_values( $rules ), false );
			}
		}
		return false;
	}

	/** @return array<int,array<string,mixed>> */
	public function similar( array $candidate, string $exclude_id = '' ): array {
		$signature = self::signature( $candidate );
		$out       = array();
		foreach ( $this->all() as $rule ) {
			$id = sanitize_key( (string) ( $rule['id'] ?? '' ) );
			if ( '' !== $exclude_id && $id === sanitize_key( $exclude_id ) ) { continue; }
			if ( $signature === self::signature( $rule ) ) { $out[] = $rule; }
		}
		return $out;
	}

	private static function signature( array $rule ): string {
		$conditions = array();
		foreach ( (array) ( $rule['conditions'] ?? array() ) as $condition ) {
			if ( ! is_array( $condition ) ) { continue; }
			$value = $condition['value'] ?? '';
			if ( is_array( $value ) ) { sort( $value ); $value = implode( ',', $value ); }
			elseif ( is_bool( $value ) ) { $value = $value ? '1' : '0'; }
			$conditions[] = sanitize_key( (string) ( $condition['field'] ?? '' ) ) . '|' . (string) ( $condition['operator'] ?? '' ) . '|' . (string) $value;
		}
		sort( $conditions );
		return hash( 'sha256', implode( ';', $conditions ) . '|window:' . (int) ( $rule['window']['value'] ?? 15 ) );
	}

	public function delete( string $id ): bool {
		$id     = sanitize_key( $id );
		$before = $this->all();
		$rules  = array_values(
			array_filter(
				$before,
				static fn( $rule ) => sanitize_key( (string) ( $rule['id'] ?? '' ) ) !== $id
			)
		);
		if ( count( $before ) === count( $rules ) ) {
			return false;
		}
		return update_option( self::OPTION, $rules, false );
	}
}
