<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Notifier {
	private const LAST_SENT_OPTION = 'kprotect_last_email_notice';
	private KProtect_Notification_Center $center;
	private KProtect_Discord_Notifier $discord;
	private KProtect_Slack_Notifier $slack;
	private KProtect_Webhook_Notifier $webhook;

	public function __construct( ?KProtect_Notification_Center $center = null ) {
		$this->center  = $center ?: new KProtect_Notification_Center();
		$this->discord = new KProtect_Discord_Notifier();
		$this->slack   = new KProtect_Slack_Notifier();
		$this->webhook = new KProtect_Webhook_Notifier();
	}

	public function maybe_send( string $event_type, int $score, array $reasons ): void {
		$this->center->record( $event_type, $score, $reasons );
		$settings = KProtect_Utils::settings();
		$queue    = new KProtect_Notification_Queue();
		if ( KProtect_Notification_Rules::email_allowed( $settings, $event_type, $score ) ) {
			$queue->enqueue( 'email', $event_type, $score, $reasons ); }
		if ( KProtect_Notification_Rules::discord_allowed( $settings, $event_type, $score ) ) {
			$queue->enqueue( 'discord', $event_type, $score, $reasons ); }
		if ( KProtect_Notification_Rules::slack_allowed( $settings, $event_type, $score ) ) {
			$queue->enqueue( 'slack', $event_type, $score, $reasons ); }
		if ( KProtect_Notification_Rules::webhook_allowed( $settings, $event_type, $score ) ) {
			$queue->enqueue( 'webhook', $event_type, $score, $reasons ); }
	}

	/** @return true|WP_Error */
	public function send_email( string $event_type, int $score, array $reasons, bool $is_test = false ) {
		$settings = KProtect_Utils::settings();
		$to       = sanitize_email( (string) ( $settings['notification_email'] ?: get_option( 'admin_email' ) ) );
		if ( ! is_email( $to ) ) {
			$error = new WP_Error( 'kprotect_email_address', '通知先メールアドレスが無効です。' );
			( new KProtect_Delivery_History() )->record( 'email', $event_type, $score, $reasons, false, 0, 0, $error->get_error_message(), $is_test );
			return $error;
		}
		$desc     = KProtect_Notification_Center::describe( $event_type, $score, $reasons );
		$subject  = sprintf( '[KProtect][%s] %s (%d)', strtoupper( $desc['severity'] ), $is_test ? 'メール接続テスト' : $desc['title'], $score );
		$body     = $is_test ? "KProtect AI Security のメール接続テストです。実際の攻撃ではありません。\n\n" : "KProtect AI Security が高危険度イベントを検知しました。\n\n";
		$body    .= 'サイト: ' . home_url( '/' ) . "\n";
		$body    .= '種類: ' . sanitize_key( $event_type ) . "\n";
		$body    .= '危険度: ' . max( 0, min( 100, $score ) ) . "\n";
		$body    .= $desc['message'] . "\n";
		$body    .= '日時: ' . wp_date( 'Y-m-d H:i:s T' ) . "\n\n";
		$body    .= '通知センター: ' . admin_url( 'admin.php?page=kprotect-notifications' ) . "\n";
		$started  = microtime( true );
		$sent     = wp_mail( $to, $subject, $body );
		$duration = (int) round( ( microtime( true ) - $started ) * 1000 );
		$error    = $sent ? '' : 'wp_mail()がfalseを返しました。メール配送設定を確認してください。';
		( new KProtect_Delivery_History() )->record( 'email', $event_type, $score, $reasons, $sent, 0, $duration, $error, $is_test );
		return $sent ? true : new WP_Error( 'kprotect_email_failed', $error );
	}
}
