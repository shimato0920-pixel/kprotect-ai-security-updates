<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Builds read-only security summaries from locally stored KProtect data.
 */
final class KProtect_Security_Report {
	/** @return array<string,mixed> */
	public function build( int $days ): array {
		global $wpdb;
		$days          = in_array( $days, array( 1, 7, 30 ), true ) ? $days : 7;
		$range         = $this->range( $days );
		$logs          = $wpdb->prefix . 'kprotect_logs';
		$notifications = $wpdb->prefix . 'kprotect_notifications';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- On-demand security report intentionally reads current KProtect-owned log/notification data for the requested range; all queries are prepared and bounded.

		$summary   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS total, COALESCE(SUM(blocked),0) AS blocked, COALESCE(MAX(risk_score),0) AS max_risk, COALESCE(AVG(risk_score),0) AS avg_risk FROM %i WHERE created_at >= %s AND created_at < %s",
				$logs,
				$range['start_gmt'],
				$range['end_gmt']
			),
			ARRAY_A
		);
		$types     = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT event_type, COUNT(*) AS total, COALESCE(SUM(blocked),0) AS blocked, MAX(risk_score) AS max_risk FROM %i WHERE created_at >= %s AND created_at < %s GROUP BY event_type ORDER BY total DESC LIMIT 10",
				$logs,
				$range['start_gmt'],
				$range['end_gmt']
			),
			ARRAY_A
		);
		$daily     = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) AS day, COUNT(*) AS total, COALESCE(SUM(blocked),0) AS blocked FROM %i WHERE created_at >= %s AND created_at < %s GROUP BY DATE(created_at) ORDER BY day ASC",
				$logs,
				$range['start_gmt'],
				$range['end_gmt']
			),
			ARRAY_A
		);
		$important = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, updated_at, title, severity, risk_score, occurrences, status FROM %i WHERE updated_at >= %s AND updated_at < %s AND risk_score >= 75 ORDER BY risk_score DESC, updated_at DESC LIMIT 8",
				$notifications,
				$range['start_gmt'],
				$range['end_gmt']
			),
			ARRAY_A
		);

		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$summary  = is_array( $summary ) ? $summary : array();
		$total    = (int) ( $summary['total'] ?? 0 );
		$blocked  = (int) ( $summary['blocked'] ?? 0 );
		$max_risk = (int) ( $summary['max_risk'] ?? 0 );
		$avg_risk = (float) ( $summary['avg_risk'] ?? 0 );
		$score    = max( 0, 100 - min( 60, $max_risk ) - min( 25, (int) floor( $total / max( 1, $days * 5 ) ) ) + min( 10, (int) floor( $blocked / 5 ) ) );
		$score    = max( 0, min( 100, $score ) );

		return array(
			'days'       => $days,
			'label'      => 1 === $days ? '今日' : $days . '日間',
			'range'      => $range,
			'total'      => $total,
			'blocked'    => $blocked,
			'block_rate' => $total > 0 ? round( ( $blocked / $total ) * 100, 1 ) : 0.0,
			'max_risk'   => $max_risk,
			'avg_risk'   => round( $avg_risk, 1 ),
			'score'      => $score,
			'level'      => $score >= 85 ? '良好' : ( $score >= 65 ? '要注意' : '高リスク' ),
			'types'      => is_array( $types ) ? $types : array(),
			'daily'      => is_array( $daily ) ? $daily : array(),
			'important'  => is_array( $important ) ? $important : array(),
			'advice'     => $this->advice( $total, $blocked, $max_risk, (array) $types, (array) $important ),
		);
	}

	/** @return array<string,string> */
	private function range( int $days ): array {
		$timezone    = wp_timezone();
		$end_local   = new DateTimeImmutable( 'tomorrow', $timezone );
		$start_local = 1 === $days ? new DateTimeImmutable( 'today', $timezone ) : $end_local->modify( '-' . $days . ' days' );
		return array(
			'start_gmt'   => $start_local->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
			'end_gmt'     => $end_local->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ),
			'start_local' => wp_date( 'Y年n月j日 H:i', $start_local->getTimestamp(), $timezone ),
			'end_local'   => wp_date( 'Y年n月j日 H:i', $end_local->getTimestamp(), $timezone ),
		);
	}

	/** @param array<int,array<string,mixed>> $types @param array<int,array<string,mixed>> $important @return array<int,array<string,string>> */
	private function advice( int $total, int $blocked, int $max_risk, array $types, array $important ): array {
		$out = array();
		if ( $max_risk >= 90 ) {
			$out[] = array(
				'priority' => '最優先',
				'title'    => 'CRITICAL通知を確認',
				'message'  => '危険度90以上の検知があります。通知センターと関連ログを確認してください。',
				'page'     => 'kprotect-notifications',
			); }
		foreach ( $types as $type ) {
			$name  = (string) ( $type['event_type'] ?? '' );
			$count = (int) ( $type['total'] ?? 0 );
			if ( false !== strpos( $name, 'login' ) && $count >= 5 ) {
				$out[] = array(
					'priority' => '高',
					'title'    => 'ログイン保護を確認',
					'message'  => 'ログイン関連の検知が複数あります。二段階認証と管理者アカウントの点検を推奨します。',
					'page'     => 'kprotect-settings',
				);
				break; }
		}
		if ( $total > 0 && $blocked < $total / 2 ) {
			$out[] = array(
				'priority' => '中',
				'title'    => '遮断しきい値を確認',
				'message'  => '検知に対する遮断率が50%未満です。ログを確認し、誤検知に注意しながらしきい値を見直してください。',
				'page'     => 'kprotect-settings',
			); }
		if ( ! empty( $important ) ) {
			$out[] = array(
				'priority' => '高',
				'title'    => '重要通知を処理',
				'message'  => '未処理の重要通知を確認し、「正しい検知・誤検知・要確認・承認済み変更」を記録してください。',
				'page'     => 'kprotect-notifications',
			); }
		if ( empty( $out ) ) {
			$out[] = array(
				'priority' => '継続',
				'title'    => '現在の設定を維持',
				'message'  => '大きな異常は見つかりません。更新、バックアップ、定期スキャンを継続してください。',
				'page'     => 'kprotect-audit',
			); }
		return array_slice( $out, 0, 4 );
	}
}
