<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Sends selected security events to a Slack incoming webhook.
 */
final class KProtect_Slack_Notifier {
	private const LAST_SENT_OPTION = 'kprotect_last_slack_notice';

	public function maybe_send( string $event_type, int $score, array $reasons ): void {
		$settings = KProtect_Utils::settings();
		if ( ! KProtect_Notification_Rules::slack_allowed( $settings, $event_type, $score ) ) {
			return; }
		$key      = KProtect_Notification_Center::fingerprint( $event_type, $reasons );
		$last     = (array) get_option( self::LAST_SENT_OPTION, array() );
		$cooldown = max( 5, (int) ( $settings['slack_cooldown_minutes'] ?? 60 ) ) * MINUTE_IN_SECONDS;
		if ( isset( $last[ $key ] ) && ( time() - (int) $last[ $key ] ) < $cooldown ) {
			return; }
		$result = $this->send( $event_type, $score, $reasons );
		if ( is_wp_error( $result ) ) {
			update_option(
				'kprotect_last_slack_error',
				array(
					'message'     => sanitize_text_field( $result->get_error_message() ),
					'recorded_at' => current_time( 'mysql' ),
				),
				false
			);
			return;
		}
		$last[ $key ] = time();
		if ( count( $last ) > 200 ) {
			$last = array_slice( $last, -200, null, true ); }
		update_option( self::LAST_SENT_OPTION, $last, false );
		delete_option( 'kprotect_last_slack_error' );
	}

	/** @return true|WP_Error */
	public function send( string $event_type, int $score, array $reasons, bool $is_test = false ) {
		$settings = KProtect_Utils::settings();
		$url      = self::sanitize_webhook_url( (string) ( $settings['slack_webhook_url'] ?? '' ) );
		if ( '' === $url ) {
			return new WP_Error( 'kprotect_slack_url', 'Slack Webhook URLが未設定または無効です。' ); }
		$desc     = KProtect_Notification_Center::describe( $event_type, $score, $reasons );
		$severity = strtoupper( (string) ( $desc['severity'] ?? 'low' ) );
		$title    = $is_test ? 'KProtect Slack 接続テスト' : (string) ( $desc['title'] ?? 'セキュリティ通知' );
		$message  = $is_test ? 'Slack通知の接続テストです。実際の攻撃ではありません。' : (string) ( $desc['message'] ?? '' );
		$payload  = array(
			'text'   => sprintf( '[KProtect][%s] %s', $severity, $title ),
			'blocks' => array(
				array(
					'type' => 'header',
					'text' => array(
						'type'  => 'plain_text',
						'text'  => wp_html_excerpt( $title, 150, '' ),
						'emoji' => true,
					),
				),
				array(
					'type' => 'section',
					'text' => array(
						'type' => 'mrkdwn',
						'text' => $message,
					),
				),
				array(
					'type'   => 'section',
					'fields' => array(
						array(
							'type' => 'mrkdwn',
							'text' => '*サイト*\n' . home_url( '/' ),
						),
						array(
							'type' => 'mrkdwn',
							'text' => '*危険度*\n' . max( 0, min( 100, $score ) ) . ' / ' . $severity,
						),
						array(
							'type' => 'mrkdwn',
							'text' => '*検知種類*\n' . sanitize_key( $event_type ),
						),
						array(
							'type' => 'mrkdwn',
							'text' => '*時刻*\n' . wp_date( 'Y-m-d H:i:s T' ),
						),
					),
				),
				array(
					'type' => 'section',
					'text' => array(
						'type' => 'mrkdwn',
						'text' => '<' . admin_url( 'admin.php?page=kprotect-notifications' ) . '|通知センターを開く>',
					),
				),
				array(
					'type'     => 'context',
					'elements' => array(
						array(
							'type' => 'mrkdwn',
							'text' => 'IP・リクエスト本文・フォーム内容は送信していません。',
						),
					),
				),
			),
		);
		$args     = array(
			'timeout'     => 6,
			'redirection' => 0,
			'headers'     => array( 'Content-Type' => 'application/json; charset=utf-8' ),
			'body'        => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			'data_format' => 'body',
		);
		$started  = microtime( true );
		$attempts = 1;
		$response = wp_remote_post( $url, $args );
		if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 500 ) {
			$attempts = 2;
			$response = wp_remote_post( $url, $args ); }
		$duration = (int) round( ( microtime( true ) - $started ) * 1000 );
		$history  = new KProtect_Delivery_History();
		if ( is_wp_error( $response ) ) {
			$history->record( 'slack', $event_type, $score, $reasons, false, 0, $duration, $response->get_error_message(), $is_test, $attempts );
			return $response; }
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			$error = new WP_Error( 'kprotect_slack_http', 'SlackがHTTP ' . $code . 'を返しました。Webhook URLとSlack側の設定を確認してください。' );
			$history->record( 'slack', $event_type, $score, $reasons, false, $code, $duration, $error->get_error_message(), $is_test, $attempts );
			return $error; }
		$history->record( 'slack', $event_type, $score, $reasons, true, $code, $duration, '', $is_test, $attempts );
		return true;
	}

	public static function sanitize_webhook_url( string $url ): string {
		$url = esc_url_raw( trim( $url ), array( 'https' ) );
		if ( '' === $url ) {
			return ''; }
		$parts = wp_parse_url( $url );
		$host  = strtolower( (string) ( $parts['host'] ?? '' ) );
		$path  = (string) ( $parts['path'] ?? '' );
		if ( 'hooks.slack.com' !== $host || ! preg_match( '#^/services/[A-Za-z0-9]+/[A-Za-z0-9]+/[A-Za-z0-9]+$#', $path ) ) {
			return ''; }
		return $url;
	}
}
