<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Notification_Rules {
	/**
	 * Known event types exposed in the notification settings UI.
	 *
	 * @return array<string,string>
	 */
	public static function event_types(): array {
		return array(
			'firewall'          => 'Firewall（SQLi・XSS・LFI等）',
			'login_failed'      => 'ログイン失敗',
			'login_blocked'     => 'ログイン自動遮断',
			'rate_limit'        => 'レート制限',
			'blocked_ip'        => '遮断済みIPの再アクセス',
			'file_integrity'    => 'ファイル改ざん検知',
			'malware_scan'      => 'uploads高リスク検知',
			'test_notification' => 'テスト通知',
		);
	}

	/**
	 * Decide whether an email should be sent for an event.
	 *
	 * @param array<string,mixed> $settings Settings.
	 */
	public static function email_allowed( array $settings, string $event_type, int $score ): bool {
		if ( empty( $settings['email_notifications'] ) ) {
			return false;
		}
		if ( $score < (int) ( $settings['email_threshold'] ?? 90 ) ) {
			return false;
		}
		$allowed = $settings['email_event_types'] ?? array_keys( self::event_types() );
		if ( ! is_array( $allowed ) ) {
			$allowed = array();
		}
		$allowed = array_map( 'sanitize_key', $allowed );
		return in_array( sanitize_key( $event_type ), $allowed, true );
	}

	/**
	 * Decide whether a Discord notification should be sent for an event.
	 *
	 * @param array<string,mixed> $settings Settings.
	 */
	public static function discord_allowed( array $settings, string $event_type, int $score ): bool {
		if ( empty( $settings['discord_notifications'] ) ) {
			return false;
		}
		if ( $score < (int) ( $settings['discord_threshold'] ?? 90 ) ) {
			return false;
		}
		$allowed = $settings['discord_event_types'] ?? array_keys( self::event_types() );
		if ( ! is_array( $allowed ) ) {
			$allowed = array();
		}
		$allowed = array_map( 'sanitize_key', $allowed );
		return in_array( sanitize_key( $event_type ), $allowed, true );
	}

	/** Decide whether a Slack notification should be sent. */
	public static function slack_allowed( array $settings, string $event_type, int $score ): bool {
		return self::channel_allowed( $settings, 'slack', $event_type, $score );
	}

	/** Decide whether a generic webhook notification should be sent. */
	public static function webhook_allowed( array $settings, string $event_type, int $score ): bool {
		return self::channel_allowed( $settings, 'webhook', $event_type, $score );
	}

	private static function channel_allowed( array $settings, string $channel, string $event_type, int $score ): bool {
		if ( empty( $settings[ $channel . '_notifications' ] ) ) {
			return false; }
		if ( $score < (int) ( $settings[ $channel . '_threshold' ] ?? 90 ) ) {
			return false; }
		$allowed = $settings[ $channel . '_event_types' ] ?? array_keys( self::event_types() );
		if ( ! is_array( $allowed ) ) {
			$allowed = array(); }
		$allowed = array_map( 'sanitize_key', $allowed );
		return in_array( sanitize_key( $event_type ), $allowed, true );
	}
}
