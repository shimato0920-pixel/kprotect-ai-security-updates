# Security Review 2.1.0-beta2.3

## Scope

This update separates request signature matching from deterministic risk scoring.

## Safety properties

- No external AI or third-party scoring service is called.
- Existing detector weights and block/log thresholds are preserved.
- Multiple primary attack signatures use the highest primary score, matching prior behaviour.
- Context signals are added and the final score is clamped to 0–100.
- No database schema, stored setting, notification, queue, or baseline format changes.
- No automatic file modification, deletion, quarantine, or repair was added.

## New output fields

The detector now also returns:

- `level`: low, medium, high, or critical.
- `components`: the matched score components used for diagnostics and tests.

Existing callers continue to use `score`, `reasons`, and `bot` unchanged.
