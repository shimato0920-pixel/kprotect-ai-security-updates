# KProtect AI Security v3.0.0-rc1 Security Review

## Scope

This release candidate focuses on performance, accessibility, UI consistency, and publication readiness.

## Data handling

- AI Security Analyst uses aggregate counts and anonymous source hashes.
- No raw IP address, request body, password, cookie, or file content is sent externally.
- AI Rule Builder remains local and only permits allow-listed fields, operators, and safe actions.
- No automatic file deletion, quarantine, or repair is performed.

## Access control

- Administration pages require `manage_options`.
- State-changing operations remain protected by WordPress nonces.
- CSV export excludes raw sensitive request data.

## Performance

- Analyst aggregation is cached for 60 seconds.
- The cache is invalidated after a security log write or cleanup.
- Existing database schema is unchanged.

## Upgrade safety

- Settings, security logs, notifications, AI rules, queue records, and integrity baselines are retained.
- No destructive migration is included.
