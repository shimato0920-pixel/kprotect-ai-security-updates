# Security Review 2.2.0-alpha1

## Scope

Adds a deterministic site-wide local security assessment to the existing dashboard aggregates.

## Privacy

- No external AI API is called.
- Raw IP addresses, request paths, request bodies, passwords, form values, and file contents are not transmitted.
- The engine receives only aggregate timeline/type data and already-normalized recent event records.

## Change safety

- No database schema changes.
- No option migrations.
- No new cron events.
- No changes to blocking thresholds or firewall behavior.
- Existing settings, logs, notification queues, and integrity baselines are preserved.

## Rollback

Remove `class-kprotect-ai-engine.php`, its `require_once`, and the `intelligence` field in the dashboard snapshot. No data rollback is required.
