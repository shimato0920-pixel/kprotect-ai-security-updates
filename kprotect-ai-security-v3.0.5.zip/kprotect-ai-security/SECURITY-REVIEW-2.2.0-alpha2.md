# Security Review 2.2.0-alpha2

## Scope

Explainable local AI advisor improvements.

## Changes

- Added up to three event-specific administrator actions.
- Added confidence labels based on the amount of local evidence.
- Prioritized unblocked high-risk events.
- Kept all analysis local and deterministic.

## Unchanged security boundaries

- No external AI API or telemetry.
- No automatic blocking or file deletion.
- No database schema changes.
- Existing firewall thresholds and notification rules are unchanged.

## Verification

- PHP syntax checked across all PHP files.
- AI engine exercised with empty and high-risk aggregate fixtures.
- ZIP integrity checked after packaging.
- Final PHPUnit, PHPCS, and PHPStan verdict is delegated to GitHub Actions.
