# AGENTS.md

## Project

KProtect AI Security is a WordPress security plugin.

Current development version: `2.1.0-beta1`

## Supported environment

- WordPress 6.4 or later
- PHP 8.0 or later
- License: GPL-2.0-or-later
- Text domain: `kprotect-ai-security`

## Core principles

1. Security detections must be explainable.
2. File scanning must remain read-only unless a future feature is explicitly approved.
3. Never delete, edit, quarantine, or repair files automatically.
4. Do not transmit raw IP addresses, request paths, request bodies, passwords, form values, or file contents to external AI services.
5. Preserve existing settings, logs, notifications, feedback, delivery history, queue data, and scan baselines during upgrades.
6. Use WordPress capability checks, nonces, sanitization, validation, and output escaping.
7. Prefer WordPress APIs over direct database access when practical.
8. Any intentional direct database access must use prepared queries and include a code comment explaining why it is needed.
9. New outbound notification channels must not expose sensitive request data.
10. Beta and prerelease builds must not be described as stable releases.

## Version consistency

Whenever the version changes, update all applicable locations:

- Plugin header in `kprotect-ai-security.php`
- `KPROTECT_VERSION`
- `Stable tag` in `readme.txt`
- Changelog entries
- Release notes
- Git tag, prefixed with `v`

The Git tag must match the plugin version exactly.

Example:

- Plugin version: `2.1.0-beta2`
- Git tag: `v2.1.0-beta2`

## Required checks before release

- PHP syntax checks for PHP 8.0 through 8.4
- PHPUnit
- Installable ZIP build
- SHA-256 generation
- Manual staging-site test
- Existing settings and data remain intact
- No fatal errors or blank administration pages
- Release ZIP installs as a single `kprotect-ai-security` directory

## Coding rules

- Follow WordPress Coding Standards where practical.
- Use tabs for PHP indentation in WordPress source files.
- Escape output as late as possible.
- Sanitize and validate input before use.
- Use strict comparisons where appropriate.
- Do not weaken security checks merely to silence tests.
- Avoid adding dependencies to the production ZIP unless explicitly approved.
- Keep development-only files out of the installable ZIP.

## Change safety

For changes affecting any of the following, include a migration and rollback assessment:

- Database tables
- Options
- Cron events
- REST routes
- Notification queue behavior
- File-integrity baselines
- Activation or deactivation hooks

## AI assistant instructions

Before editing:

1. Read the affected class and its callers.
2. Identify existing capability, nonce, sanitization, and escaping patterns.
3. Preserve backward compatibility unless the task explicitly allows a breaking change.
4. Keep changes focused.
5. Do not invent files, methods, database columns, or settings that are not present.
6. State any assumptions.
7. Add or update tests when behavior changes.
