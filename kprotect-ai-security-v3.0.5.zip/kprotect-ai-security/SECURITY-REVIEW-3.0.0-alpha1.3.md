# Security Review 3.0.0-alpha1.3

## Scope

Notification Center workflow refactor.

## Controls

- All state-changing notification operations use POST.
- `manage_options` capability is required.
- WordPress nonces protect every operation.
- Feedback and read state are updated in one database operation.
- Bulk deletion is restricted to read or administrator-classified notifications.
- No security log, firewall rule, integrity baseline, or external service configuration is modified.

## Data model

The existing `status` and `feedback_status` columns remain separate. The UI derives workflow state as follows:

- Pending: unread and not classified.
- Processed: read or classified by an administrator.

No database schema migration is required.
