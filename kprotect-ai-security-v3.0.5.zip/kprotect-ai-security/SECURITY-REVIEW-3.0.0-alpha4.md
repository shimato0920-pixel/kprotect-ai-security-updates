# Security Review 3.0.0-alpha4

- Rule Builder actions require `manage_options`.
- Every mutation uses a WordPress nonce.
- New rules are always saved disabled.
- Enabling a rule does not permit IP blocking, file deletion, quarantine, or settings mutation.
- Fields, operators, and actions are validated against allowlists.
- Rule data remains local in the `kprotect_ai_rules` option.
