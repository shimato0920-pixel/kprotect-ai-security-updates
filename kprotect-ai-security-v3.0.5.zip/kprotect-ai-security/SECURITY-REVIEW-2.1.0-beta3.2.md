# Security Review 2.1.0-beta3.2

- Added deterministic event-level guidance to stored security logs.
- No external AI API or telemetry was added.
- Query strings are removed before a request path is displayed in the advisor.
- The advisor never deletes, quarantines, modifies, or blocks files or requests.
- Existing detection rules, risk scores, blocking thresholds, database schema, and notification behavior are unchanged.
- Advice explicitly avoids claiming that a single event proves compromise.
