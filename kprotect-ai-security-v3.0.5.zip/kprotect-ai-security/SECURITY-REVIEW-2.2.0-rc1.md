# Security Review 2.2.0-rc1

## Scope

- SOC-style dashboard layout
- Local AI confidence percentage
- Aggregate incident CSV export
- Dark-mode and high-contrast administration styles

## Security properties

- CSV export requires `manage_options` and a valid nonce.
- Export contains aggregate incident data only.
- Raw IP addresses, request paths, request bodies, passwords, and file contents are excluded.
- No external AI service or external API is contacted.
- No automatic blocking, file modification, quarantine, or baseline update was added.
- Database schema and stored data formats are unchanged.

## Rollback

The release can be rolled back to v2.2.0-beta1 without a database migration.
