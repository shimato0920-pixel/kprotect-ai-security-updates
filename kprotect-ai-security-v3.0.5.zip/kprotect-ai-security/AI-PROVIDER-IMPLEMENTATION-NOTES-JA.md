# AI Provider基盤 実装メモ

## 今回の範囲

- AI Provider Interface
- Local Rule Engine用アダプター
- Provider Manager
- 登録プロバイダーの検証
- 選択プロバイダーの解決
- 利用不能・例外発生時のローカルフォールバック
- AI Assistantの呼び出しをProvider Manager経由へ変更

## 今回追加しないもの

- OpenAI、Gemini、Claude、Ollamaへの通信
- APIキー保存
- 外部AI設定画面
- 外部AIへの自動送信
- 自動遮断・設定変更

## 次のPR

この基盤がCIを通過した後、外部プロバイダーは個別のfeatureブランチで追加します。
各外部プロバイダーには、明示的な管理者同意、タイムアウト、送信データ最小化、秘密情報の秘匿、ローカルフォールバック試験が必要です。
