# Contributing to KProtect AI Security

Thank you for helping improve KProtect AI Security.

## Branches

- `main`: releasable and tested code
- `develop`: integration branch for the next version
- `feature/*`: focused feature development
- `fix/*`: non-urgent bug fixes
- `hotfix/*`: urgent fixes based on the current stable release

Do not commit unfinished experimental work directly to `main`.

## Development workflow

1. Create or choose an Issue.
2. Create a focused branch.
3. Make the smallest safe change.
4. Add or update tests.
5. Run local checks where available.
6. Push the branch.
7. Open a Pull Request.
8. Confirm GitHub Actions.
9. Test on a staging WordPress site.
10. Merge only after review.

## Commit messages

Use short imperative messages.

Examples:

- `Fix notification queue card wrapping`
- `Add read-only integrity REST endpoint`
- `Preserve delivery history during upgrade`

Avoid vague messages such as:

- `Update`
- `Fix stuff`
- `Changes`

## Pull Requests

A Pull Request should explain:

- What changed
- Why it changed
- Security impact
- Data migration impact
- How it was tested
- Screenshots for administration UI changes
- Rollback considerations

## Security-sensitive contributions

Do not include:

- Real webhook URLs
- Passwords
- Application Passwords
- API keys
- Real user IP addresses
- Production database exports
- Private security logs
- Customer or site-identifying data

Use sanitized test fixtures.

## Testing

At minimum, confirm:

- PHP syntax checks pass
- PHPUnit passes
- Installable ZIP is generated
- Plugin activates on staging
- Existing settings remain
- No fatal errors are produced

For UI changes, test common WordPress administration widths.

For REST API changes, test both authorized and unauthorized requests.

For notification changes, test success, failure, retry, and privacy behavior.

## Coding standards

PHPCS and PHPStan are currently advisory during the beta phase. Their findings should be reduced gradually and must not be ignored when they indicate a real security or correctness problem.

## Release process

1. Update the version consistently.
2. Update `readme.txt` and release notes.
3. Merge tested changes.
4. Create a matching Git tag.
5. Push the tag.
6. Confirm the GitHub Release contains:
   - Installable ZIP
   - SHA-256 checksum
7. Test the generated ZIP on staging.
