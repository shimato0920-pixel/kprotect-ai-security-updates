# Security Review 3.0.0-alpha1.4

- Dedicated `admin_post_kprotect_delete_processed_notifications` action.
- `manage_options` capability check.
- Dedicated nonce verification.
- POST-only destructive operation with confirmation.
- Existing notification records only; no schema change.
- Database failures are reported instead of being treated as success.
