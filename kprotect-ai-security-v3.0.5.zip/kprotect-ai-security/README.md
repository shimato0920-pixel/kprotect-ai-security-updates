# KProtect AI Security

KProtect AI Security is a local-first WordPress security plugin for request monitoring, login protection, temporary IP blocking, file-integrity monitoring, notifications, incident review, AI rules, and explainable security guidance.

## v3.0.0

RC2 freezes the version 3 feature set after successful RC1 testing and prepares the package for final release review.

Included version 3 features:

- Local AI Security Analyst
- Japanese AI Rule Builder with safe disabled-by-default rules
- Prioritized AI Incident Queue and 24-hour Incident Report
- Local AI Assistant with explainable evidence and cautions
- Pending and processed notification workflow
- Security log explanations
- File-integrity and uploads monitoring
- Privacy-preserving aggregate CSV export
- Responsive, dark-mode, high-contrast, and reduced-motion administration UI

The local AI features are deterministic and read-only. They do not send logs, IP addresses, request paths, passwords, form values, cookies, or file contents to an external AI service.

## Requirements

- WordPress 6.4 or later
- PHP 8.0 or later

## Safety behavior

- File scanning is read-only.
- Files are never deleted, repaired, or quarantined automatically.
- New AI rules are saved disabled and require administrator review.
- Existing settings, logs, notification history, rules, queue data, and integrity baselines are retained during upgrades.
- Uninstalling the plugin does not automatically delete stored KProtect data.

## Documentation

- [Japanese installation and initial setup](INSTALL-GUIDE-JA.md)
- [Japanese FAQ](FAQ-JA.md)
- [Japanese troubleshooting](TROUBLESHOOTING-JA.md)
- [RC2 final test checklist](RC2-TESTING-JA.md)
- [Changelog](CHANGELOG.md)
- [Security policy](SECURITY.md)

## License

GPL-2.0-or-later.
