# Security and Code Quality Review 2.1.0-beta2.2

## Scope

This maintenance build focuses on notification queue code quality and safe custom-table access.

## Changes

- Refactored compact one-line queue methods into readable methods.
- Prepared the numeric LIMIT used by queue history retrieval.
- Added short-lived object-cache entries for queue counts and statistics.
- Invalidated queue caches after writes and processing.
- Added documented PHPCS exceptions for intentional access to KProtect-owned custom tables.
- Standardized `wp_unslash()` usage for the log minimum-risk filter.

## Compatibility

- No schema changes.
- No option migrations.
- No notification-rule changes.
- Existing logs, queue data, delivery history, settings, and integrity baselines are preserved.
