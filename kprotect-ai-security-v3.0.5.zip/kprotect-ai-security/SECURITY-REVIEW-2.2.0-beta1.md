# Security Review: 2.2.0-beta1

## Added

- Local AI Assistant on the dashboard.
- Administrator-only AJAX endpoint protected by nonce and capability checks.
- Deterministic topic detection for priority, 24-hour report, files, login, firewall, and false-positive questions.
- Separate factual evidence, assessment, recommended actions, confidence, and caution.

## Privacy and safety

- No external AI or external API calls.
- Does not return request bodies, passwords, raw file contents, or query strings.
- Does not modify settings, block IPs, update baselines, delete files, or quarantine files.
- Answers are decision support and do not claim that a site is safe or compromised.

## Compatibility

- No database schema changes.
- Existing settings, logs, notification data, delivery history, queues, and integrity baselines are preserved.
