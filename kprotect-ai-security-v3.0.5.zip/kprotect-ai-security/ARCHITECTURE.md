# KProtect AI Security Architecture

## Overview

KProtect AI Security is a local-first WordPress security plugin. It monitors requests and login behavior, calculates explainable risk scores, records security events, provides notifications and reports, and performs read-only file-integrity checks.

The main bootstrap file is:

`kprotect-ai-security.php`

It defines project constants, loads required classes, registers activation/deactivation hooks, adds the Plugins-screen settings link, and starts the plugin.

## Main areas

### Bootstrap and lifecycle

- `kprotect-ai-security.php`
- `includes/class-kprotect-installer.php`
- `includes/class-kprotect-plugin.php`
- `uninstall.php`

Responsibilities:

- Constants
- Class loading
- Activation/deactivation
- Cron registration
- Database setup
- Main hook registration
- Safe uninstall behavior

Uninstall intentionally does not automatically remove logs and settings.

### Detection and protection

Representative classes:

- `class-kprotect-detector.php`
- `class-kprotect-firewall.php`
- `class-kprotect-rate-limiter.php`
- `class-kprotect-login-guard.php`
- `class-kprotect-ip-blocker.php`

Responsibilities:

- Request analysis
- Explainable risk scoring
- Login protection
- Rate limiting
- Temporary blocking

Protection changes must avoid locking administrators out without a recovery path.

### Logging and notifications

Representative classes:

- `class-kprotect-logger.php`
- `class-kprotect-notification-center.php`
- `class-kprotect-notification-rules.php`
- `class-kprotect-notifier.php`
- `class-kprotect-notification-queue.php`
- `class-kprotect-delivery-history.php`
- Discord, Slack, and generic webhook notifiers

Responsibilities:

- Local event storage
- Notification aggregation
- Delivery queueing and retries
- Delivery history
- Privacy-preserving external messages

External notifications must not include sensitive request content.

### File integrity and scanning

Representative classes:

- `class-kprotect-integrity-scanner.php`
- `class-kprotect-file-integrity-manager.php`
- `class-kprotect-malware-scanner.php`

Responsibilities:

- WordPress core checks
- Plugin and theme baseline comparison
- Uploads scanning
- Added, modified, and missing file detection
- Approved-change handling

All scanning remains read-only. Detection must not trigger automatic file modification.

### Administration and reporting

Representative classes:

- `admin/class-kprotect-admin.php`
- `class-kprotect-dashboard-analytics.php`
- `class-kprotect-security-report.php`
- `class-kprotect-incident-center.php`
- `class-kprotect-security-assistant.php`
- `class-kprotect-maintenance-manager.php`

Responsibilities:

- Administration menus and screens
- Dashboard summaries
- Reports
- Incident workflows
- Plain-language security guidance
- Maintenance and load visibility

All administration actions require appropriate capabilities and nonces.

### REST API

- `class-kprotect-rest-api.php`

Current principles:

- Read-only foundation
- Disabled by default
- Administrator-only access
- No raw IP addresses
- No request bodies
- No passwords
- No raw file contents
- Integrity endpoints return summaries rather than sensitive paths where possible

## Data compatibility

Updates must preserve:

- Settings
- Logs
- Notifications
- Feedback
- Delivery history
- Queue data
- Scan baselines

Schema changes require versioned migrations and must be idempotent.

## Packaging

The installable ZIP must contain one top-level directory:

`kprotect-ai-security/`

Development-only files are excluded, including:

- `.git`
- `.github`
- `tests`
- `vendor`
- Composer configuration
- PHPCS/PHPStan/PHPUnit configuration

## Future Cloud integration

Cloud integration must be opt-in and privacy-preserving.

Before transmitting any site data, define:

- Exact fields
- Purpose
- Authentication
- Encryption
- Retention period
- Deletion process
- Administrator consent
- Failure behavior

The local plugin must remain functional when Cloud connectivity is unavailable.
