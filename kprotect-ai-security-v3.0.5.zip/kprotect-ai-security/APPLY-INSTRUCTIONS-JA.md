# RC3.3 適用手順

`feature/ai-provider`ブランチ上で、このオーバーレイの内容をリポジトリ直下へ上書きしてください。

対象ページ：
- 改ざん検知
- ファイル整合性
- uploads高度スキャン
- 保守・負荷

コミット例：

`Migrate legacy security pages to Admin UI 1.0 for RC3.3`
