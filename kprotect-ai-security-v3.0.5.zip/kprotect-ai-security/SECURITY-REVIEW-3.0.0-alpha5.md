# Security Review 3.0.0-alpha5

- Historical rule tests are read-only and query at most 1,000 recent aggregate log rows.
- Test output excludes IP addresses, request paths, request bodies, passwords, and file contents.
- New rules remain disabled when saved.
- Duplicate detection compares normalized rule conditions and windows only.
- No automatic blocking, deletion, quarantine, or settings modification was added.
