# Security Review: v3.0.0-alpha1 AI Provider Foundation

## Scope

This change introduces a provider interface, provider manager, and local-provider adapter.
It does not add an external AI connection.

## Security properties

- The local provider remains the default and unconditional fallback.
- Provider selection is restricted to registered provider identifiers.
- Invalid or unavailable providers fall back to the local engine.
- Provider exceptions are not exposed to administrators or site visitors.
- The provider API receives normalized intelligence only.
- Raw passwords, cookies, request bodies, and file contents are outside the provider contract.
- No firewall, blocking, notification, database, or file-integrity behavior is changed.

## Future provider requirements

Every external provider must add:

- explicit administrator opt-in;
- secret storage and redaction review;
- strict timeout and response-size limits;
- data-minimization documentation;
- local fallback tests;
- nonce and capability checks for settings changes;
- provider-specific security review.
