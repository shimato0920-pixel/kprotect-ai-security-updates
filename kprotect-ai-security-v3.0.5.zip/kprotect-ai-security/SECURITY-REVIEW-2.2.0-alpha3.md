# Security Review 2.2.0-alpha3

## Scope

This alpha adds explainable evidence and cautious likelihood text to the local AI dashboard assessment.

## Security properties

- Uses only already-normalized local dashboard aggregates.
- Does not transmit logs, IP addresses, paths, or file contents.
- Does not change firewall rules, block thresholds, database schema, or notification conditions.
- Does not automatically approve integrity changes or update the integrity baseline.
- Maintenance likelihood is advisory and explicitly requires comparison with WordPress update history.

## Review notes

The maintenance heuristic only looks for normalized words such as plugin, modified, and added in recent local reason labels. It must not be treated as proof that a change is safe.
