# Security Review 3.0.0-alpha2

- Purge remains restricted to manage_options.
- Request remains protected by a WordPress nonce.
- Only processed notification IDs are deleted.
- Result data is stored in a short-lived, user-specific transient.
- No database schema changes.
