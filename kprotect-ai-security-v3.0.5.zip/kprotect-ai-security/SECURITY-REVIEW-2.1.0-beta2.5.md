# Security Review 2.1.0-beta2.5

This release changes administrator-facing log presentation only.

- Japanese file-integrity explanations.
- Risk, event, and enforcement badges.
- Expandable evidence and recommendation panels.
- No rule, threshold, schema, telemetry, or external AI changes.
