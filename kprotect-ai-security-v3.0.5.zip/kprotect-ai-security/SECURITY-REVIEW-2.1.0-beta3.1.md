# Security review: 2.1.0-beta3.1

## Scope

This maintenance update focuses on dashboard query efficiency and coding-quality hygiene.

## Changes

- Dashboard snapshots use the WordPress object cache for 15 seconds.
- Direct reads are limited to the plugin-owned `kprotect_logs` table and are documented for PHPCS.
- No detection rule, blocking threshold, database schema, notification condition, or stored log is changed.
- No security data is transmitted to external AI services.
- macOS metadata files are excluded from generated packages.

## Validation

- PHP syntax checked for all plugin PHP files.
- Dashboard intelligence tests expanded for safe, watch, critical, and file-integrity label behavior.
- ZIP integrity checked after packaging.
