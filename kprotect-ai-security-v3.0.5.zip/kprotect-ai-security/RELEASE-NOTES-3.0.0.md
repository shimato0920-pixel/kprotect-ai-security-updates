# KProtect AI Security v3.0.0

KProtect AI Security v3.0.0 is the first stable release of the v3 series.

## Highlights

- Local AI Security Analyst
- AI Rule Builder with Japanese natural-language drafting
- Rule preview, save, edit, enable/disable, duplicate detection, and historical log testing
- AI Incident Queue and AI Incident Report
- Notification Center workflow with processed-history management
- Security logs with explainable event summaries
- File integrity and tamper detection
- Uploads advanced scan
- Security diagnostics
- Maintenance and performance tools
- Admin UI 1.0 with responsive light/dark mode support
- Privacy-preserving aggregate CSV export

## Privacy and safety

- Local-first analysis
- No external AI service is required
- No raw IP addresses, passwords, request bodies, cookies, or file contents are sent externally
- New AI rules are saved disabled by default
- Rule Builder does not automatically block IPs, delete files, quarantine files, or change WordPress settings

## Compatibility

- WordPress 6.4 or later
- PHP 8.0–8.4
