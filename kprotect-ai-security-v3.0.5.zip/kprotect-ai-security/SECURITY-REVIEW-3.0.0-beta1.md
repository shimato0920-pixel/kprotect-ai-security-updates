# Security Review: 3.0.0-beta1

## Scope

AI Security Analyst trend improvements and dashboard presentation.

## Safety properties

- Analysis is read-only.
- No external AI or telemetry request is performed.
- Repeated-source analysis uses stored one-way IP hashes only.
- Raw IP addresses, request paths, bodies, passwords, cookies, and file contents are not included in analyst output.
- No firewall rule, block entry, WordPress setting, or file is changed by the analyst.
- Queries are aggregate or grouped queries over the existing KProtect log table.

## Review result

No new automatic enforcement capability was introduced. Administrator review remains required for every recommendation.
