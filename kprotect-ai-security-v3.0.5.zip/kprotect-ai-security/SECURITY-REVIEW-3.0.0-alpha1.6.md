# Security Review 3.0.0-alpha1.6

- Processed-notification deletion uses a dedicated WordPress `admin-post.php` action.
- The UI invokes the action through a nonce-protected URL.
- `manage_options` capability remains required.
- The redirect reports deleted row count or database failure.
- No database schema changes are introduced.
