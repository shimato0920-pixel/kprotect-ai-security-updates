# Security Review 3.0.0-alpha1.1

- Notification deletion uses nonce-protected POST.
- `manage_options` remains required.
- Legacy status values are normalized with `LOWER(TRIM(status))`.
- Deleted-row count and database failure are shown to administrators.
- No firewall, AI provider, notification generation, or schema changes.
