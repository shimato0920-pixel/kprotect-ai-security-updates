# KProtect AI Security 3.0.0-alpha1.8

## Notification deletion routing

- Uses a nonce-protected URL on the notification screen itself.
- Requires `manage_options`.
- Avoids JavaScript-only handling, form submission, and `admin-post.php` routing.
- Redirects after deletion and reports whether PHP processing was reached.
- Does not expose SQL queries or database errors to the browser.
