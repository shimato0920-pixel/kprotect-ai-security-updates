<?php declare(strict_types = 1);

// variadic-method-KProtect_Risk_Score_Calculator-level-/Users/yasuterushimato/Documents/GitHub/kprotect-ai-security/includes/class-kprotect-risk-score-calculator.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1785912469-v4',
   'data' => false,
));