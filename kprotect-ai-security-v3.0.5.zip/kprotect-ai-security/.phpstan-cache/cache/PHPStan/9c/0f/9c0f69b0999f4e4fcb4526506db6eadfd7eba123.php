<?php declare(strict_types = 1);

// variadic-function-sanitize_key-/Users/yasuterushimato/Documents/GitHub/kprotect-ai-security/tests/phpstan-bootstrap.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => '1785909459-v4',
   'data' => false,
));