# GitHub開発ファイルの導入手順

このZIPは、KProtect AI Security本体を置き換えるものではありません。
GitHub Desktopが管理している `kprotect-ai-security` フォルダへ、
このZIPを解凍した中身を上書きコピーしてください。

## 追加されるもの

- `.github/workflows/ci.yml`
- `.github/workflows/release.yml`
- `.gitignore`
- `composer.json`
- `phpunit.xml.dist`
- `phpcs.xml.dist`
- `phpstan.neon.dist`
- `tests/`

## Macで隠しファイルが見えない場合

Finderで次を押します。

`Command + Shift + .`

## GitHub Desktop

コピー後、GitHub Desktopで変更を確認します。

Summary:

`Add GitHub development and CI files`

次に:

1. Commit to main
2. Push origin
3. GitHubのActionsを開く

## 最初のCI

- PHP 8.0〜8.4構文チェック: 必須
- PHPUnit: 必須
- PHPCS/PHPStan: 参考チェック
- ZIP/SHA-256生成: 必須

PHPCSとPHPStanは既存コードの改善点を表示しますが、最初はCI全体を失敗させません。
