# Security Review — 2.2.0-alpha6

## Scope

Adds a local 24-hour AI Incident Report with totals, block status, peak hour, top event types, and previous-day comparison.

## Safety

- No external AI or API calls.
- No database schema changes.
- No automatic blocking, approval, quarantine, deletion, or baseline updates.
- Uses local aggregated log data only.
- Existing settings, logs, queues, notifications, and integrity baselines are preserved.
