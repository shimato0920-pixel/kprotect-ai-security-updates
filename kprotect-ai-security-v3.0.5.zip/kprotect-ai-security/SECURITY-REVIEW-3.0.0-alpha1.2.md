# Security Review 3.0.0-alpha1.2

- Notification mutations use POST, nonce verification, and manage_options.
- Administrator feedback marks the notification read in the same database update.
- Read cleanup includes legacy classified notifications whose status was not synchronized.
- Deletion remains limited to read or explicitly classified notification rows.
- No firewall, blocking, external AI, or file-integrity behavior changed.
