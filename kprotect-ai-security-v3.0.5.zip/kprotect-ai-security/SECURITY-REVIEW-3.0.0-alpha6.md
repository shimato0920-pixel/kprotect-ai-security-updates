# Security Review 3.0.0-alpha6

- AI Security Analyst uses local aggregate log data only.
- No external AI or telemetry transmission is added.
- Raw IP addresses, request paths, request bodies, passwords, cookies, and file contents are not included in analyst output.
- Analysis is read-only and does not change blocking rules or delete data.
