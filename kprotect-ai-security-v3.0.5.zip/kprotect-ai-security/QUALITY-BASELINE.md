# KProtect AI Security quality baseline

The project runs PHP syntax checks for PHP 8.0–8.4, PHPUnit, PHPStan, WordPress Coding Standards, and an installable ZIP build in CI.

## PHPCS baseline policy

PHPCBF has normalized the automatically fixable formatting in the current codebase. `phpcs.xml.dist` keeps the remaining legacy findings behind explicit, named exclusions rather than disabling WordPress Coding Standards entirely.

The exclusions currently cover:

- incomplete legacy PHPDoc;
- legacy short ternaries and multi-assignment patterns;
- dynamic plugin-owned database table identifiers that cannot be represented by value placeholders;
- existing nonce, sanitization, and alternative-function findings that require behavior-aware refactoring.

All other WordPress Coding Standards checks remain active. New exclusions should not be added without documenting the reason here. Existing exclusions should be removed incrementally as affected code is refactored and tested.

## Refactoring priority

1. Nonce verification and input sanitization.
2. Prepared SQL and dynamic table-name handling.
3. PHPDoc completeness.
4. Legacy expression cleanup.

This baseline is a CI migration tool, not a claim that excluded findings have been fixed.
