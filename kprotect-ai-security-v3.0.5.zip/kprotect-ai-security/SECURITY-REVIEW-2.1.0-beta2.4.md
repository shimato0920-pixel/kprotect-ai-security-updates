# Security Review 2.1.0-beta2.4

## Scope

- Explainable risk presentation in the dashboard and log table.
- No database schema changes.
- No changes to detection signatures, thresholds, blocking, notifications, or retention.

## Privacy

- Explanations are generated locally from stored reason keys.
- No request data is sent to an external AI service.
- Existing IP and path privacy settings remain unchanged.

## Compatibility

- Older log rows continue to work.
- Unknown reason keys are displayed as humanized informational labels with zero attributed points.
