# Security Review 3.0.0-rc3.3

This release changes administration-page markup and CSS only.

- No database schema changes.
- No firewall, blocking, scanning, or deletion behavior changes.
- Existing capability and nonce checks remain unchanged.
- Dark-mode styling does not expose or transmit data.
- Integrity and malware operations remain administrator-only and read-only unless the administrator explicitly creates a baseline.
