# Security Review 3.0.0-alpha3

- Rule drafts are local and deterministic.
- All saved rules are forced to disabled.
- Only allow-listed fields, operators, and actions are accepted.
- Forms require manage_options and WordPress nonces.
- No automatic IP blocking, file deletion, quarantine, or external AI transmission is implemented.
