# Security Review — 2.1.0-beta3.0

## Scope

- Added a local explainable security assessment to the dashboard.
- Assessment uses only aggregated local log data.
- No request payload, IP address, file content, or other site data is transmitted externally.
- Detection rules, database schema, block thresholds, and notification behavior are unchanged.

## Assessment behavior

The dashboard assessment is deterministic guidance. It summarizes recent maximum risk, high-risk event count, dominant event type, and block rate. It must not be presented as proof that a site is compromised or safe.
