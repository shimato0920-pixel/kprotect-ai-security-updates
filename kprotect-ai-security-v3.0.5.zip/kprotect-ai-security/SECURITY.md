# Security Policy

## Supported versions

Security fixes are prioritized for the latest stable release and the current prerelease branch.

## Reporting a vulnerability

Do not open a public GitHub Issue for a vulnerability that could put sites at risk.

Report privately to the repository owner with:

- Affected version
- Reproduction steps
- Security impact
- Proof of concept using non-production data
- Suggested mitigation, if available

Do not include real passwords, API keys, webhook URLs, user data, production database exports, or private logs.

## Safe testing

Test only on systems you own or are explicitly authorized to assess.

Do not test destructive behavior on production sites.

## Disclosure

Please allow reasonable time to investigate, patch, test, and release a fix before public disclosure.
