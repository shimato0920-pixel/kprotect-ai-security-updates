# Security Review — KProtect AI Security v3.0.0-rc4

## Scope

RC4 is a release-verification build. No new security feature or blocking behavior is introduced.

## Verified locally

- 43 PHP files parse successfully on the available PHP 8.4 runtime.
- No `eval`, `shell_exec`, `exec`, `system`, or `passthru` calls were found in plugin PHP files.
- All registered administrator POST handlers include both a capability check and a nonce check.
- Both registered authenticated AJAX handlers include both a capability check and an AJAX nonce check.
- The installable ZIP uses a single `kprotect-ai-security/` root directory.
- `.DS_Store` and `__MACOSX` entries are excluded from the distribution.
- RC3.3.1 runtime behavior and database schema are intentionally preserved.

## Required project-side gates

- GitHub Actions
- PHPUnit
- PHPStan
- PHPCS
- WordPress Plugin Check
- Update test from the currently deployed RC build
- Final desktop/mobile light/dark-mode smoke test

## Privacy and destructive actions

KProtect's local analysis is intended to remain local and read-only. The scanner does not automatically delete, repair, or quarantine files.
