# Security Review — 2.2.0

## Release scope

Version 2.2.0 promotes the tested RC1 implementation to stable without changing detection rules, blocking thresholds, database schema, notification conditions, or file-modification behavior.

## Privacy

- Local deterministic analysis only.
- No external AI provider communication.
- Aggregate CSV export excludes raw IP addresses, request paths, request bodies, passwords, form values, and file contents.
- CSV export requires administrator capability and nonce verification.

## File safety

- Integrity and malware scanning remain read-only.
- No automatic deletion, repair, quarantine, or integrity-baseline approval.

## Upgrade safety

Existing settings, logs, notification history, delivery queue data, feedback, and integrity baselines are retained.
