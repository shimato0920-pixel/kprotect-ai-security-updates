<?php
/**
 * Uninstall handler for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// 安全のため、アンインストール時もログと設定は自動削除しません。
// 完全削除する場合は、管理者がデータベースから kprotect_* を削除してください。
// セキュリティログは初期設定では保持します。
