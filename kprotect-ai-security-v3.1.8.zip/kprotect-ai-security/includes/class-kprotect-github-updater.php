<?php
/**
 * Public update repository updater.
 *
 * @package KProtect_AI_Security
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class KProtect_GitHub_Updater {

	private const UPDATE_JSON_URL = 'https://raw.githubusercontent.com/shimato0920-pixel/kprotect-ai-security-updates/main/latest.json';

	private string $plugin_file;
	private string $plugin_basename;
	private string $slug;

	public function __construct( string $plugin_file ) {
		$this->plugin_file     = $plugin_file;
		$this->plugin_basename = plugin_basename( $plugin_file );
		$this->slug            = dirname( $this->plugin_basename );
	}

	public function hooks(): void {
		add_filter(
			'pre_set_site_transient_update_plugins',
			array( $this, 'check_update' )
		);

		add_filter(
			'plugins_api',
			array( $this, 'plugin_information' ),
			20,
			3
		);

		add_filter(
			'upgrader_source_selection',
			array( $this, 'fix_package_folder' ),
			10,
			4
		);
	}
	public function check_update( $transient ) {

		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		$release = $this->get_latest_release();

		if ( ! $release ) {
			return $transient;
		}

		$latest_version = $release['version'];

		if ( ! version_compare( KPROTECT_VERSION, $latest_version, '<' ) ) {
			return $transient;
		}

		$update = (object) array(
			'id'           => 'kprotect-ai-security',
			'slug'         => $this->slug,
			'plugin'       => $this->plugin_basename,
			'new_version'  => $latest_version,
			'url'          => '',
			'package'      => $release['download_url'],
			'icons'        => array(),
			'banners'      => array(),
			'banners_rtl'  => array(),
			'tested'       => '',
			'requires_php' => '8.0',
		);

		$transient->response[ $this->plugin_basename ] = $update;

		return $transient;
	}

	public function plugin_information( $result, string $action, object $args ) {

		if ( 'plugin_information' !== $action ) {
			return $result;
		}

		if ( empty( $args->slug ) || $this->slug !== $args->slug ) {
			return $result;
		}

		$release = $this->get_latest_release();

		if ( ! $release ) {
			return $result;
		}

		return (object) array(
			'name'          => $release['name'],
			'slug'          => $this->slug,
			'version'       => $release['version'],
			'author'        => 'KProtect',
			'homepage'      => '',
			'requires'      => '6.4',
			'requires_php'  => '8.0',
			'download_link' => $release['download_url'],
			'sections'      => array(
				'description' =>
					'KProtect AI Security provides WordPress firewall, login protection, risk scoring, security monitoring, malware scanning, and file integrity features.',
			),
		);
	}

	public function fix_package_folder(
		string $source,
		string $remote_source,
		$upgrader,
		array $hook_extra
	): string {

		if (
			empty( $hook_extra['plugin'] ) ||
			$this->plugin_basename !== $hook_extra['plugin']
		) {
			return $source;
		}

		$expected = trailingslashit( $remote_source ) . $this->slug . '/';

		if ( $source === $expected ) {
			return $source;
		}

		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			return $source;
		}

		if ( $wp_filesystem->exists( $expected ) ) {
			$wp_filesystem->delete( $expected, true );
		}

		if ( ! $wp_filesystem->move( $source, $expected, true ) ) {
			return $source;
		}

		return $expected;
	}

	private function get_latest_release(): ?array {

		$cache_key = 'kprotect_public_update_release';

		$force_check = is_admin() && isset( $_GET['force-check'] );

		if ( $force_check ) {
			delete_site_transient( $cache_key );
		} else {
			$cached = get_site_transient( $cache_key );

			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$response = wp_remote_get(
			self::UPDATE_JSON_URL,
			array(
				'timeout' => 10,
				'headers' => array(
					'Accept'     => 'application/json',
					'User-Agent' => 'KProtect-AI-Security/' . KPROTECT_VERSION,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return null;
		}

		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$data = json_decode(
			wp_remote_retrieve_body( $response ),
			true
		);

		if (
			! is_array( $data ) ||
			empty( $data['version'] ) ||
			empty( $data['download_url'] )
		) {
			return null;
		}

		$release = array(
			'name'         =>
				isset( $data['name'] )
					? sanitize_text_field( (string) $data['name'] )
					: 'KProtect AI Security',

			'version'      =>
				sanitize_text_field( (string) $data['version'] ),

			'download_url' =>
				esc_url_raw( (string) $data['download_url'] ),

			'sha256_url'   =>
				isset( $data['sha256_url'] )
					? esc_url_raw( (string) $data['sha256_url'] )
					: '',
		);

		set_site_transient(
			$cache_key,
			$release,
			HOUR_IN_SECONDS
		);

		return $release;
	}
}
