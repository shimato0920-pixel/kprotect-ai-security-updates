<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Utils {
	public static function settings(): array {
		return wp_parse_args( (array) get_option( 'kprotect_settings', array() ), KProtect_Installer::defaults() );
	}

	public static function client_ip(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	public static function has_valid_client_ip( string $ip ): bool {
		return '' !== $ip && false !== filter_var( $ip, FILTER_VALIDATE_IP );
	}

	public static function ip_hash( string $ip ): string {
		return hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) );
	}

	public static function lines( string $value ): array {
		$items = preg_split( '/[\r\n,]+/', $value ) ?: array();
		return array_values( array_filter( array_map( 'trim', $items ) ) );
	}

	public static function ip_matches( string $ip, string $rule ): bool {
		if ( ! self::has_valid_client_ip( $ip ) ) {
			return false; }
		if ( $ip === $rule ) {
			return true; }
		if ( false === strpos( $rule, '/' ) ) {
			return false; }
		list( $subnet, $bits ) = array_pad( explode( '/', $rule, 2 ), 2, null );
		$ip_bin                = inet_pton( $ip );
		$subnet_bin            = inet_pton( (string) $subnet );
		if ( false === $ip_bin || false === $subnet_bin || strlen( $ip_bin ) !== strlen( $subnet_bin ) ) {
			return false; }
		$bits = (int) $bits;
		$max  = strlen( $ip_bin ) * 8;
		if ( $bits < 0 || $bits > $max ) {
			return false; }
		$bytes     = intdiv( $bits, 8 );
		$remainder = $bits % 8;
		if ( substr( $ip_bin, 0, $bytes ) !== substr( $subnet_bin, 0, $bytes ) ) {
			return false; }
		if ( 0 === $remainder ) {
			return true; }
		$mask = ( 0xFF << ( 8 - $remainder ) ) & 0xFF;
		return ( ord( $ip_bin[ $bytes ] ) & $mask ) === ( ord( $subnet_bin[ $bytes ] ) & $mask );
	}

	public static function is_trusted( string $ip ): bool {
		if ( ! self::has_valid_client_ip( $ip ) ) {
			return false; }
		foreach ( self::lines( (string) self::settings()['trusted_ips'] ) as $rule ) {
			if ( self::ip_matches( $ip, $rule ) ) {
				return true; }
		}
		return false;
	}

	public static function sanitize_excluded_paths( string $value ): string {
		$clean = array();

		foreach ( self::lines( sanitize_textarea_field( $value ) ) as $rule ) {
			$rule = trim( $rule );

			if ( '' === $rule || '/' === $rule || '/' !== $rule[0] ) {
				continue;
			}

			$path = wp_parse_url( $rule, PHP_URL_PATH );

			if ( ! is_string( $path ) || '' === $path || '/' === $path ) {
				continue;
			}

			$clean[] = $path;
		}

		return implode( "\n", array_values( array_unique( $clean ) ) );
	}
	public static function path_matches_exclusion(
		string $request_target,
		string $rule
	): bool {
		$request_path = wp_parse_url( $request_target, PHP_URL_PATH );
		$request_path = is_string( $request_path ) && '' !== $request_path
			? $request_path
			: '/';

		$rule = trim( $rule );

		if ( '' === $rule || '/' !== $rule[0] ) {
			return false;
		}

		$rule_path = wp_parse_url( $rule, PHP_URL_PATH );
		$rule_path = is_string( $rule_path ) && '' !== $rule_path
			? $rule_path
			: '';

		if ( '' === $rule_path || '/' === $rule_path ) {
			return false;
		}

		if ( str_ends_with( $rule_path, '/' ) ) {
			return str_starts_with( $request_path, $rule_path );
		}

		return $request_path === $rule_path;
	}
	public static function is_excluded_path( ?string $request_target = null ): bool {
		if ( null === $request_target ) {
			$request_target = self::current_request_target();
		}

		$rules = self::lines(
			(string) ( self::settings()['excluded_paths'] ?? '' )
		);

		foreach ( $rules as $rule ) {
			if ( self::path_matches_exclusion( $request_target, $rule ) ) {
				return true;
			}
		}

		return false;
	}
	public static function current_request_target(): string {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- The raw request target is intentionally inspected for encoded attack patterns; it is unslashed, length-bounded, parsed, and never rendered directly.
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		return substr( is_string( $uri ) ? $uri : '/', 0, 4000 );
	}

	public static function current_inspection_target(): string {
		$uri   = self::current_request_target();
		$parts = wp_parse_url( $uri );
		$path  = isset( $parts['path'] ) ? (string) $parts['path'] : '/';

		if ( empty( $parts['query'] ) ) {
			return substr( $path, 0, 4000 );
		}

		parse_str( (string) $parts['query'], $query );
		$query   = self::redact_sensitive_inspection_values( is_array( $query ) ? $query : array() );
		$encoded = http_build_query( $query, '', '&', PHP_QUERY_RFC3986 );

		return substr( $path . ( '' !== $encoded ? '?' . $encoded : '' ), 0, 4000 );
	}

	public static function current_post_inspection_target(): string {
		$request_method = isset( $_SERVER['REQUEST_METHOD'] )
			? strtoupper( sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) )
			: '';

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Firewall inspection reads untrusted request data without modifying state.
		if ( 'POST' !== $request_method || empty( $_POST ) || ! is_array( $_POST ) ) {
			return '';
		}

		$post = wp_unslash( $_POST );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$post = self::redact_sensitive_inspection_values( is_array( $post ) ? $post : array() );

		$encoded = http_build_query( $post, '', '&', PHP_QUERY_RFC3986 );

		return substr( $encoded, 0, 4000 );
	}

	public static function is_json_request(): bool {
		$content_type = isset( $_SERVER['CONTENT_TYPE'] )
			? strtolower( sanitize_text_field( wp_unslash( $_SERVER['CONTENT_TYPE'] ) ) )
			: '';

		return str_contains( $content_type, 'application/json' );
	}

	public static function current_json_inspection_target( ?string $raw_body = null ): string {
		if ( ! self::is_json_request() || is_user_logged_in() ) {
			return '';
		}

		if ( null === $raw_body ) {
			$raw_body = file_get_contents( 'php://input', false, null, 0, 4000 );

			if ( false === $raw_body ) {
				return '';
			}
		}

		return self::json_inspection_target( substr( $raw_body, 0, 4000 ) );
	}

	public static function json_inspection_target( string $json ): string {
		if ( '' === trim( $json ) ) {
			return '';
		}

		$data = json_decode( $json, true );

		if ( ! is_array( $data ) ) {
			return '';
		}

		$data = self::redact_sensitive_inspection_values( $data );

		$encoded = http_build_query( $data, '', '&', PHP_QUERY_RFC3986 );

		return substr( $encoded, 0, 4000 );
	}

	public static function current_path(): string {
		$uri   = self::current_request_target();
		$parts = wp_parse_url( $uri );
		$path  = isset( $parts['path'] ) ? (string) $parts['path'] : '/';
		if ( empty( $parts['query'] ) ) {
			return substr( $path, 0, 2000 ); }

		parse_str( (string) $parts['query'], $query );
		$query   = self::redact_sensitive_values( is_array( $query ) ? $query : array() );
		$encoded = http_build_query( $query, '', '&', PHP_QUERY_RFC3986 );
		return substr( $path . ( '' !== $encoded ? '?' . $encoded : '' ), 0, 2000 );
	}

	private static function redact_sensitive_inspection_values( array $value ): array {
		$sensitive = array(
			'password',
			'pass',
			'pwd',
			'token',
			'access_token',
			'refresh_token',
			'jwt',
			'secret',
			'client_secret',
			'credential',
			'key',
			'api_key',
			'apikey',
			'nonce',
			'authorization',
			'bearer',
			'auth',
			'session',
			'code',
		);

		$out = array();

		foreach ( $value as $key => $item ) {
			$normalized   = strtolower( preg_replace( '/[^a-z0-9_]/i', '', (string) $key ) );
			$is_sensitive = false;

			foreach ( $sensitive as $needle ) {
				if ( $normalized === $needle || str_ends_with( $normalized, '_' . $needle ) ) {
					$is_sensitive = true;
					break;
				}
			}

			if ( $is_sensitive ) {
				$out[ $key ] = '[redacted]';
				continue;
			}

			if ( is_array( $item ) ) {
				$out[ $key ] = self::redact_sensitive_inspection_values( $item );
				continue;
			}

			$out[ $key ] = substr( (string) $item, 0, 2000 );
		}

		return $out;
	}

	private static function redact_sensitive_values( array $value ): array {
		$sensitive = array(
			'password',
			'pass',
			'pwd',
			'token',
			'access_token',
			'refresh_token',
			'jwt',
			'secret',
			'client_secret',
			'credential',
			'key',
			'api_key',
			'apikey',
			'nonce',
			'authorization',
			'bearer',
			'auth',
			'session',
			'code',
		);
		$out       = array();
		foreach ( $value as $key => $item ) {
			$normalized   = strtolower( preg_replace( '/[^a-z0-9_]/i', '', (string) $key ) );
			$is_sensitive = false;
			foreach ( $sensitive as $needle ) {
				if ( $normalized === $needle || str_ends_with( $normalized, '_' . $needle ) ) {
					$is_sensitive = true;
					break; }
			}
			if ( $is_sensitive ) {
				$out[ $key ] = '[redacted]';
				continue; }
			$out[ $key ] = is_array( $item ) ? self::redact_sensitive_values( $item ) : sanitize_text_field( (string) $item );
		}
		return $out;
	}
}
