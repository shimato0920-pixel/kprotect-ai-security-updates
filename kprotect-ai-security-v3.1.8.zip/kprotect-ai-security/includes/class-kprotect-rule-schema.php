<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Rule_Schema {
	/** @return array<int,string> */
	public static function fields(): array {
		return array( 'event_type', 'risk_score', 'blocked', 'count', 'request_method', 'hour', 'day_of_week' );
	}
	/** @return array<int,string> */
	public static function operators(): array {
		return array( '=', '!=', '>=', '<=', 'in', 'not_in', 'contains', 'starts_with' );
	}
	/** @return array<int,string> */
	public static function actions(): array {
		return array( 'admin_notification', 'email_notification', 'incident_priority', 'audit_log' );
	}
	/** @return array<string,string> */
	public static function field_labels(): array {
		return array(
			'event_type'     => 'イベント種別',
			'risk_score'     => '危険度',
			'blocked'        => '遮断状態',
			'count'          => '一致件数',
			'request_method' => 'リクエスト方式',
			'hour'           => '発生時刻',
			'day_of_week'    => '曜日',
		);
	}
	/** @return array<string,string> */
	public static function operator_labels(): array {
		return array(
			'='           => '等しい',
			'!='          => '等しくない',
			'>='          => '以上',
			'<='          => '以下',
			'in'          => 'いずれか',
			'not_in'      => 'いずれでもない',
			'contains'    => '含む',
			'starts_with' => '先頭一致',
		);
	}
	/** @return array<string,string> */
	public static function action_labels(): array {
		return array(
			'admin_notification' => '管理画面へ通知',
			'email_notification' => 'メールで通知',
			'incident_priority'  => 'インシデント優先度を変更',
			'audit_log'          => '監査ログへ記録',
		);
	}
	public static function field_label( string $key ): string {
		return self::field_labels()[ $key ] ?? $key; }
	public static function operator_label( string $key ): string {
		return self::operator_labels()[ $key ] ?? $key; }
	public static function action_label( string $key ): string {
		return self::action_labels()[ $key ] ?? $key; }
}
