<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Builds privacy-conscious dashboard aggregates from the local security log.
 */
final class KProtect_Dashboard_Analytics {
	/**
	 * Return dashboard data for the requested number of hours.
	 *
	 * @param int $hours Number of hours to include in the timeline.
	 * @return array<string,mixed>
	 */
	public function snapshot( int $hours = 24 ): array {
		global $wpdb;

		$hours = max( 6, min( 48, $hours ) );
		$table = $wpdb->prefix . 'kprotect_logs';
		$since = gmdate( 'Y-m-d H:00:00', time() - ( ( $hours - 1 ) * HOUR_IN_SECONDS ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard analytics intentionally reads live aggregates from the append-only KProtect log table; all dynamic values are prepared.
		$timeline_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE_FORMAT(created_at, '%%Y-%%m-%%d %%H:00:00') AS bucket, COUNT(*) AS total, SUM(blocked) AS blocked, MAX(risk_score) AS max_risk FROM %i WHERE created_at >= %s GROUP BY bucket ORDER BY bucket ASC",
				$table,
				$since
			),
			ARRAY_A
		);

		$type_rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT event_type, COUNT(*) AS total FROM %i WHERE created_at >= %s GROUP BY event_type ORDER BY total DESC LIMIT 8',
				$table,
				$since
			),
			ARRAY_A
		);

		$recent_rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT created_at, event_type, risk_score, ip_hash, ip_address, blocked, reasons FROM %i ORDER BY id DESC LIMIT 8',
				$table
			),
			ARRAY_A
		);

		$current_since  = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		$previous_since = gmdate( 'Y-m-d H:i:s', time() - ( 2 * DAY_IN_SECONDS ) );
		$comparison_row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT SUM(CASE WHEN created_at >= %s THEN 1 ELSE 0 END) AS current_total, SUM(CASE WHEN created_at >= %s AND created_at < %s THEN 1 ELSE 0 END) AS previous_total FROM %i WHERE created_at >= %s',
				$current_since,
				$previous_since,
				$current_since,
				$table,
				$previous_since
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$comparison = array(
			'current_total'  => max( 0, (int) ( $comparison_row['current_total'] ?? 0 ) ),
			'previous_total' => max( 0, (int) ( $comparison_row['previous_total'] ?? 0 ) ),
		);

		$timeline = self::fill_timeline( (array) $timeline_rows, $hours );
		$types    = array_map( array( self::class, 'normalize_type_row' ), (array) $type_rows );
		$recent   = array_map( array( self::class, 'normalize_recent_row' ), (array) $recent_rows );

		return array(
			'timeline'     => $timeline,
			'types'        => $types,
			'recent'       => $recent,
			'intelligence' => KProtect_AI_Engine::analyze( $timeline, $types, $recent, $comparison ),
		);
	}

	/**
	 * Fill empty hours so the chart remains stable when there are no events.
	 *
	 * @param array<int,array<string,mixed>> $rows Aggregated database rows.
	 * @param int                            $hours Number of buckets.
	 * @return array<int,array<string,mixed>>
	 */
	public static function fill_timeline( array $rows, int $hours ): array {
		$hours   = max( 1, min( 48, $hours ) );
		$indexed = array();
		foreach ( $rows as $row ) {
			$key = isset( $row['bucket'] ) ? (string) $row['bucket'] : '';
			if ( '' !== $key ) {
				$indexed[ $key ] = $row; }
		}

		$result = array();
		for ( $offset = $hours - 1; $offset >= 0; $offset-- ) {
			$timestamp = time() - ( $offset * HOUR_IN_SECONDS );
			$key       = gmdate( 'Y-m-d H:00:00', $timestamp );
			$row       = $indexed[ $key ] ?? array();
			$result[]  = array(
				'label'    => gmdate( 'H:00', $timestamp ),
				'total'    => max( 0, (int) ( $row['total'] ?? 0 ) ),
				'blocked'  => max( 0, (int) ( $row['blocked'] ?? 0 ) ),
				'max_risk' => max( 0, min( 100, (int) ( $row['max_risk'] ?? 0 ) ) ),
			);
		}
		return $result;
	}

	/** @param array<string,mixed> $row @return array<string,mixed> */
	public static function normalize_type_row( array $row ): array {
		$type = sanitize_key( (string) ( $row['event_type'] ?? 'unknown' ) );
		return array(
			'type'  => $type,
			'label' => self::event_label( $type ),
			'total' => max( 0, (int) ( $row['total'] ?? 0 ) ),
		);
	}

	/** @param array<string,mixed> $row @return array<string,mixed> */
	public static function normalize_recent_row( array $row ): array {
		$type = sanitize_key( (string) ( $row['event_type'] ?? 'unknown' ) );
		$ip   = trim( (string) ( $row['ip_address'] ?? '' ) );
		if ( '' === $ip ) {
			$hash = preg_replace( '/[^a-f0-9]/i', '', (string) ( $row['ip_hash'] ?? '' ) );
			$ip   = '' !== $hash ? 'hash:' . substr( $hash, 0, 12 ) : '非表示';
		}
		$reasons = json_decode( (string) ( $row['reasons'] ?? '[]' ), true );
		if ( ! is_array( $reasons ) ) {
			$reasons = array(); }

		$risk         = max( 0, min( 100, (int) ( $row['risk_score'] ?? 0 ) ) );
		$level        = KProtect_Risk_Score_Calculator::level( $risk );
		$explanations = KProtect_Risk_Score_Calculator::explain_reasons( $reasons );

		return array(
			'time'         => (string) ( $row['created_at'] ?? '' ),
			'type'         => $type,
			'label'        => self::event_label( $type ),
			'risk'         => $risk,
			'level'        => $level,
			'level_label'  => KProtect_Risk_Score_Calculator::level_label( $level ),
			'source'       => sanitize_text_field( $ip ),
			'blocked'      => ! empty( $row['blocked'] ),
			'reason'       => sanitize_text_field( implode( ', ', array_column( array_slice( $explanations, 0, 3 ), 'label' ) ) ),
			'explanations' => $explanations,
		);
	}

	public static function event_label( string $type ): string {
		$labels = array(
			'firewall'      => 'ファイアウォール',
			'login_failed'  => 'ログイン失敗',
			'login_blocked' => 'ログイン遮断',
			'rate_limit'    => '大量アクセス',
			'integrity'     => 'ファイル変更',
			'malware_scan'  => 'スキャン検知',
			'xmlrpc'        => 'XML-RPC',
		);
		return $labels[ $type ] ?? ( '' !== $type ? str_replace( '_', ' ', $type ) : '不明' );
	}
}
