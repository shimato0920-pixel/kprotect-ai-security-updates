<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Read-only REST API foundation for trusted administrative integrations.
 */
final class KProtect_REST_API {
	private const NAMESPACE = 'kprotect/v1';

	private KProtect_Security_Assistant $assistant;
	private KProtect_Security_Report $report;
	private KProtect_Dashboard_Analytics $analytics;
	private KProtect_File_Integrity_Manager $integrity;

	public function __construct(
		KProtect_Security_Assistant $assistant,
		KProtect_Security_Report $report,
		KProtect_Dashboard_Analytics $analytics,
		KProtect_File_Integrity_Manager $integrity
	) {
		$this->assistant = $assistant;
		$this->report    = $report;
		$this->analytics = $analytics;
		$this->integrity = $integrity;
	}

	public function register_routes(): void {
		$this->register( '/status', 'status' );
		$this->register( '/dashboard', 'dashboard' );
		$this->register( '/integrity', 'integrity' );
		$this->register( '/advisor', 'advisor' );
		$this->register(
			'/reports',
			'reports',
			array(
				'days' => array(
					'default'           => 1,
					'sanitize_callback' => 'absint',
					'validate_callback' => static fn( $value ): bool => in_array( (int) $value, array( 1, 7, 30 ), true ),
				),
			)
		);
		$this->register(
			'/notifications',
			'notifications',
			array(
				'page'     => array(
					'default'           => 1,
					'sanitize_callback' => 'absint',
				),
				'per_page' => array(
					'default'           => 20,
					'sanitize_callback' => 'absint',
					'validate_callback' => static fn( $value ): bool => (int) $value >= 1 && (int) $value <= 50,
				),
				'status'   => array(
					'default'           => '',
					'sanitize_callback' => 'sanitize_key',
					'validate_callback' => static fn( $value ): bool => in_array( (string) $value, array( '', 'read', 'unread' ), true ),
				),
			)
		);
	}

	/** @param array<string,mixed> $args */
	private function register( string $route, string $method, array $args = array() ): void {
		register_rest_route(
			self::NAMESPACE,
			$route,
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, $method ),
				'permission_callback' => array( $this, 'permissions' ),
				'args'                => $args,
			)
		);
	}

	/** @return true|WP_Error */
	public function permissions() {
		$settings = KProtect_Utils::settings();
		if ( empty( $settings['rest_api_enabled'] ) ) {
			return new WP_Error( 'kprotect_rest_disabled', 'KProtect REST APIは無効です。', array( 'status' => 403 ) );
		}
		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'kprotect_rest_authentication_required', '認証が必要です。', array( 'status' => 401 ) );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'kprotect_rest_forbidden', '管理者権限が必要です。', array( 'status' => 403 ) );
		}
		return true;
	}

	public function status( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;
		$logs          = $wpdb->prefix . 'kprotect_logs';
		$notifications = $wpdb->prefix . 'kprotect_notifications';
		$since         = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- REST status must report current security counters from KProtect-owned tables; all queries are read-only and prepared.
		$events   = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE created_at >= %s', $logs, $since ) );
		$blocked  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE created_at >= %s AND blocked = 1', $logs, $since ) );
		$max_risk = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(MAX(risk_score),0) FROM %i WHERE created_at >= %s', $logs, $since ) );
		$unread   = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $notifications, 'unread' ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return $this->response(
			array(
				'version'              => KPROTECT_VERSION,
				'protected'            => ! empty( KProtect_Utils::settings()['enabled'] ),
				'site_url'             => home_url( '/' ),
				'generated_at'         => current_time( 'c' ),
				'last_24_hours'        => array(
					'events'   => $events,
					'blocked'  => $blocked,
					'max_risk' => $max_risk,
				),
				'unread_notifications' => $unread,
				'last_scans'           => array(
					'integrity'      => (string) get_option( 'kprotect_integrity_last_scan', '' ),
					'uploads'        => (string) get_option( 'kprotect_malware_last_scan', '' ),
					'full_integrity' => (string) ( $this->integrity->last_result()['scanned_at'] ?? '' ),
				),
			)
		);
	}

	public function dashboard( WP_REST_Request $request ): WP_REST_Response {
		$data = $this->analytics->snapshot( 12 );
		// The analytics class already returns privacy-reduced source identifiers.
		return $this->response(
			array(
				'generated_at' => current_time( 'c' ),
				'hours'        => 12,
				'timeline'     => (array) ( $data['timeline'] ?? array() ),
				'types'        => (array) ( $data['types'] ?? array() ),
				'recent'       => array_slice( (array) ( $data['recent'] ?? array() ), 0, 8 ),
			)
		);
	}

	public function advisor( WP_REST_Request $request ): WP_REST_Response {
		$data = $this->assistant->report();
		return $this->response(
			array(
				'generated_at'    => current_time( 'c' ),
				'safety_score'    => (int) ( $data['safety_score'] ?? 0 ),
				'risk_score'      => (int) ( $data['risk_score'] ?? 0 ),
				'risk_level'      => sanitize_key( (string) ( $data['risk_level'] ?? '' ) ),
				'summary'         => sanitize_text_field( (string) ( $data['summary'] ?? '' ) ),
				'domains'         => (array) ( $data['domains'] ?? array() ),
				'trend'           => (array) ( $data['trend'] ?? array() ),
				'recommendations' => array_slice( (array) ( $data['recommendations'] ?? array() ), 0, 7 ),
			)
		);
	}

	public function reports( WP_REST_Request $request ): WP_REST_Response {
		$days = (int) $request->get_param( 'days' );
		$data = $this->report->build( $days );
		return $this->response(
			array(
				'generated_at'    => current_time( 'c' ),
				'days'            => $days,
				'score'           => (int) ( $data['score'] ?? 0 ),
				'level'           => sanitize_text_field( (string) ( $data['level'] ?? '' ) ),
				'total'           => (int) ( $data['total'] ?? 0 ),
				'blocked'         => (int) ( $data['blocked'] ?? 0 ),
				'block_rate'      => (float) ( $data['block_rate'] ?? 0 ),
				'max_risk'        => (int) ( $data['max_risk'] ?? 0 ),
				'avg_risk'        => (float) ( $data['avg_risk'] ?? 0 ),
				'types'           => (array) ( $data['types'] ?? array() ),
				'recommendations' => array_slice( (array) ( $data['recommendations'] ?? array() ), 0, 7 ),
			)
		);
	}

	public function integrity( WP_REST_Request $request ): WP_REST_Response {
		$data    = $this->integrity->last_result();
		$changes = (array) ( $data['changes'] ?? array() );
		$counts  = array();
		foreach ( $changes as $change ) {
			$category       = sanitize_key( (string) ( $change['category'] ?? 'unknown' ) );
			$type           = sanitize_key( (string) ( $change['type'] ?? 'unknown' ) );
			$key            = $category . ':' . $type;
			$counts[ $key ] = ( $counts[ $key ] ?? 0 ) + 1;
		}
		return $this->response(
			array(
				'generated_at'        => current_time( 'c' ),
				'baseline_created_at' => $this->integrity->baseline_created_at(),
				'has_baseline'        => $this->integrity->has_baseline(),
				'status'              => sanitize_key( (string) ( $data['status'] ?? 'not_scanned' ) ),
				'scanned_at'          => sanitize_text_field( (string) ( $data['scanned_at'] ?? '' ) ),
				'summary'             => (array) ( $data['summary'] ?? array() ),
				'change_count'        => count( $changes ),
				'change_counts'       => $counts,
			)
		);
	}

	public function notifications( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;
		$table         = $wpdb->prefix . 'kprotect_notifications';
		$page          = max( 1, (int) $request->get_param( 'page' ) );
		$per_page      = min( 50, max( 1, (int) $request->get_param( 'per_page' ) ) );
		$status        = sanitize_key( (string) $request->get_param( 'status' ) );
		$status_filter = in_array( $status, array( 'read', 'unread' ), true ) ? 1 : 0;
		$status_value  = $status_filter ? $status : '';
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Notification REST pagination requires current KProtect notification state; queries are read-only and prepared.
		$total  = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE ( %d = 0 OR status = %s )',
				$table,
				$status_filter,
				$status_value
			)
		);
		$offset = ( $page - 1 ) * $per_page;
		$rows   = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, created_at, updated_at, event_type, severity, title, message, risk_score, status, occurrences, feedback_status
				 FROM %i WHERE ( %d = 0 OR status = %s ) ORDER BY updated_at DESC LIMIT %d OFFSET %d',
				$table,
				$status_filter,
				$status_value,
				$per_page,
				$offset
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$items = array();
		foreach ( (array) $rows as $row ) {
			$presentation = KProtect_Notification_Center::presentation( (string) $row['event_type'], (int) $row['risk_score'], (string) $row['message'] );
			$items[]      = array(
				'id'              => (int) $row['id'],
				'created_at'      => $this->local_datetime( (string) $row['created_at'] ),
				'updated_at'      => $this->local_datetime( (string) $row['updated_at'] ),
				'event_type'      => sanitize_key( (string) $row['event_type'] ),
				'severity'        => sanitize_key( (string) $row['severity'] ),
				'risk_score'      => (int) $row['risk_score'],
				'status'          => sanitize_key( (string) $row['status'] ),
				'occurrences'     => (int) $row['occurrences'],
				'feedback_status' => sanitize_key( (string) $row['feedback_status'] ),
				'title'           => sanitize_text_field( (string) $presentation['title'] ),
				'summary'         => sanitize_text_field( (string) $presentation['summary'] ),
				'impact'          => sanitize_text_field( (string) $presentation['impact'] ),
				'actions'         => array_values( array_map( 'sanitize_text_field', (array) $presentation['actions'] ) ),
			);
		}
		$response = $this->response(
			array(
				'items'    => $items,
				'page'     => $page,
				'per_page' => $per_page,
				'total'    => $total,
			)
		);
		$response->header( 'X-WP-Total', (string) $total );
		$response->header( 'X-WP-TotalPages', (string) (int) ceil( $total / $per_page ) );
		return $response;
	}

	/** @param array<string,mixed> $data */
	private function response( array $data ): WP_REST_Response {
		$response = rest_ensure_response( $data );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
		return $response;
	}

	private function local_datetime( string $gmt ): string {
		$timestamp = strtotime( $gmt . ' UTC' );
		return false === $timestamp ? $gmt : wp_date( 'c', $timestamp );
	}
}
