<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

/**
 * Calculates an explainable request risk score from detector signals.
 *
 * The calculator is intentionally deterministic. It does not call an external
 * AI service and does not modify WordPress data.
 */
final class KProtect_Risk_Score_Calculator {
	/**
	 * Calculate the request risk score.
	 *
	 * Primary rule matches use the highest matched value rather than stacking
	 * several signatures for the same request. Context modifiers are then added.
	 * This preserves the detector behaviour used before this class was added.
	 *
	 * @param array<string,int> $primary_matches Matched rule name => score.
	 * @param array<string,int> $modifiers       Context reason => score adjustment.
	 * @param array<int,string> $informational   Reasons that do not change the score.
	 * @return array{score:int,level:string,reasons:array<int,string>,components:array<string,int>}
	 */
	public static function calculate( array $primary_matches, array $modifiers = array(), array $informational = array() ): array {
		$components = array();
		$reasons    = array();
		$base_score = 0;

		foreach ( $primary_matches as $reason => $value ) {
			$reason = sanitize_key( (string) $reason );
			$value  = self::normalize_points( $value );
			if ( '' === $reason || 0 === $value ) {
				continue;
			}

			$components[ $reason ] = $value;
			$reasons[]             = $reason;
			$base_score            = max( $base_score, $value );
		}

		$score = $base_score;
		foreach ( $modifiers as $reason => $value ) {
			$reason = sanitize_key( (string) $reason );
			$value  = self::normalize_points( $value );
			if ( '' === $reason || 0 === $value ) {
				continue;
			}

			$components[ $reason ] = $value;
			$reasons[]             = $reason;
			$score                += $value;
		}

		foreach ( $informational as $reason ) {
			$reason = sanitize_key( (string) $reason );
			if ( '' !== $reason ) {
				$reasons[] = $reason;
			}
		}

		$score = max( 0, min( 100, $score ) );

		return array(
			'score'      => $score,
			'level'      => self::level( $score ),
			'reasons'    => array_values( array_unique( $reasons ) ),
			'components' => $components,
		);
	}

	/**
	 * Convert a score into a stable level used by APIs and administration UI.
	 */
	public static function level( int $score ): string {
		$score = max( 0, min( 100, $score ) );
		if ( $score >= 90 ) {
			return 'critical';
		}
		if ( $score >= 70 ) {
			return 'high';
		}
		if ( $score >= 30 ) {
			return 'medium';
		}
		return 'low';
	}


	/**
	 * Convert stored reason keys into administrator-facing explanations.
	 *
	 * @param array<int,string> $reasons Stored detector reasons.
	 * @return array<int,array{key:string,label:string,points:int,kind:string}>
	 */
	public static function explain_reasons( array $reasons ): array {
		$catalog = self::reason_catalog();
		$result  = array();

		foreach ( array_values( array_unique( $reasons ) ) as $reason ) {
			$key = sanitize_key( (string) $reason );
			if ( '' === $key ) {
				continue;
			}

			if ( isset( $catalog[ $key ] ) ) {
				$item     = $catalog[ $key ];
				$result[] = array(
					'key'    => $key,
					'label'  => $item['label'],
					'points' => $item['points'],
					'kind'   => $item['kind'],
				);
				continue;
			}

			$result[] = array(
				'key'    => $key,
				'label'  => ucwords( str_replace( '_', ' ', $key ) ),
				'points' => 0,
				'kind'   => 'information',
			);
		}

		return $result;
	}

	/** Return the Japanese label used by the administration UI. */
	public static function level_label( string $level ): string {
		$labels = array(
			'low'      => '低',
			'medium'   => '中',
			'high'     => '高',
			'critical' => '重大',
		);
		return $labels[ sanitize_key( $level ) ] ?? '不明';
	}


	/** Return the Japanese label used for a stored event type. */
	public static function event_label( string $event_type ): string {
		$labels = array(
			'firewall'       => 'ファイアウォール検知',
			'rate_limit'     => 'アクセス過多',
			'blocked_ip'     => '遮断中IPからのアクセス',
			'login_failed'   => 'ログイン失敗',
			'login_blocked'  => 'ログイン攻撃を遮断',
			'integrity'      => '重要ファイルの変更',
			'file_integrity' => 'ファイル整合性の差分',
			'malware_scan'   => 'uploadsスキャン',
		);

		$event_type = sanitize_key( $event_type );
		return $labels[ $event_type ] ?? ucwords( str_replace( '_', ' ', $event_type ) );
	}

	/**
	 * Build an administrator-facing explanation for one stored event.
	 *
	 * @param string            $event_type Stored event type.
	 * @param array<int,string> $reasons    Stored detector reasons.
	 * @param int               $score      Stored risk score.
	 * @param bool              $blocked    Whether the event was blocked.
	 * @return array{level:string,level_label:string,title:string,summary:string,recommendation:string,items:array<int,array{label:string,value:string,points:int}>}
	 */
	public static function explain_event( string $event_type, array $reasons, int $score, bool $blocked ): array {
		$score = max( 0, min( 100, $score ) );
		$level = self::level( $score );
		$items = array();

		foreach ( self::explain_reasons( $reasons ) as $reason ) {
			$kind    = (string) $reason['kind'];
			$items[] = array(
				'label'  => (string) $reason['label'],
				'value'  => 'primary' === $kind ? '主要な検知根拠' : ( 'modifier' === $kind ? '補助的な判断材料' : '参考情報' ),
				'points' => (int) $reason['points'],
			);
		}

		if ( empty( $items ) ) {
			$items[] = array(
				'label'  => '詳細な検知理由は記録されていません',
				'value'  => '保存済みの危険度と関連ログを確認してください',
				'points' => 0,
			);
		}

		$title = self::event_label( $event_type );
		if ( $blocked ) {
			$summary        = 'このイベントはKProtectによって遮断されました。';
			$recommendation = '同じ種類の検知が継続していないか、関連ログと遮断状況を確認してください。';
		} elseif ( in_array( $level, array( 'critical', 'high' ), true ) ) {
			$summary        = '危険度が高い未遮断イベントです。侵害を断定せず、検知理由とアクセス内容を確認してください。';
			$recommendation = '正規アクセスか攻撃試行かを確認し、必要に応じて一時遮断や設定の見直しを行ってください。';
		} else {
			$summary        = '監査目的で記録されたイベントです。直ちに侵害を示すものではありません。';
			$recommendation = '同種イベントの発生回数と時間帯を確認し、継続する場合のみ追加対応を検討してください。';
		}

		return array(
			'level'          => $level,
			'level_label'    => self::level_label( $level ),
			'title'          => $title,
			'summary'        => $summary,
			'recommendation' => $recommendation,
			'items'          => $items,
		);
	}

	/**
	 * Known detector and firewall reasons.
	 *
	 * @return array<string,array{label:string,points:int,kind:string}>
	 */
	private static function reason_catalog(): array {
		return array(
			'sql_injection'           => array(
				'label'  => 'SQLインジェクションの疑い',
				'points' => 90,
				'kind'   => 'primary',
			),
			'xss'                     => array(
				'label'  => 'クロスサイトスクリプティングの疑い',
				'points' => 85,
				'kind'   => 'primary',
			),
			'path_traversal'          => array(
				'label'  => 'パストラバーサルの疑い',
				'points' => 90,
				'kind'   => 'primary',
			),
			'code_execution'          => array(
				'label'  => 'コード実行の疑い',
				'points' => 100,
				'kind'   => 'primary',
			),
			'sensitive_file'          => array(
				'label'  => '機密ファイルへのアクセス試行',
				'points' => 75,
				'kind'   => 'primary',
			),
			'webshell_probe'          => array(
				'label'  => 'Webシェル探索の疑い',
				'points' => 95,
				'kind'   => 'primary',
			),
			'empty_user_agent'        => array(
				'label'  => 'User-Agentが空',
				'points' => 25,
				'kind'   => 'modifier',
			),
			'suspicious_automation'   => array(
				'label'  => '不審な自動アクセス',
				'points' => 35,
				'kind'   => 'modifier',
			),
			'login_post'              => array(
				'label'  => 'ログインPOSTリクエスト',
				'points' => 10,
				'kind'   => 'modifier',
			),
			'oversized_request_uri'   => array(
				'label'  => '異常に長いリクエストURI',
				'points' => 20,
				'kind'   => 'modifier',
			),
			'heavy_url_encoding'      => array(
				'label'  => '過剰なURLエンコード',
				'points' => 15,
				'kind'   => 'modifier',
			),
			'known_search_bot_claim'  => array(
				'label'  => '検索エンジンBotを名乗るアクセス',
				'points' => 0,
				'kind'   => 'information',
			),
			'active_block'            => array(
				'label'  => '既存の有効なIPブロック',
				'points' => 100,
				'kind'   => 'enforcement',
			),
			'too_many_requests'       => array(
				'label'  => '短時間のアクセス過多',
				'points' => 90,
				'kind'   => 'enforcement',
			),
			'administrator_session'   => array(
				'label'  => '管理者セッションのため記録のみ',
				'points' => 0,
				'kind'   => 'information',
			),
			'client_automation'       => array(
				'label'  => '自動化クライアント',
				'points' => 0,
				'kind'   => 'information',
			),
			'client_unknown_bot'      => array(
				'label'  => '識別不能なBot',
				'points' => 0,
				'kind'   => 'information',
			),
			'client_search_bot_claim' => array(
				'label'  => '検索Botを名乗るクライアント',
				'points' => 0,
				'kind'   => 'information',
			),
		);
	}

	/** @param mixed $value */
	private static function normalize_points( $value ): int {
		return max( 0, min( 100, (int) $value ) );
	}
}
