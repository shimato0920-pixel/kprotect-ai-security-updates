<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Maintenance_Manager {
	private const LAST_CLEANUP_OPTION = 'kprotect_last_cleanup_report';
	private const METRICS_OPTION      = 'kprotect_performance_metrics';

	/** @return array<string,mixed> */
	public function run_cleanup(): array {
		global $wpdb;
		$settings            = KProtect_Utils::settings();
		$started             = microtime( true );
		$memory_before       = memory_get_usage( true );
		$log_days            = max( 1, (int) $settings['log_retention_days'] );
		$notification_days   = max( 1, (int) $settings['notification_retention_days'] );
		$log_cutoff          = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * $log_days );
		$notification_cutoff = gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS * $notification_days );
		$block_cutoff        = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Scheduled/admin maintenance intentionally deletes expired rows from KProtect-owned tables; write operations must not be cached and all SQL is prepared.
		$logs          = $wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE created_at < %s', $wpdb->prefix . 'kprotect_logs', $log_cutoff ) );
		$notifications = $wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE updated_at < %s', $wpdb->prefix . 'kprotect_notifications', $notification_cutoff ) );
		$blocks        = $wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE active = 0 AND expires_at < %s', $wpdb->prefix . 'kprotect_blocks', $block_cutoff ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$deliveries = ( new KProtect_Delivery_History() )->cleanup( $notification_days );
		$report     = array(
			'completed_at'          => current_time( 'mysql' ),
			'logs_deleted'          => max( 0, (int) $logs ),
			'notifications_deleted' => max( 0, (int) $notifications ),
			'blocks_deleted'        => max( 0, (int) $blocks ),
			'deliveries_deleted'    => max( 0, (int) $deliveries ),
			'duration_ms'           => round( ( microtime( true ) - $started ) * 1000, 2 ),
			'memory_delta_bytes'    => max( 0, memory_get_usage( true ) - $memory_before ),
		);
		update_option( self::LAST_CLEANUP_OPTION, $report, false );
		return $report;
	}

	/** @return array<string,mixed> */
	public function status(): array {
		global $wpdb;
		$tables = array(
			'logs'          => $wpdb->prefix . 'kprotect_logs',
			'notifications' => $wpdb->prefix . 'kprotect_notifications',
			'blocks'        => $wpdb->prefix . 'kprotect_blocks',
			'deliveries'    => $wpdb->prefix . 'kprotect_delivery_history',
		);
		$counts = array();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Maintenance status is an explicit diagnostics view and must report the current KProtect table state; queries are read-only and prepared.
		foreach ( $tables as $key => $table ) {
			$exists         = $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			$counts[ $key ] = $exists ? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) ) : 0;
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return array(
			'counts'          => $counts,
			'last_cleanup'    => get_option( self::LAST_CLEANUP_OPTION, array() ),
			'next_cleanup'    => wp_next_scheduled( 'kprotect_daily_cleanup' ),
			'installed'       => (string) get_option( 'kprotect_version', '' ),
			'schema'          => (string) get_option( 'kprotect_schema_version', '' ),
			'upgrade_history' => (array) get_option( 'kprotect_upgrade_history', array() ),
			'metrics'         => (array) get_option( self::METRICS_OPTION, array() ),
		);
	}

	/** @param array<string,mixed> $metric */
	public static function record_metric( string $name, array $metric ): void {
		$all                          = (array) get_option( self::METRICS_OPTION, array() );
		$all[ sanitize_key( $name ) ] = array_merge( $metric, array( 'recorded_at' => current_time( 'mysql' ) ) );
		update_option( self::METRICS_OPTION, $all, false );
	}
}
