<?php
/**
 * Login attack aggregation for KProtect AI Security.
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Aggregates anonymous login attack telemetry.
 */
final class KProtect_Login_Attack_Tracker {

	/**
	 * Create a privacy-preserving account identifier.
	 *
	 * @param string $username Submitted username.
	 * @return string
	 */
	public static function account_hash( string $username ): string {
		$username = strtolower( trim( $username ) );

		if ( '' === $username ) {
			return '';
		}

		return hash_hmac(
			'sha256',
			$username,
			wp_salt( 'auth' )
		);
	}

	/**
	 * Create an anonymous source identifier.
	 *
	 * @param string $ip Source IP address.
	 * @return string
	 */
	public static function source_hash( string $ip ): string {
		if ( ! KProtect_Utils::has_valid_client_ip( $ip ) ) {
			return '';
		}

		return KProtect_Utils::ip_hash( $ip );
	}
	/**
	 * Record an anonymous failed-login event.
	 *
	 * Usernames and raw IP addresses are never stored in these tables.
	 *
	 * @param string $username       Submitted username.
	 * @param string $ip             Source IP address.
	 * @param int    $login_failures Configured IP login failure threshold.
	 * @return array<string,mixed>
	 */
	public static function record_failure(
		string $username,
		string $ip,
		int $login_failures
	): array {
		global $wpdb;

		$account_hash = self::account_hash( $username );
		$source_hash  = self::source_hash( $ip );

		if ( '' === $account_hash || '' === $source_hash ) {
			return array();
		}

		$attacks_table = $wpdb->prefix . 'kprotect_login_attacks';
		$sources_table = $wpdb->prefix . 'kprotect_login_attack_sources';
		$now           = current_time( 'mysql', true );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
		$existing_source = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE account_hash = %s AND source_hash = %s',
				$sources_table,
				$account_hash,
				$source_hash
			)
		);

		$has_new_source = 0 === $existing_source;

		if ( $has_new_source ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
			$wpdb->insert(
				$sources_table,
				array(
					'account_hash'  => $account_hash,
					'source_hash'   => $source_hash,
					'first_seen'    => $now,
					'last_seen'     => $now,
					'attempt_count' => 1,
				),
				array( '%s', '%s', '%s', '%s', '%d' )
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
			$wpdb->query(
				$wpdb->prepare(
					'UPDATE %i SET last_seen = %s, attempt_count = attempt_count + 1 WHERE account_hash = %s AND source_hash = %s',
					$sources_table,
					$now,
					$account_hash,
					$source_hash
				)
			);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
		$source_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE account_hash = %s',
				$sources_table,
				$account_hash
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
		$current_failed_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT failed_count FROM %i WHERE account_hash = %s LIMIT 1',
				$attacks_table,
				$account_hash
			)
		);

		$failed_count = $current_failed_count + 1;

		$aggregate = self::evaluate_aggregate(
			$failed_count,
			$source_count,
			$has_new_source,
			$login_failures
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
		$existing_attack = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE account_hash = %s',
				$attacks_table,
				$account_hash
			)
		);

		if ( 0 === $existing_attack ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
			$wpdb->insert(
				$attacks_table,
				array(
					'account_hash' => $account_hash,
					'failed_count' => $failed_count,
					'source_count' => $source_count,
					'distributed'  => ! empty( $aggregate['distributed'] ) ? 1 : 0,
					'first_seen'   => $now,
					'last_seen'    => $now,
				),
				array( '%s', '%d', '%d', '%d', '%s', '%s' )
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- KProtect-owned real-time security telemetry table.
			$wpdb->update(
				$attacks_table,
				array(
					'failed_count' => $failed_count,
					'source_count' => $source_count,
					'distributed'  => ! empty( $aggregate['distributed'] ) ? 1 : 0,
					'last_seen'    => $now,
				),
				array(
					'account_hash' => $account_hash,
				),
				array( '%d', '%d', '%d', '%s' ),
				array( '%s' )
			);
		}

		$aggregate['account_hash'] = $account_hash;
		$aggregate['source_hash']  = $source_hash;

		return $aggregate;
	}
	/**
	 * Return recent anonymous login attack aggregates.
	 *
	 * @param int $limit Maximum number of rows.
	 * @return array<int,array<string,mixed>>
	 */
	public static function recent_attacks( int $limit = 20 ): array {
		global $wpdb;

		$limit = max( 1, min( 100, $limit ) );
		$table = $wpdb->prefix . 'kprotect_login_attacks';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Read-only KProtect-owned security telemetry.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT account_hash, failed_count, source_count, distributed, first_seen, last_seen FROM %i ORDER BY last_seen DESC LIMIT %d',
				$table,
				$limit
			),
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( array $row ): array {
				$account_hash = (string) ( $row['account_hash'] ?? '' );

				return array(
					'account_id'   => '' !== $account_hash ? substr( $account_hash, 0, 12 ) : '',
					'failed_count' => (int) ( $row['failed_count'] ?? 0 ),
					'source_count' => (int) ( $row['source_count'] ?? 0 ),
					'distributed'  => ! empty( $row['distributed'] ),
					'first_seen'   => (string) ( $row['first_seen'] ?? '' ),
					'last_seen'    => (string) ( $row['last_seen'] ?? '' ),
				);
			},
			$rows
		);
	}
	/**
	 * Evaluate aggregate login attack state without side effects.
	 *
	 * @param int  $failed_count      Total failed attempts against the account.
	 * @param int  $source_count      Number of unique source IP hashes.
	 * @param bool $has_new_source    Whether the latest attempt came from a new source.
	 * @param int  $login_failures    Configured IP login failure threshold.
	 * @return array<string,mixed>
	 */
	public static function evaluate_aggregate(
		int $failed_count,
		int $source_count,
		bool $has_new_source,
		int $login_failures
	): array {
		$threshold         = max( 2, $login_failures );
		$account_threshold = $threshold + 3;

		$failed_count = max( 0, $failed_count );
		$source_count = max( 0, $source_count );

		return array(
			'failed_count'      => $failed_count,
			'source_count'      => $source_count,
			'has_new_source'    => $has_new_source,
			'distributed'       => $failed_count >= $account_threshold
				&& $source_count >= $account_threshold,
			'account_threshold' => $account_threshold,
		);
	}
}
