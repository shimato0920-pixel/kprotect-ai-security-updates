<?php
/**
 * Plugin Name: KProtect AI Security
 * Plugin URI:  https://github.com/shimato0920-pixel/kprotect-ai-security
 * Description: Lightweight WordPress firewall, login protection, risk scoring, temporary IP blocking, security monitoring, and file integrity checks.
 * Version: 3.2.5
 * Requires at least: 6.4
 * Requires PHP: 8.0
 * Author:      shimato0920
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 * Text Domain: kprotect-ai-security
 *
 * @package KProtect_AI_Security
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KPROTECT_VERSION', '3.2.5' );
define( 'KPROTECT_FILE', __FILE__ );
define( 'KPROTECT_DIR', plugin_dir_path( __FILE__ ) );
define( 'KPROTECT_URL', plugin_dir_url( __FILE__ ) );

require_once KPROTECT_DIR . 'includes/class-kprotect-installer.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-utils.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-threat-level.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-logger.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-notification-center.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-notification-rules.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-delivery-history.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-notification-queue.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-discord-notifier.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-slack-notifier.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-webhook-notifier.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-notifier.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-adaptive-protection.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-ip-blocker.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-risk-score-calculator.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-ai-engine.php';
require_once KPROTECT_DIR . 'includes/interface-kprotect-ai-provider.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-local-ai-assistant.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-local-ai-provider.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-ai-provider-manager.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-rule-schema.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-rule-validator.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-ai-rule-drafter.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-rule-repository.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-rule-tester.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-event-advisor.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-detector.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-attack-classifier.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-rate-limiter.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-firewall.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-login-attack-tracker.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-login-guard.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-integrity-scanner.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-file-integrity-manager.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-security-auditor.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-security-assistant.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-security-report.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-incident-center.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-dashboard-analytics.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-security-analyst.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-malware-scanner.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-maintenance-manager.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-rest-api.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-github-updater.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-update-diagnostics.php';
require_once KPROTECT_DIR . 'admin/class-kprotect-admin.php';
require_once KPROTECT_DIR . 'includes/class-kprotect-plugin.php';



/**
 * Add a direct settings link on the Plugins screen.
 *
 * @param array<int,string> $links Existing action links.
 * @return array<int,string>
 */
function kprotect_plugin_action_links( array $links ): array {
	if ( ! current_user_can( 'manage_options' ) ) {
		return $links;
	}

	$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=kprotect-settings' ) ) . '">' . esc_html__( 'Settings', 'kprotect-ai-security' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'kprotect_plugin_action_links' );

register_activation_hook( __FILE__, array( 'KProtect_Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'KProtect_Installer', 'deactivate' ) );

KProtect_Plugin::instance()->run();
