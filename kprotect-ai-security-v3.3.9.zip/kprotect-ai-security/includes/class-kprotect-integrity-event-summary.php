<?php
/**
 * Build bounded evidence for aggregated file-integrity events.
 *
 * @package KProtect_AI_Security
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds bounded evidence for one aggregated file-integrity event.
 */
final class KProtect_Integrity_Event_Summary {
	private const SAMPLE_LIMIT = 5;

	/**
	 * Summarize file changes without creating one event per file.
	 *
	 * @param array<int, array<string, mixed>> $changes File changes.
	 * @return array<int, string>
	 */
	public static function reasons( array $changes ): array {
		$type_counts     = array();
		$category_counts = array();
		$samples         = array();
		$kprotect_sample = '';

		foreach ( $changes as $change ) {
			$type     = (string) ( $change['type'] ?? 'unknown' );
			$category = (string) ( $change['category'] ?? 'tracked' );
			$file     = (string) ( $change['file'] ?? '' );

			$type_counts[ $type ]         = ( $type_counts[ $type ] ?? 0 ) + 1;
			$category_counts[ $category ] = ( $category_counts[ $category ] ?? 0 ) + 1;

			if ( '' !== $file && count( $samples ) < self::SAMPLE_LIMIT ) {
				$samples[] = $file;
			}

			$normalized = strtolower( str_replace( '\\', '/', $file ) );
			if (
				'' === $kprotect_sample &&
				str_contains(
					$normalized,
					'wp-content/plugins/kprotect-ai-security/'
				)
			) {
				$kprotect_sample = $file;
			}
		}

		ksort( $type_counts );
		ksort( $category_counts );

		$reasons = array( '変更総数 ' . count( $changes ) . '件' );
		foreach ( $type_counts as $type => $count ) {
			$reasons[] = '種別 ' . $type . ' ' . $count . '件';
		}
		foreach ( $category_counts as $category => $count ) {
			$reasons[] = '分類 ' . $category . ' ' . $count . '件';
		}

		if ( '' !== $kprotect_sample && ! in_array( $kprotect_sample, $samples, true ) ) {
			if ( count( $samples ) >= self::SAMPLE_LIMIT ) {
				array_pop( $samples );
			}
			$samples[] = $kprotect_sample;
		}

		foreach ( $samples as $file ) {
			$reasons[] = '代表ファイル ' . $file;
		}

		return $reasons;
	}
}
