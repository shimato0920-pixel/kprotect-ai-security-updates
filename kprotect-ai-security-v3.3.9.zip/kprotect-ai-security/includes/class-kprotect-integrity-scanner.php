<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class KProtect_Integrity_Scanner {
	private KProtect_Logger $logger;
	private const OPTION = 'kprotect_integrity_baseline';

	public function __construct( KProtect_Logger $logger ) {
		$this->logger = $logger; }

	public function tracked_files(): array {
		$files = array(
			ABSPATH . 'wp-config.php',
			dirname( ABSPATH ) . '/wp-config.php',
			ABSPATH . '.htaccess',
			ABSPATH . 'index.php',
			ABSPATH . 'wp-settings.php',
			ABSPATH . 'wp-load.php',
			get_stylesheet_directory() . '/functions.php',
			get_stylesheet_directory() . '/header.php',
			get_stylesheet_directory() . '/footer.php',
		);
		return array_values( array_unique( array_filter( $files, 'is_file' ) ) );
	}

	public function create_baseline(): array {
		$baseline = array();
		foreach ( $this->tracked_files() as $file ) {
			$baseline[ $this->relative_path( $file ) ] = array(
				'hash'  => hash_file( 'sha256', $file ),
				'mtime' => (int) filemtime( $file ),
				'size'  => (int) filesize( $file ),
			);
		}
		update_option( self::OPTION, $baseline, false );
		update_option( 'kprotect_integrity_last_baseline', current_time( 'mysql', true ), false );
		return $baseline;
	}

	public function scan(): array {
		$kp_started = microtime( true );
		$kp_memory  = memory_get_usage( true );
		$baseline   = (array) get_option( self::OPTION, array() );
		if ( empty( $baseline ) ) {
			KProtect_Maintenance_Manager::record_metric(
				'integrity_scan',
				array(
					'duration_ms'        => round( ( microtime( true ) - $kp_started ) * 1000, 2 ),
					'memory_delta_bytes' => max( 0, memory_get_usage( true ) - $kp_memory ),
					'changes'            => 0,
					'status'             => 'no_baseline',
				)
			);
			return array(
				'status'  => 'no_baseline',
				'changes' => array(),
			);
		}
		$changes = array();
		$current = array();
		foreach ( $this->tracked_files() as $file ) {
			$path             = $this->relative_path( $file );
			$current[ $path ] = hash_file( 'sha256', $file );
			if ( isset( $baseline[ $path ]['hash'] ) && ! hash_equals( (string) $baseline[ $path ]['hash'], $current[ $path ] ) ) {
				$changes[] = array(
					'file' => $path,
					'type' => 'modified',
				);
			}
		}
		foreach ( $baseline as $path => $data ) {
			if ( ! array_key_exists( $path, $current ) ) {
				$changes[] = array(
					'file' => $path,
					'type' => 'missing',
				);
			}
		}
		update_option( 'kprotect_integrity_last_scan', current_time( 'mysql', true ), false );
		update_option( 'kprotect_integrity_last_result', $changes, false );
		if ( ! empty( $changes ) ) {
			$this->logger->log(
				'file_integrity',
				85,
				KProtect_Integrity_Event_Summary::reasons( $changes ),
				false,
				KProtect_Utils::client_ip()
			);
		}
		KProtect_Maintenance_Manager::record_metric(
			'integrity_scan',
			array(
				'duration_ms'        => round( ( microtime( true ) - $kp_started ) * 1000, 2 ),
				'memory_delta_bytes' => max( 0, memory_get_usage( true ) - $kp_memory ),
				'changes'            => count( $changes ),
				'status'             => empty( $changes ) ? 'clean' : 'changed',
			)
		);
		return array(
			'status'  => empty( $changes ) ? 'clean' : 'changed',
			'changes' => $changes,
		);
	}

	private function relative_path( string $file ): string {
		$normalized = wp_normalize_path( $file );
		$root       = trailingslashit( wp_normalize_path( ABSPATH ) );
		return str_starts_with( $normalized, $root ) ? substr( $normalized, strlen( $root ) ) : basename( $normalized );
	}
}
