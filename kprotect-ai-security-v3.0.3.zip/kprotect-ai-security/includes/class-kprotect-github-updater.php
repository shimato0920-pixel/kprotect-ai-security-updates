{\rtf1\ansi\ansicpg932\cocoartf2870
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 <?php\
/**\
 * GitHub release updater.\
 *\
 * @package KProtect_AI_Security\
 */\
\
declare(strict_types=1);\
\
if ( ! defined( 'ABSPATH' ) ) \{\
	exit;\
\}\
\
final class KProtect_GitHub_Updater \{\
\
	private const API_URL = 'https://api.github.com/repos/shimato0920-pixel/kprotect-ai-security/releases/latest';\
\
	private string $plugin_file;\
	private string $plugin_basename;\
	private string $slug;\
\
	public function __construct( string $plugin_file ) \{\
		$this->plugin_file     = $plugin_file;\
		$this->plugin_basename = plugin_basename( $plugin_file );\
		$this->slug            = dirname( $this->plugin_basename );\
	\}\
\
	public function hooks(): void \{\
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_update' ) );\
		add_filter( 'plugins_api', array( $this, 'plugin_information' ), 20, 3 );\
		add_filter( 'upgrader_source_selection', array( $this, 'fix_package_folder' ), 10, 4 );\
	\}\
\
	public function check_update( $transient ) \{\
		if ( ! is_object( $transient ) ) \{\
			return $transient;\
		\}\
\
		$release = $this->get_latest_release();\
\
		if ( ! $release ) \{\
			return $transient;\
		\}\
\
		$latest_version = $release['version'];\
\
		if ( ! version_compare( KPROTECT_VERSION, $latest_version, '<' ) ) \{\
			return $transient;\
		\}\
\
		$package_url = $this->get_package_url( $release['assets'], $latest_version );\
\
		if ( ! $package_url ) \{\
			return $transient;\
		\}\
\
		$update = (object) array(\
			'id'           => 'github.com/shimato0920-pixel/kprotect-ai-security',\
			'slug'         => $this->slug,\
			'plugin'       => $this->plugin_basename,\
			'new_version'  => $latest_version,\
			'url'          => 'https://github.com/shimato0920-pixel/kprotect-ai-security',\
			'package'      => $package_url,\
			'icons'        => array(),\
			'banners'      => array(),\
			'banners_rtl'  => array(),\
			'tested'       => '',\
			'requires_php' => '8.0',\
		);\
\
		$transient->response[ $this->plugin_basename ] = $update;\
\
		return $transient;\
	\}\
\
	public function plugin_information( $result, string $action, object $args ) \{\
		if ( 'plugin_information' !== $action ) \{\
			return $result;\
		\}\
\
		if ( empty( $args->slug ) || $this->slug !== $args->slug ) \{\
			return $result;\
		\}\
\
		$release = $this->get_latest_release();\
\
		if ( ! $release ) \{\
			return $result;\
		\}\
\
		$package_url = $this->get_package_url( $release['assets'], $release['version'] );\
\
		return (object) array(\
			'name'          => 'KProtect AI Security',\
			'slug'          => $this->slug,\
			'version'       => $release['version'],\
			'author'        => '<a href="https://github.com/shimato0920-pixel">shimato0920</a>',\
			'homepage'      => 'https://github.com/shimato0920-pixel/kprotect-ai-security',\
			'requires'      => '6.4',\
			'requires_php'  => '8.0',\
			'download_link' => $package_url,\
			'sections'      => array(\
				'description' => 'KProtect AI Security provides WordPress firewall, login protection, risk scoring, security monitoring, malware scanning, and file integrity features.',\
				'changelog'   => wp_kses_post( nl2br( $release['body'] ) ),\
			),\
		);\
	\}\
\
	public function fix_package_folder( string $source, string $remote_source, $upgrader, array $hook_extra ): string \{\
		if ( empty( $hook_extra['plugin'] ) || $this->plugin_basename !== $hook_extra['plugin'] ) \{\
			return $source;\
		\}\
\
		$expected = trailingslashit( $remote_source ) . $this->slug . '/';\
\
		if ( $source === $expected ) \{\
			return $source;\
		\}\
\
		global $wp_filesystem;\
\
		if ( ! $wp_filesystem ) \{\
			return $source;\
		\}\
\
		if ( $wp_filesystem->exists( $expected ) ) \{\
			$wp_filesystem->delete( $expected, true );\
		\}\
\
		if ( ! $wp_filesystem->move( $source, $expected, true ) ) \{\
			return $source;\
		\}\
\
		return $expected;\
	\}\
\
	private function get_latest_release(): ?array \{\
		$cache_key = 'kprotect_github_release';\
\
		$cached = get_site_transient( $cache_key );\
\
		if ( is_array( $cached ) ) \{\
			return $cached;\
		\}\
\
		$response = wp_remote_get(\
			self::API_URL,\
			array(\
				'timeout' => 10,\
				'headers' => array(\
					'Accept'               => 'application/vnd.github+json',\
					'X-GitHub-Api-Version' => '2022-11-28',\
					'User-Agent'           => 'KProtect-AI-Security/' . KPROTECT_VERSION,\
				),\
			)\
		);\
\
		if ( is_wp_error( $response ) ) \{\
			return null;\
		\}\
\
		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) \{\
			return null;\
		\}\
\
		$data = json_decode( wp_remote_retrieve_body( $response ), true );\
\
		if ( ! is_array( $data ) || empty( $data['tag_name'] ) ) \{\
			return null;\
		\}\
\
		if ( ! empty( $data['draft'] ) || ! empty( $data['prerelease'] ) ) \{\
			return null;\
		\}\
\
		$release = array(\
			'version' => ltrim( (string) $data['tag_name'], 'vV' ),\
			'body'    => isset( $data['body'] ) ? (string) $data['body'] : '',\
			'assets'  => isset( $data['assets'] ) && is_array( $data['assets'] ) ? $data['assets'] : array(),\
		);\
\
		set_site_transient( $cache_key, $release, 6 * HOUR_IN_SECONDS );\
\
		return $release;\
	\}\
\
	private function get_package_url( array $assets, string $version ): ?string \{\
		$expected_name = 'kprotect-ai-security-v' . $version . '.zip';\
\
		foreach ( $assets as $asset ) \{\
			if (\
				isset( $asset['name'], $asset['browser_download_url'] )\
				&& $expected_name === $asset['name']\
			) \{\
				return esc_url_raw( (string) $asset['browser_download_url'] );\
			\}\
		\}\
\
		return null;\
	\}\
\}}